define({
  "name": "node-rem",
  "version": "0.8.0",
  "description": "Node REM - NodeJS Rest Express MongoDB and more: typescript, passport, JWT, socket.io, HTTPS, HTTP2, async/await, nodemailer, templates, pagination, docker, etc.",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-06-09T00:56:01.913Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
