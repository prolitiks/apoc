# Node REM

NodeJS Rest Express MongoDB (REM) - a production-ready lightweight backend setup.



# Frontend proceedure 
components  :


1. object containing intructions for the html control group
2. an object full of functions that are used to attach to these controls as, events , control creators etc..
3. functions that are used to help build controls in 1. and get added to 2.
4. a main function ttieing all these things together 



Step 1:

EXAMPLE:
list = 
   cnt: [
      {
        crtl: ['span'],   //this is the control type , ie 'span' 
        name: ['CONE'],  // the name of the control 
        statcnt: ['TRYNAME'],  // static content, ie  <span>TRYNAME </span>
        evfuct: ['DROP'],  // this listener function that gets added just as the html cntol is created
        evtype: ['click'],  // listener event type 
        cntfuct: [],  // this is a function to create the control e.g slider, it must be created after the wrapper control is created 
        statefuct: ['ADDPLST'],  // this is the function to add state to the control, in this casre the dropdoewn 
        cls: ['uk-label'],  // the class you want toadd to the function
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'TRYNAME' },
          { datattr: 'uk-icon', val: 'icon: chevron-down ; ratio: 0.6' },
          { datattr: 'uk-byee' }
        ],
        after: ['<br>'],
        cnt: [],

        //extra ones go here

        drpdwnSelected: [],
        drpdwn: [
          { name: 'Less-than-1-year' },
          { name: '_1-3-years' },
          { name: '_3-5-years' },
          { name: '_5-10-years' },
          { name: '_10-20-years' },
          { name: 'More-than-20-years' },
          { name: 'Unknown' }
        ]
      }

createCntrlGrpx(list, next, rootel, cbhtml, funct , functab) 

e.g.  :  let ss = createCntrlGrpx(jokexx, 'cnt', 'main-box-sel' , htmStrgx , addfunctgrpx , functTable );


-what does addfunctgrpx do , ill show you
addfunctgrpx(element, obj , functab ) 

General: this gets used in the creation of the control, it add functions ot it as its getting created, or after its created

When creating the control, it looks for these key values:
        evfuct: ['DROP'],  - this listener gets added just as the html cntol is created wont work for controls created via a function e.g slider 
        evtype: ['click'],  - enetn type for the above  
        cntfuct: [],  this is a function to create the control e.g slider, it must be created after the wrapper control is created e.g create div called slider then put slider in it
        statefuct: ['ADDPLST'], this is the function to add state to the control, in this case the dropdown pill



list - array of object required for controls in page 
next - the name of the object to go to in the recursive 'cnt' -the nested object in the other object
rootel -the root element to start from , should be already on the page 
cbhtml - the callback function the creates the control from each 'cnt' object in the aray list
funct - the cb function thar adds the event listeners from another list of functions , that should also add immediately envoked functions that create controls eg. sliders
functab - an object of functions / methods that are used in the main control group

Returns :    return { el, elnames ,  elinfo}
el- the parent elemt / control just below the root el.
e.g. 
el: div#PARRA-100.PARRA.uk-card.uk-card-default.uk-card-body.CTRGP-100

elnames - alist of names of each control:
e.g. 
elnames: Array(9)
0: {crtl: Array(1), name: Array(1), statcnt: Array(0), evfuct: Array(0), cls: Array(3), …}
1: {crtl: Array(1), name: Array(1), statcnt: Array(1), evfuct: Array(1), evtype: Array(1), …}

elinfo - an array of objects
e.g. 0
elinfo: Array(8)
0: {elm: span#CONE-101.CONE.uk-label.CTRGP-100.uk-icon, obj: {…}}
1: {elm: div#PILLBOX-102.PILLBOX.flex-container.CTRGP-100, obj: {…}}
2: {elm: span#CONE-103.CONE.uk-label.CTRGP-100.uk-icon, obj: {…}}

 that contain referencer to the elemt, plus the object it was created from this is useful if later on you need to add another listener to it or get the current state of the elemnt from the object and put this back , that is update the control


 evfuct:  ['DROP']  - this is the event function this gets added to the control
 evtype:  ['click'], - this is the type of trigger for above
 cntfuct: [] - this is a potential function that is triggerd to create the control - e.g slider 


Step 2:





Step 3:



//to do
1. select , list or util control object grpups . ned to separate selector 
2. how to identify each control, class id control group id ect.
3. how to reference one control in relation to another once its created