
require('ts-node').register({
  "compilerOptions": {
    "outDir": "./built",
    "allowJs": true,
    "noImplicitAny": true,
    "strictNullChecks": true,
    "target": "es6",
    "module": "commonjs"
  },
  "include": [
    "./src/**/*"
  ],
  "exclude": [
    "node_modules" ,"public"
  ],
  "paths": {
    "api/*": ["api/*"],
    "config/*": ["config/*"]
  }
}
); // This will register the TypeScript compiler
require('./src'); // This will load our Typescript application

