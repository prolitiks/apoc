// declare module

declare module 'mstime';
