**Title**
- bug: XYZ broken...
- feature: please add...
- enhancement: add this to existing features...

**Short Description:**
- Unable to get a result from blah...
  
**Environment Details**
  * OS:
  * Node.js version:
  * npm version:

**Long Description**
- etc.

**Code**
```JS
JS code example goes here...
```

**Workaround**

...

Please help with a PR if you have a solution. Thanks!
