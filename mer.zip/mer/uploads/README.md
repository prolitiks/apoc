### Upload File

Uploaded files (using POST /upload/file) are stored here.
See: src/api/routes/v1/upload.route.ts