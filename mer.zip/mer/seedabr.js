const mongoose = require('mongoose')
require('mongoose').connect('mongodb://localhost:27017/node-rem');
var mongoose_fuzzy_searching = require('mongoose-fuzzy-searching');

const Schema = mongoose.Schema;

 



    const abrSchema = new Schema({

      BUSN	: {  type: 'String',   required: false  },
      TRADN	: {  type: 'String',   required: false  },
      TRADNF	: {  type: 'String',   required: false  },
      BUSPC	: {  type: 'String',   required: false  },
      BUSSTATE	: {  type: 'String',   required: false  },
      STATUS	: {  type: 'String',   required: false  },
      ABN_	: {  type: 'String',   required: false  },
      BSUB	: {  type: 'String',   required: false  },
      BSUBSSC	: {  type: 'String',   required: false  },
      BSUBF	: {  type: 'String',   required: false  },
      
    
      user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
    
    
      }, {strict: false});




//  merchSchema.plugin(mongooseHistory)

abrSchema.plugin(mongoose_fuzzy_searching, {fields: [ {
  name: 'BSUB',
          minSize: 4,
          
        prefixOnly: true
        
         }, {
          name: 'TRADN',
          minSize: 6
         }  
         ,
         {
          name: 'BUSN',
          minSize: 6
         }  
         ,

     ]});



Abr =mongoose.model('Abr', abrSchema);



//2661833v

const updateFuzzy = async (Model, attrs) => {
  // const data = await Model.findOne();
    const dcount = await Model.count()   
   const datax = await Model.find({}).limit(61833).skip(2600010)   ;  //2,661,833
                                                                       //1010100   

   let data;
   for (var i = 0; i < datax.length; i++) {
   data = await datax[i]
   const obj = await attrs.reduce((acc, attr) => ({ ...acc, [attr]: data[attr] }), {});
   await console.log('updated record: ', i)
   await Model.findByIdAndUpdate(data._id, obj).exec();
      if  (i== (datax.length -1 )  )
   {
     process.exit()  
   }
 }

}
 
updateFuzzy(Abr, ['BSUB','TRADN','BUSN']);



