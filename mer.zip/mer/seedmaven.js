/* eslint-disable */
const mongoose = require('mongoose')
require('mongoose').connect('mongodb://localhost:27017/node-rem');
var mongoose_fuzzy_searching = require('mongoose-fuzzy-searching');

const mavenSchema = new mongoose.Schema({


TSUB	: {  type: 'String',   required: false  },
TRADN	: {  type: 'String',   required: false  },
MSTATE	: {  type: 'String',   required: false  },
PCODE	: {  type: 'String',   required: false  },
M_LAT	: {  type: 'String',   required: false  },
M_LONG	: {  type: 'String',   required: false  },
MCC	: {  type: 'String',   required: false  },
TRADNF	: {  type: 'String',   required: false  },
TSUBF	: {  type: 'String',   required: false  },


  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }


  }, {strict: false});


  // cardSchema.plugin(mongoosePaginate);
  // cardSchema.plugin(mongoose_fuzzy_searching, {fields: ['MERCHANT_NAME', 'MERCHANT_SUBURB']});
  // cardSchema.plugin(mongooseHistory)
  //  module.exports =  mongoose.model('



//   UserSchema.plugin(mongoose_fuzzy_searching, {
//     fields: [{
//         name: 'firstName',
//         minSize: 2,
//         weight: 5
//     }, {
//         name: 'lastName',
//         minSize: 3,
//         prefixOnly: true,
//     }, {
//         name: 'email',
//         escapeSpecialCharacters: false,
//     }, {
//         name: 'text',
//         keys: ["title"] // supports only one key so far.
//     }]
    
// });

//  merchSchema.plugin(mongoosePaginate);
mavenSchema.plugin(mongoose_fuzzy_searching, {fields: [ {
  name: 'TSUB',
          minSize: 4,
          
        prefixOnly: true
        
         }, {
          name: 'TRADN',
          minSize: 4
         }  
     ]});

//  merchSchema.plugin(mongooseHistory)
Maven =mongoose.model('Maven', mavenSchema);

const updateFuzzy = async (Model, attrs) => {
       // const data = await Model.findOne();
         const dcount = await Model.count()   
        const datax = await Model.find({}).limit(262547).skip(1010100)   ;  //1272647
                                                                            //1010100   

        let data;
        for (var i = 0; i < datax.length; i++) {
        data = await datax[i]
        const obj = await attrs.reduce((acc, attr) => ({ ...acc, [attr]: data[attr] }), {});
        await console.log('updated record: ', i)
        await Model.findByIdAndUpdate(data._id, obj).exec();
           if  (i== (datax.length -1 )  )
        {
          process.exit()  
        }
      }

}

 
updateFuzzy(Maven,  ['TSUB','TRADN']);



