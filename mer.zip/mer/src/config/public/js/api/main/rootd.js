
/* eslint-disable */

import {

  getNextSibling ,
  $$ ,
  $_,
  $  ,
  $inhtm,
  getatrvals,
  isElement,
  htmStrg  ,
  htmStrgx ,
  htmStrgy,
  getFirstChild  ,
  remFrArr  ,
  mpto  ,
  ArrObjCont


} from '/js/api/modules/mods/utils.js';


import {
  selectControl as jokexx , selectControlv2 as jokeyy

} from '/js/api/modules/mods/selectControls.js';



// import { functTable } from '/js/api/modules/mods/functionTables.js';


//create controlgroup from object 
// let ss = createCntrlGrp(jokexx, 'cnt', 'main-box-sel' , htmStrgx);
// list : the object you want
// next : the container object you want  
//

// function getatrvals(subarr, objkey, keyval, el) {
//   let mp = ArrObjCont(subarr, objkey, 'data-id');
//   let eltrue = el.querySelector(`[${mp[0][objkey]}="${mp[0][keyval]}"]`);
//   return eltrue;
// }





/*!addfunctgrp
 * Adds functions, event listeners and control creators after the elemts get created!!!!
 * @param  {Object}   element    element that will get functions added to it or listeners
 * @param  {Object}   obj        The name of the object  within the array that get iterated e.g. obj.cntfuct
 * @param  {Object}   functab    The function table that refers to the functions that get added as listeners or control creators to the control group 
 */

function addfunctgrp(element, obj , functab ) {

  let cntfx = mpto(obj.cntfuct);  //this is run after the control is created to add to it e.g slider within wrapping div. 
  let evfx = mpto(obj.evfuct); // this is run after the control is created to add to it e.g. botton click event
 


  console.log('evfx ' , evfx );
  //  if it has a function to generate a control inside A DIV WRAPPER then run this

  if (cntfx) {
    let cntF = functab[cntfx];
    //    let cntF = functTable[cntfx];

    if (typeof cntF === 'function') {
      let sf = cntF(element, obj);
      sf();
    }
  }
  
  //1. returns a value for display or executes another function
  //2. return a function, for exection now of later
  //if it has an event functrion add it as a listener

  if (evfx) {

      //this is the function in the list  e.g.   DROPTEST: function(elmt , e ) {}
      //functTable['stringfunctionNAME'](element, e)
      //pass the element itself + the event info + the info from the object
     
    function wrapListener(e) {
      let tf = functab[evfx](element, obj ,e );
      if (typeof tf === 'function') {
        tf();

      

      }
    }




    element.addEventListener(mpto(obj.evtype), wrapListener);
  }


}



/*!createCntrlGrp
 * Create a group of controls from a JSON template !!!!
 * 
 * @param  {array}    list        The array of objects required for controls in page 
 * @param  {String}   next        The name of the object to go to in the recursive  e.g.'cnt'
 * @param  {Any}      rootel      The root HTML element to start from , should be already on the page 
 * @param  {Function} cbhtml      The callback function the creates the control from each 'cnt' object in the aray list
 * @param  {Function} addfunctEL  The callbackfunction that adds the event listeners from another list of functions in a function table
 * @param  {Object}   functab     The function table that refers to the functions that get added as listeners or control creators to the control group 
 * @param  {number}   cntref      The control ref identifier
 * @return {Object}    el         The parent elemt / control just below the root element
 * @return {Array}     elnames    A list of names of each control        
 * @return {Array}     elinfo     A list of names of each control and a reference to the DOM object of that element       
 */

let CNTRGRP = 99;
function createCntrlGrp(list, next, rootel, cbhtml, addfunctEL, functab, cntref = 1) {
  let el = $(rootel); //it then becomes the wraping card div e.g  PARRA-100
  CNTRGRP = cntref + 99;
  let count = 99;
  let elnames = [];
  let elinfo = [];
  function printList(list) {
    for (let i = 0; i < list.length; i++) {
      count++;
      //create the html string for later insertion using aan object to html string cb funct
      let strn = cbhtml(list[i], count).htmlstr;
      //save the list of elemet names that were created
      elnames.push(list[i]);

      // let mp = ArrObjCont(list[i].dattr, 'datattr', 'data-id');
      // console.log(' list[i].dattr:-----', list[i].dattr);

      function addstuff() {

        let mp = ArrObjCont(list[i].dattr, 'datattr', 'data-id');
        console.log(' list[i].dattr:-----', list[i].dattr);

        let eltrue = el.querySelector(`[${mp[0].datattr}="${mp[0].val}"]`);
        if (eltrue) {
          eltrue.classList.add(`CTRGP-${CNTRGRP}`);


        //addfunctgrp(element, obj , functab )
          addfunctEL(eltrue, list[i], functab);

          elinfo.push({ elm: eltrue, obj: list[i] }); //keep a ref of the ele and object for updating the save frunction
        }
      }


      //this if nsures we get  wraping card div e.g  PARRA-100 rather than main-box-sel
      if (list[i].cnt.length == 0) {
        // if this is the last control object , then get the gel
        el = $inhtm(strn, 'beforeEnd', el).gel;
        console.log('el last ' , el.id );
        addstuff();

      } 
        else {
        el = $inhtm(strn, 'beforeEnd', el).firstEl
        console.log('el not last ' , el.id );
        addstuff();

      }
      if (list[i].hasOwnProperty(next)) {
        printList(list[i][next]);
      }
    }
  }
  printList(list);
  return { el, elnames, elinfo };
}


//need a function thats takes the pill stuff and then puts the pills in all while adding even listener

function addpill(pillname, pillBox, selArr, drptype) {
  let seld = `<span class="closea">${pillname}<span id ='${pillname}' class="close ${pillname}">x</span></span>`;
  //if its a single select, just get rid of the existing pill , and clear the select array 
  if (drptype == 'single') {
    selArr.splice(0, selArr.length);  // this empties the selarry 

      console.log( '------selArr.splice(0, selArr.length); ' , selArr );

    let pill = pillBox.querySelector('span');
    if (pill) {
      pill.remove();
    }
  }
  // after the addpill is executed, push the name into the select arry + instert the pill into the poillbox , ie div
  selArr.push({ name: pillname });
  $inhtm(seld, 'afterBegin', pillBox);

  // also add an event handler to the pill, the cross, this clears that pill from the select array, ie the array that fills the 'select' array 
  pillBox.querySelector(`#${pillname}`).onclick = function(e) {
    selArr = remFrArr(selArr, [{ name: e.target.id }], 'name', 1).original;
    e.target.parentNode.remove();
  };
}



function addpillstate(elmt, obj) {
  //let selArr = obj.drpdwnSelected;
   
  
 // let drptype= obj.drpconfig[0].type  //e.g 'single'
  //let drpcnt = obj.drpconfig[0].dcnt  // 'name' 


  const containEl = elmt.parentElement.querySelector(
    `[data-rel="${ArrObjCont(obj.dattr, 'datattr', 'data-id')[0].val}"]`
  );

  //if singlr add one pill, if multi add array
  return function() {
    // this function gets exectued when run in the add state function


    addpill(obj.drpdwnSelected[0].name, containEl, obj.drpdwnSelected, obj.drpconfig[0].type  );
    //remFrArr( obj.drpdwn, obj.drpdwnSelected, drpcnt ).original;

  };
}


//new version of drop

//returns a function that becomes an event handler fro dropdowns  evfuct: ['DROP'],
//let functTable = { DROP: drp}
// if (evfx) { function wrapListener(e) {
//this is the function in the list  e.g.   DROPTEST: function(elmt , e ) {}addfunctgrpx(
//  functTable['stringfunctionNAME'](element, e)
   // pass the element itself + the event info + the info from the object
    //let tf =functTable[element.classList[0]](element, e , obj)
//let tf = functab[evfx](element, obj ,e );
   // if (typeof tf === 'function') {
   //  tf();
 // element.addEventListener(mpto(obj.evtype), wrapListener);


// let drp = function drpmx(elmt, obj) {
//   let drpDivID = `${ArrObjCont(obj.dattr, 'datattr', 'data-id')[0].val}`;
//   let drpArr = obj.drpdwn;
//   let selArr = obj.drpdwnSelected;

//    let drptype= obj.drpconfig[0].type  //e.g 'single'
//    let drpcnt = obj.drpconfig[0].dcnt  // 'name' 

//   //const inputEl = elmt;
//   const afterEl = elmt;
//   const containEl = elmt.parentElement.querySelector(`[data-rel="${drpDivID}"]`);
//   const drpdwnIn = `<div id = '${drpDivID}-${elmt.id}' uk-dropdown="mode: click" > <ul id ="${drpDivID}-${elmt.id}-DROP" class="uk-nav uk-dropdown-nav"> </ul>  </div>`;

//   function drpvauto(cb) {
//     //you hsvr 2 arrays
//     //1. Dropdown array - drparr - this is used in the dropdown list box.
//     return function() {
//       let drparrList = remFrArr(drpArr, selArr, drpcnt ).original;
//       let remDr = $(`${drpDivID}-${elmt.id}`); //remDr  - dropdown list in html 
//       if (remDr) {
//         remDr.remove();
//       }
//       $inhtm(drpdwnIn, 'afterEnd', afterEl);
//       let filldrop = $(`${drpDivID}-${elmt.id}-DROP`);
//       for (let i = 0; i < drparrList.length; i++) {
//         filldrop.insertAdjacentHTML(
//           'beforeEnd',
//           `<li><a class ="${drparrList[i].name}"  href="#" >${drparrList[i].name}</a></li>`
//         );
//         UIkit.dropdown(`#${drpDivID}-${elmt.id}`).show();
//         filldrop.addEventListener('click', cb);
//       }
//     };
//   }

//   function addp(e) {
//     e.currentTarget.parentNode.innerHTML = '';
//     addpill(e.target.innerHTML, containEl, selArr, drptype);
//   }

//   let drpf = drpvauto(addp);

//   return drpf; //returns a function
// };




let drp = function drpmx(elmt, obj) {
  let drpDivID = `${ArrObjCont(obj.dattr, 'datattr', 'data-id')[0].val}`;
  let drpArr = obj.drpdwn;
  let selArr = obj.drpdwnSelected;

  console.log( '---- dropdown obj  ' ,  obj );
  console.log( '---- dropdown elmt  ' ,  elmt );
   let drptype= obj.drpconfig[0].type  //e.g 'single'
   let drpcnt = obj.drpconfig[0].dcnt  // 'name' 

  //const inputEl = elmt;
  //the elmt is usally the triggeger, bu the dropdown itself has not been created yet
  //we call it afterEl, cuz the dropdown goes after it,
  const afterEl = elmt;

//the containEl is where the pillbox goes we usally put this in another flex box and we select it by selecting the data-rel = 'TRYNAME'
//    dattr: [
//   { datattr: 'data-id', val: 'PILLBOX' },
//   { datattr: 'data-rel', val: 'TRYNAME' }
// ],
  const containEl = elmt.parentElement.querySelector(`[data-rel="${drpDivID}"]`);


  //drpdwnIn string that get converted to html,  the div that goes after the button that will contain the dropdown list, this is usally a div with a UL indside it ready to get filled
  // with li 's

  const drpdwnIn = `<div id = '${drpDivID}-${elmt.id}' uk-dropdown="mode: click" > <ul id ="${drpDivID}-${elmt.id}-DROP" class="uk-nav uk-dropdown-nav"> </ul>  </div>`;



//need to add this
  let drpMulti = function() {
    let drpCurrent = removeFromArray(drpArr, selArr);
    let remDr = $(_drpDivID);
    if (remDr) {
      remDr.remove();
    }
    afterEl.insertAdjacentHTML('afterEnd', drpdwnIn);
    let val = inputEl.value;
    let arr = drpCurrent;
    let filldrop = $(`${dropName}-DROP-${_id}`);
    if (val.length > 0) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].substr(arr[i].indexOf(val), val.length).toUpperCase() == val.toUpperCase()) {
          filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ='DROP-${_id}' href="#" >${arr[i]}</a></li>`);
          UIkit.dropdown(`#${_drpDivID}`).show();
          filldrop.addEventListener('click', addMulti);
        }
      }
    } else remDr.remove();
  };




  function drpvauto(cb) {
    //you hsvr 2 arrays
    //1. Dropdown array - drparr - this is used in the dropdown list box.
    return function() {
      let drparrList = remFrArr( obj.drpdwn, obj.drpdwnSelected, drpcnt ).original;
       console.log('obj.drpdwnSelected; ' , obj.drpdwnSelected);
       console.log('drparrList; ' , drparrList);
     //need to update the actual opbject   e.g obj.drpdwnSelected 

      let remDr = $(`${drpDivID}-${elmt.id}`); //remDr  - dropdown list in html 
      if (remDr) {
        remDr.remove();
      }
      $inhtm(drpdwnIn, 'afterEnd', afterEl);
      let filldrop = $(`${drpDivID}-${elmt.id}-DROP`);
      for (let i = 0; i < drparrList.length; i++) {
        filldrop.insertAdjacentHTML(
          'beforeEnd',
          `<li><a class ="${drparrList[i].name}"  href="#" >${drparrList[i].name}</a></li>`
        );
        UIkit.dropdown(`#${drpDivID}-${elmt.id}`).show();
        filldrop.addEventListener('click', cb);
      }
    };
  }

  function addp(e) {
    e.currentTarget.parentNode.innerHTML = '';
    addpill(e.target.innerHTML, containEl, obj.drpdwnSelected, drptype);
  }

  let drpf = drpvauto(addp);

  return drpf; //returns a function thats added as an event listener
};




//   slider array, e,g const YMARR = []; ["201710", "201711", "201712", "201801", "201802", "201803"]
// sliderEl -element of the div
//


function sliderN(slideObj, minEl, maxEl, sldArr, sliderEl) {
  let sldArr_ = sldArr;
  const startSlider = $(sliderEl);
  noUiSlider.create(startSlider, slideObj);

  const marginMin = $(minEl); // the pill with thats gets the first knob value
  const marginMax = $(maxEl); // the pill with thats gets the second knob value

  //add function to update pilss on chanmge of handle
  startSlider.noUiSlider.on('update', function(values, handle) {
    //if you are preessing handle a it will bve 0, if handle b it will be 1

    if (handle) {
      //could be 0 or 1  in this case its 1
      marginMax.innerHTML = sldArr_[Math.trunc(values[handle])]; //datesrg[Math.trunc(values[handle]) ]; orginal value is e.g 20.0, need to make this '2'
    } else {
      marginMin.innerHTML = sldArr_[Math.trunc(values[handle])];
    }
  });
  //in case you need to set something here
  // startSlider.noUiSlider.set();
}


function getconattrb ( elmt, obj , key , objar , objarkey , objarkeyn , objarval   )  {


//( elmt, obj , 'data-id' ,'dattr ', 'datattr', 'data-frm' , 'val'  )  
 return elmt.parentElement.querySelector(`[${key}="${ArrObjCont(obj[objar], objarkey, objarkeyn )[0][objarval]}"]`);

//elemt current elemt that is passed in e.g. slider div
//<div id="slider-108" data-id="SLIDER" data-frm="FROMDATE" data-to="TODATE" class="slider">

//i want to find this element 
 // <span id="FRDTE-106" data-id="FROMDATE" class="FRDTE closeb CTRGP-100">201712</span>
 // using this array of objects
 //   dattr: [
  //     { datattr: 'data-id', val: 'SLIDER' },
  //     { datattr: 'data-frm', val: 'FROMDATE' },...........................
  //     { datattr: 'data-to', val: 'TODATE' }
  //   ],
  //i will create this: elmt.parentElement.querySelector ( [data-id="FROMDATE"]  )


 // const minEl = elmt.parentElement.querySelector(`[data-id="${ArrObjCont(obj.dattr, 'datattr', 'data-frm')[0].val}"]`);

 // elmt.parentElement.querySelector(`[data-rel="${ArrObjCont(obj.dattr, 'datattr', 'data-id')[0].val}"]`);
  //elmt.parentElement.querySelector ( [data-id="FROMDATE"]  )
  
}



let sldx = function sld(elmt, obj) {
  let sldArr = obj.sldarr;
  let sliderEl = elmt;
  let slideObj = obj.sldint;
  //minEl : where you are going to put the value of the min amount from the slider handle
  //in this case the find the pill elemt min via thios queryselector
  //but you use the slider obj div, to then find the pill
 const minEl = elmt.parentElement.querySelector(`[data-id="${ArrObjCont(obj.dattr, 'datattr', 'data-frm')[0].val}"]`);
   
  const minElx =  getconattrb ( elmt, obj , 'data-id' ,'dattr', 'datattr', 'data-frm' , 'val'  ) 

  //this becomes  elmt.parentElement.querySelector ( [data-id="FROMDATE"]  )
  console.log('minelx ', minElx);
 // console.log('query sel slider ' , `[data-id="${ArrObjCont(obj.dattr, 'datattr', 'data-frm')[0].val}"]` );
  // {
  //   crtl: ['div'],
  //   name: ['slider'],
  //   statcnt: [],
  //   cntfuct: ['SLIDE'],
  //   evfuct: [],
  //   evtype: [],
  //   cls: ['sc'],
  //   freeattr: [],
  //   dattr: [
  //     { datattr: 'data-id', val: 'SLIDER' },
  //     { datattr: 'data-frm', val: 'FROMDATE' },...........................
  //     { datattr: 'data-to', val: 'TODATE' }
  //   ],





  //this will find pill:
  // {
  //   crtl: ['span'],
  //   name: ['FRDTE'],
  //   statcnt: [], 
  //   evfuct: [],
  //   evtype: [],
  //   cls: ['closeb'],
  //   freeattr: [],
  //   dattr: [{ datattr: 'data-id', val: 'FROMDATE' }],
  //   after: [],
  //   cnt: []
  // },
  // },



  const maxEl = elmt.parentElement.querySelector(`[data-id="${ArrObjCont(obj.dattr, 'datattr', 'data-to')[0].val}"]`);
  let sld_ = function() {
    sliderN(slideObj, minEl, maxEl, sldArr, sliderEl);
  };
  return sld_;
};



let stb = function st(elmt, obj)
{


  const contEl= elmt.parentElement.querySelector(`[data-id="${ArrObjCont(obj.dattr, 'datattr', 'data-rel')[0].val}`);

  console.log('stable ver 2 elmt  '  , elmt );
  console.log('stable ver 2 obj  '  , obj  );
  console.log('stable ver 2 contEl  '  , contEl  );



   
//table
const ListFromJSON = function(apiadd, dataObj, afterElemtId, inJson, tableID = 100) {
  //delete existing table  #table-101
  const containEl = afterElemtId

  let tbl = containEl.querySelector('table');
  if (tbl !== null) {
    tbl.remove();
  }

  console.log('dataOBj', apiadd, dataObj);

  let tableHTML = `
 <table id ="table-${tableID}" class="uk-table uk-table-divider uk-table-hover uk-table-small">
 <thead id ="thead-${tableID}"><tr id="thr-${tableID}"></tr></thead>
 <tbody id ="tbody-${tableID}"></tbody>
 </table>`;

  containEl.insertAdjacentHTML('beforeEnd', tableHTML);
  const hdr = document.querySelector(`#thead-${tableID}`).firstChild;
  const bdr = document.querySelector(`#tbody-${tableID}`);

  var col = [];
  let rowdata = '';
  //header
  for (var i = 0; i < inJson.length; i++) {
    for (var key in inJson[0]) {
      if (col.indexOf(key) === -1) {
        col.push(key);
        hdr.insertAdjacentHTML('beforeEnd', `<td>${key}</td>`);
      }
    }
    for (var property in inJson[i]) {
      rowdata += `<td>${inJson[i][property]}</td>`;
    }
    bdr.insertAdjacentHTML('beforeEnd', `<tr class ="thr-${tableID}">${rowdata}</tr>`);
    // console.log(bdr.lastChild); event listener addition

    rowdata = '';
  }
};


  const getData = async (apiadd, dataObj, afterElemtId, pg) => {
    let query = [];
    for (let key in dataObj) {
      if (dataObj.hasOwnProperty(key)) {
        query.push(`${encodeURIComponent(key)}=${encodeURIComponent(dataObj[key])}`);
      }
    }
    let srchterm = query.join('&');
  
    console.log(`/v1/${apiadd}?${srchterm}&page=${pg}`);
    const response = await axios({
      url: `/v1/${apiadd}?${srchterm}&page=${pg}`,
      method: 'get',
      onDownloadProgress: function(progressEvent) {}
    });
  
    console.log('url ', `/v1/${apiadd}?${srchterm}&page=${pg}`);
    let { data, meta } = await response.data;
    let { perPage, limit, sort, totalCount, pageCount, count, page } = meta;
    let page_ = page.toString();
    await console.log('pagedata: ', perPage, limit, sort, totalCount, pageCount, count, page_);
  
    let inJson = await data;
    await console.log('getall: ', inJson);
    await ListFromJSON(apiadd, dataObj, afterElemtId, inJson, 101);
    return { data, meta };
  };
  
  let qury = { perPage: 10, sort: 'MerText:desc', FUZ: 'mcd' };
  getData(`card/fuzz`, qury, contEl, 1);

}





// this is the gateway for functions


let functTable = {

  DROP: drp,

  SLIDE: sldx  ,

  ADDPLST : addpillstate  ,

  STABLE : stb

};





function lisntoCntrGrp(cntrlWrapEle, commClassName, funct) {
  // commClassName : group class name or common selector for group
  // cntrlWrapEle : parent elemnt
  // funct : callback function  for each control , then adds listener based on controls

  let cntrls = $$(commClassName, cntrlWrapEle);

  for (let i = 0; i < cntrls.length; i++) {
    funct(cntrls[i]);
  }
}

//needed for dropdown  document.querySelector("#PILLBOX-102")




// <div class="uk-margin">
// <input class="uk-input uk-form-width-small uk-form-small" type="text" placeholder="Input">
// </div>


function T1() {

 // let ne = $('main-box-sel');
 // lisntoCntrGrp(ss.el, '.CONE',  addfunctgrp );

 let sssss= document.querySelector("#PILLBOX-102.CTRGP-100")
 console.log(sssss);



}





function T2() {


  console.log(' joke ' ,  jokexx[0].cnt[0] );
 
}




function T3() {

let ss = createCntrlGrp(jokexx, 'cnt', 'main-box-sel' , htmStrgx , addfunctgrp , functTable );
console.log('ss :::::: '  ,ss);


function updateState(elobj) {
  let { el, elinfo, elnames } = elobj;

  //lkoop here and change control group

  for (let i = 0; i < elinfo.length; i++) {
    let em = elinfo[i].elm;
    let obj= elinfo[i].obj;    

 let statefx = mpto(obj.statefuct); 

  if (statefx) {
    let stF = functTable[statefx];

    if (typeof stF === 'function') {
      let sfx = stF(em, obj);
      sfx();
    }
  }
  
    console.log('statefx ' , statefx);
  }
}


updateState( ss)


}




function createSliderArr ( arrObj) {

  const arrobj = arrObj
  
  const YMARR = [];
  for (let i = 0; i < arrobj.length; i++) {
    if (min <= arrobj[i].YMC && max >= arrobj[i].YMC) {
      YMARR.push(arrobj[i].YM);
    }
  }

}


// 
//handle - this is 0 or 1  for 2 handle slider 
//values  an array of the 2 value handles eg  [ '10' , '80']
//datesrg[Math.trunc(values[handle]) / 10 - 1];
// slideObj  is the standard  config object :  
// const objsld = {
//   start: [20, 60], ----where you want the 2 handles to start 
//   connect: true,  -----defaults to true
//   step: 10,   --- how much each strep of the slider is 
//   range: {    the total range of the slider  
//     min: [10],   
//     max: [70]
//   }
// }

//  sldArr   :  this is thge arry of single values that will appear on the target elemet, eg, pill from to date







function T4() {

  let ss = createCntrlGrp(jokeyy, 'cnt', 'main-box-sel' , htmStrgy , addfunctgrp , functTable );
  console.log(ss);

}






function T5() {


  /*
1. list with table
2. pagiation
3. continus

USAGE example
  let qury =  {    perPage :10  ,sort : 'MerText:desc'   ,   FUZ:'mcd'       }
  getData( `card/fuzz`  , qury    ,`main-box-sel`, 1 );
*/

function pagination(apiadd, dataObj, afterElemtId, page = '0', pages = 0) {
  const afterEl = document.querySelector(`#${afterElemtId}`);
  const curpg = parseInt(page);
  const nxtpg = curpg + 1;
  const prvpg = curpg - 1;

  console.log(' pag, data obj  ', dataObj);

  let fist = document.querySelector('#pagea > ul');
  if (fist !== null) {
    fist.remove();
  }

  afterEl.insertAdjacentHTML(
    'afterend',
    `<div id ="pagea" class="uk-flex-center"><ul class="uk-pagination" ></ul></div>`
  );

  console.log('apiadd pgation ', apiadd, 'page ', page, 'pages ', pages);

  let li = afterEl.nextElementSibling.lastElementChild;

  // previous <
  // of current page not 1 you can go back
  if (curpg !== 1) {
    li.insertAdjacentHTML('beforeend', `<li><a  href="#"><span uk-pagination-previous></span></a></li>`);

    li.lastChild.addEventListener(
      'click',
      function() {
        getData(`card/fuzz`, dataObj, `main-box-sel`, prvpg);
      },
      false
    );
  } else {
    li.insertAdjacentHTML('beforeend', `<li><a href="#"><span uk-pagination-previous></span></a></li>`);
  }

  console.log('afterEl ', li);

  let outpgarr = generatePagination(curpg, pages);
  console.log('outpgarr ', outpgarr);

  // [1, 2, 3, "...", 46]

  for (let i = 0; i < outpgarr.length; i++) {
    li.insertAdjacentHTML('beforeend', `<li><a href="#">${outpgarr[i]}</a></li>`);

    li.lastChild.addEventListener(
      'click',
      function() {
        getData(`card/fuzz`, dataObj, `main-box-sel`, outpgarr[i]);
      },
      false
    );

    if (outpgarr[i] == '...') {
      li.lastChild.classList.add('uk-disabled');
    }
    if (outpgarr[i] == page) {
      li.lastChild.classList.add('uk-active');
    }
  }

  if (curpg < pages) {
    li.insertAdjacentHTML('beforeend', `<li> <a  href="#"><span uk-pagination-next></span></a>  </li>`);
    li.lastChild.addEventListener(
      'click',
      function() {
        getData(`card/fuzz`, dataObj, `main-box-sel`, nxtpg);
      },
      false
    );
  } else {
    li.insertAdjacentHTML('beforeend', `<li><a   href="#"><span uk-pagination-next>.</span></a></li>`);
  }

  function generatePagination(current, last) {
    const offset = 2;
    const leftOffset = current - offset;
    const rightOffset = current + offset + 1;

    /**
     * Reduces a list into the page numbers desired in the pagination
     * @param {array} accumulator - Growing list of desired page numbers
     * @param {*} _ - Throwaway variable to ignore the current value in iteration
     * @param {*} idx - The index of the current iteration
     * @returns {array} The accumulating list of desired page numbers
     */
    function reduceToDesiredPageNumbers(accumulator, _, idx) {
      const currIdx = idx + 1;

      if (
        // Always include first page
        currIdx === 1 ||
        // Always include last page
        currIdx === last ||
        // Include if index is between the above defined offsets
        (currIdx >= leftOffset && currIdx < rightOffset)
      ) {
        return [...accumulator, currIdx];
      }

      return accumulator;
    }

    /**
     * Transforms a list of desired pages and puts ellipsis in any gaps
     * @param {array} accumulator - The growing list of page numbers with ellipsis included
     * @param {number} currentPage - The current page in iteration
     * @param {number} currIdx - The current index
     * @param {array} src - The source array the function was called on
     */
    function transformToPagesWithEllipsis(accumulator, currentPage, currIdx, src) {
      const prev = src[currIdx - 1];

      if (prev != null && currentPage - prev !== 1) {
        return [...accumulator, '...', currentPage];
      }

      // If page does not meet above requirement, just add it to the list
      return [...accumulator, currentPage];
    }
    const pageNumbers = Array(last)
      .fill()
      .reduce(reduceToDesiredPageNumbers, []);
    const pageNumbersWithEllipsis = pageNumbers.reduce(transformToPagesWithEllipsis, []);
    return pageNumbersWithEllipsis;
  }
}

//table
const ListFromJSON = function(apiadd, dataObj, afterElemtId, inJson, tableID = 100) {
  //delete existing table  #table-101
  const containEl = document.querySelector(`#${afterElemtId}`);

  let tbl = containEl.querySelector('table');
  if (tbl !== null) {
    tbl.remove();
  }

  console.log('dataOBj', apiadd, dataObj);

  let tableHTML = `
 <table id ="table-${tableID}" class="uk-table uk-table-divider uk-table-hover uk-table-small">
 <thead id ="thead-${tableID}"><tr id="thr-${tableID}"></tr></thead>
 <tbody id ="tbody-${tableID}"></tbody>
 </table>`;

  containEl.insertAdjacentHTML('beforeEnd', tableHTML);
  const hdr = document.querySelector(`#thead-${tableID}`).firstChild;
  const bdr = document.querySelector(`#tbody-${tableID}`);

  var col = [];
  let rowdata = '';
  //header
  for (var i = 0; i < inJson.length; i++) {
    for (var key in inJson[0]) {
      if (col.indexOf(key) === -1) {
        col.push(key);
        hdr.insertAdjacentHTML('beforeEnd', `<td>${key}</td>`);
      }
    }
    for (var property in inJson[i]) {
      rowdata += `<td>${inJson[i][property]}</td>`;
    }
    bdr.insertAdjacentHTML('beforeEnd', `<tr class ="thr-${tableID}">${rowdata}</tr>`);
    // console.log(bdr.lastChild); event listener addition

    rowdata = '';
  }
};

const getData = async (apiadd, dataObj, afterElemtId, pg) => {
  let query = [];
  for (let key in dataObj) {
    if (dataObj.hasOwnProperty(key)) {
      query.push(`${encodeURIComponent(key)}=${encodeURIComponent(dataObj[key])}`);
    }
  }
  let srchterm = query.join('&');

  console.log(`/v1/${apiadd}?${srchterm}&page=${pg}`);
  const response = await axios({
    url: `/v1/${apiadd}?${srchterm}&page=${pg}`,
    method: 'get',
    onDownloadProgress: function(progressEvent) {}
  });

  console.log('url ', `/v1/${apiadd}?${srchterm}&page=${pg}`);
  let { data, meta } = await response.data;
  let { perPage, limit, sort, totalCount, pageCount, count, page } = meta;
  let page_ = page.toString();
  await console.log('pagedata: ', perPage, limit, sort, totalCount, pageCount, count, page_);

  await pagination(apiadd, dataObj, afterElemtId, page_, pageCount);

  let inJson = await data;
  await console.log('getall: ', inJson);
  await ListFromJSON(apiadd, dataObj, afterElemtId, inJson, 101);
  return { data, meta };
};

let qury = { perPage: 10, sort: 'MerText:desc', FUZ: 'mcd' };
getData(`card/fuzz`, qury, `main-box-sel`, 1);
}




function T6() {
  /*
1. list with table
2. pagiation
3. continus

USAGE example
  let qury =  {    perPage :10  ,sort : 'MerText:desc'   ,   FUZ:'mcd'       }
  getData( `card/fuzz`  , qury    ,`main-box-sel`, 1 );
*/

  function pagination( afterElemtId, page = '0', pages = 0 , gdata) {

   const afterEl = $(`${afterElemtId}`);
    const curpg = parseInt(page);
    const nxtpg = curpg + 1;
    const prvpg = curpg - 1;
    // let pagetrig =  function(pgnbr) {
    //   li.lastChild.addEventListener( 'click',  function() { gdata(apiadd, dataObj, afterElemtId, pgnbr)  }, false  );
    // }

    let pagetrig =  function(pgnbr) {
      li.lastChild.addEventListener( 'click',  function() {  console.log('  pgnbr is : ',   pgnbr) }, false  );
    }


    let fist = document.querySelector('#pagea > ul');
    if (fist !== null) {
      fist.remove();
    }

    afterEl.insertAdjacentHTML(
      'afterend',
      `<div id ="pagea" class="uk-flex-center"><ul class="uk-pagination" ></ul></div>`
    );
  
    let li = afterEl.nextElementSibling.lastElementChild;
  

    // previous <
    // of current page not 1 you can go back
    if (curpg !== 1) {
      li.insertAdjacentHTML('beforeend', `<li><a  href="#"><span uk-pagination-previous></span></a></li>`);
      pagetrig (prvpg)
    } else {
      li.insertAdjacentHTML('beforeend', `<li><a href="#"><span uk-pagination-previous></span></a></li>`);
    }

    let outpgarr = generatePagination(curpg, pages);

    console.log( ' outpgarr ---' , outpgarr );
    
    // [1, 2, 3, "...", 46]

    for (let i = 0; i < outpgarr.length; i++) {
      li.insertAdjacentHTML('beforeend', `<li><a href="#">${outpgarr[i]}</a></li>`);

      pagetrig (outpgarr[i] )

      if (outpgarr[i] == '...') {
        li.lastChild.classList.add('uk-disabled');
      }
      if (outpgarr[i] == page) {
        li.lastChild.classList.add('uk-active');
      }
    }

    if (curpg < pages) {
      li.insertAdjacentHTML('beforeend', `<li> <a  href="#"><span uk-pagination-next></span></a>  </li>`);
      pagetrig (nxtpg)
    } else {
      li.insertAdjacentHTML('beforeend', `<li><a   href="#"><span uk-pagination-next></span></a></li>`);
    }

    function generatePagination(current, last) {
      const offset = 2;
      const leftOffset = current - offset;
      const rightOffset = current + offset + 1;
      function reduceToDesiredPageNumbers(accumulator, _, idx) {
        const currIdx = idx + 1;
        if (
          // Always include first page
          currIdx === 1 ||
          // Always include last page
          currIdx === last ||
          // Include if index is between the above defined offsets
          (currIdx >= leftOffset && currIdx < rightOffset)
        ) {
          return [...accumulator, currIdx];
        }

        return accumulator;
      }

      function transformToPagesWithEllipsis(accumulator, currentPage, currIdx, src) {
        const prev = src[currIdx - 1];
        if (prev != null && currentPage - prev !== 1) {
          return [...accumulator, '...', currentPage];
        }
        return [...accumulator, currentPage];
      }
      const pageNumbers = Array(last)
        .fill()
        .reduce(reduceToDesiredPageNumbers, []);
      const pageNumbersWithEllipsis = pageNumbers.reduce(transformToPagesWithEllipsis, []);
      return pageNumbersWithEllipsis;
    }
  }

  //table
  const ListFromJSON = function( afterElemtId, inJson, tableID = 100) {
    //delete existing table  #table-101
    const containEl = document.querySelector(`#${afterElemtId}`);

    let tbl = containEl.querySelector('table');
    if (tbl !== null) {
      tbl.remove();
    }

   

    let tableHTML = `
   <table id ="table-${tableID}" class="uk-table uk-table-divider uk-table-hover uk-table-small">
   <thead id ="thead-${tableID}"><tr id="thr-${tableID}"></tr></thead>
   <tbody id ="tbody-${tableID}"></tbody>
   </table>`;

    containEl.insertAdjacentHTML('beforeEnd', tableHTML);
    const hdr = document.querySelector(`#thead-${tableID}`).firstChild;
    const bdr = document.querySelector(`#tbody-${tableID}`);

    var col = [];
    let rowdata = '';
    //header
    for (var i = 0; i < inJson.length; i++) {
      for (var key in inJson[0]) {
        if (col.indexOf(key) === -1) {
          col.push(key);
          hdr.insertAdjacentHTML('beforeEnd', `<td>${key}</td>`);
        }
      }
      for (var property in inJson[i]) {
        rowdata += `<td>${inJson[i][property]}</td>`;
      }
      bdr.insertAdjacentHTML('beforeEnd', `<tr class ="thr-${tableID}">${rowdata}</tr>`);
      // console.log(bdr.lastChild); event listener addition

      rowdata = '';
    }
  };





  let qury = { perPage: 10, sort: 'MerText:desc', FUZ: 'mcd' };


  //getData(`card/fuzz`, qury, `main-box-sel`, 1);



  const getDataFromAPI = async (apiadd, dataObj , pg=1) => {
    let query = [];
    for (let key in dataObj) {
      if (dataObj.hasOwnProperty(key)) {
        query.push(`${encodeURIComponent(key)}=${encodeURIComponent(dataObj[key])}`);
      }
    }
    let srchterm = query.join('&');

    //console.log(`/v1/${apiadd}?${srchterm}&page=${pg}`);
    const response = await axios({
      url: `/v1/${apiadd}?${srchterm}&page=${pg}`,
      method: 'get',
      onDownloadProgress: function(progressEvent) {   console.log( ' progressEvent  ' , progressEvent );  }
    });

    let { data, meta } = await response.data;

   // console.log('url ', `/v1/${apiadd}?${srchterm}&page=${pg}`);
    return { data, meta }
  }



  async  function makeListwithData() {
   let  { data, meta } = await getDataFromAPI(`card/fuzz`, qury , 1);

  console.log('data :----- ', data );

  console.log('meta :----- ', meta );

  ListFromJSON ( `main-box-sel`, data, 101)
   let { perPage, limit, sort, totalCount, pageCount, count, page } = meta;
 //  console.log('paage '  , page);
   let page_ = page.toString();
    pagination(`main-box-sel`, page_ , pageCount , getDataFromAPI );


  }
 

makeListwithData()

}

function T7() {









}

function T8() {}

function T9() {}

function T10() {

let xxx =   document.querySelector('#pagea > ul');

console.log(xxx);

}

document.querySelector('#T1').addEventListener('click', T1);
document.querySelector('#T2').addEventListener('click', T2);
document.querySelector('#T3').addEventListener('click', T3);
document.querySelector('#T4').addEventListener('click', T4);
document.querySelector('#T5').addEventListener('click', T5);
document.querySelector('#T6').addEventListener('click', T6);
document.querySelector('#T7').addEventListener('click', T7);
document.querySelector('#T8').addEventListener('click', T8);
document.querySelector('#T9').addEventListener('click', T9);
document.querySelector('#T10').addEventListener('click', T10);
