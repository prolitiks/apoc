
/* eslint-disable */

import * as mapjs from '../api/modules/mapInit.js'


// import * as dataSelect from '../api/modules/dataSelect.js'
// import * as mapjs from '../api/modules/mapSetup.js'

import * as charts from '../api/modules/charts.js'



import { red8 } from  '../api/modules/dataSelect.js'
//console.log(red8)  src\config\public


