/*
 Highcharts JS v7.2.0 (2019-09-03)
 (c) 2009-2019 Torstein Honsi
 License: www.highcharts.com/license
*/

/* eslint-disable *//*
 Highcharts JS v7.2.0 (2019-09-03)
 (c) 2009-2019 Highsoft AS
 License: www.highcharts.com/license
*/


(function(a) {
  "object" === typeof module && module.exports ? (a["default"] = a, module.exports = a) : "function" === typeof define && define.amd ? define("highcharts/themes/high-contrast-light", ["highcharts"], function(b) {
      a(b);
      a.Highcharts = b;
      return a
  }) : a("undefined" !== typeof Highcharts ? Highcharts : void 0)
})(function(a) {
  function b(a, b, c, d) {
      a.hasOwnProperty(b) || (a[b] = d.apply(null, c))
  }
  a = a ? a._modules : {};
  b(a, "themes/high-contrast-light.js", [a["parts/Globals.js"]], function(a) {
      a.theme = {
          colors: "#737373 #bdbdbd #f0f0f0".split(" "),


          navigator: {
              series: {
                  color: "#252525",
                  lineColor: "#252525"
              }
          }
      };
      a.setOptions(a.theme)
  });
  b(a, "masters/themes/high-contrast-light.src.js", [], function() {})
});
//# sourceMappingURL=high-contrast-light.js.map


//['#ffffff','#f0f0f0','#d9d9d9','#bdbdbd','#969696','#737373','#525252','#252525']