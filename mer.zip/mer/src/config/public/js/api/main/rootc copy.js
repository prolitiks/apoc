/* eslint-disable */





// function remFrArr(original, remove , objkey) {

//   for (let i = original.length - 1; i >= 0; i--) {
//     for (let j = 0; j < remove.length; j++) {
//       if (original[i] && original[i][objkey] === remove[j][objkey]) {
//         original.splice(i, 1);
//       }
//     }
//   }
  
//   let named =original.map( nme => nme[objkey]  );

//   return   { original , named  } 
// }
var getNextSibling = function (elem, selector) {

	// Get the next sibling element
	var sibling = elem.nextElementSibling;

	// If there's no selector, return the first sibling
	if (!selector) return sibling;

	// If the sibling matches our selector, use it
	// If not, jump to the next sibling and continue the loop
	while (sibling) {
		if (sibling.matches(selector)) return sibling;
		sibling = sibling.nextElementSibling
	}

};

/*!
 * Get an array of all matching elements in the DOM
 * (c) 2019 Chris Ferdinandi, MIT License, https://gomakethings.com
 * @param  {String} selector The element selector
 * @param  {Node}   parent   The parent to search in [optional]
 * @return {Array}           Th elements
 */
var $$ = function (selector, parent) {
  return Array.prototype.slice.call((parent ? parent : document).querySelectorAll(selector));
};

var $_ = function (selector, parent) {
  return (parent ? parent : document).querySelector(selector);
};

function isElement(o) {
  return typeof HTMLElement === 'object'
    ? o instanceof HTMLElement //DOM2
    : o && typeof o === 'object' && o !== null && o.nodeType === 1 && typeof o.nodeName === 'string';
}

let $ = function(selector, parent) {
  return isElement(selector) ? selector : (parent ? parent : document).querySelector(`#${selector}`);
};

function htmStrg(cfgobj, idx) {
  let { crtl, name, prefix, cls, attr, cnt, after ,  attrname  ,attrval  } = cfgobj;
  let tag = `<${crtl} ${mpto(attr,' ')} ${mpto(attrname,' ')}${mpto(attrval,' ')} id="${prefix}-${idx}" class ="${mpto(name,' ')} ${mpto(cls,' ')}">${cnt}`;
  let tagaft = `</${crtl}>${after}`;
  let htmlstr = `${tag}${tagaft}`;
  return { htmlstr, tag, tagaft };
}



function getFirstChild(el){
  var firstChild = el.firstChild;
  while(firstChild != null && firstChild.nodeType == 3){ // skip TextNodes
    firstChild = firstChild.nextSibling;
  }
  return firstChild;
}



//helper for inserting html
function $inhtm(html, pos, element) {
  const gel = $(element);
  gel.insertAdjacentHTML(pos, html);
  const firstEl = getFirstChild(gel)
  const lastEl = gel.lastElementChild;
  return { gel, firstEl, lastEl };
}

//helper for extracting vaues out of arrays into single strings
//if values is string or number just return
// obkeyname - if has another object , ADD THIS NI OPTIONAL
//if value is array return as joined string
//if array has objects return the values from the key string name, if not return all vales in object

// typeof inp !== "undefined" && (typeof inp !== "object" || !inp)

let mpto = function(inp, joinvalue, obkeyname) {
  let ky;
  let vl;

  if (typeof inp ==="undefined" ||  (typeof inp !== "object" || !inp)   ) {
    return ''
  }
  else

  return typeof inp === 'string' || typeof inp === 'number' // ||  typeof inp ==="undefined"
    ? inp

    : //string of object key name
      inp
        .map(function(part) {
          if (typeof inp[0] === 'object') {

            if (Object.values(part).length > 1  &&  Object.keys(part)[0] =='datattr'   ) {
              ky = Object.values(part)[0];
              vl = Object.values(part)[1];
              return `${ky} = "${vl}"`;
            }

            if (obkeyname) {
              return Object.values(part[obkeyname]).join(joinvalue);
            } else return Object.values(part).join(joinvalue);
          }
          return part;
        })
        .join(joinvalue);
    

};

//if the key value matches the objects in the arry return the object selected
//returns all the objects that match the key val so need to [ ] to get the single object
//arr - array of objects
//key - key of object to select
//value of that key to select

function ArrObjCont(arr, key, value) {
  let ar = arr.filter(function(obj) {
    if (obj[key].includes(value)) {
      return obj;
    }
  }); 
  return ar;
}

// <div id="SelCard-${CardId}" class="uk-card uk-card-default uk-card-body">
//need instancce id- lowest , plus insert groiup id 

let jew= 

{
  crtl: 'span',
  grp: 'cntr',
  name: 'CONDROP',
  prefix: 'LB',
  id: 1,
  cls: ['CTHREE', 'uk-label'],
  freeattr: [],
  attr: [`uk-icon="icon: chevron-down ; ratio: 0.6"`],
  AttrValue: [],
  cnt: ['OTHER CONT'],
  after: '<br>' ,
  nonest: 1 , 
  
  ctype: 'CMRELYEARS',

  drpdwnSelected: [  ],
  drpdwn: [
    { name: 'Less-than-1-year', code: '1' },
    { name: 'x1-3-years', code: '2' },
    { name: 'x3-5-years', code: '3' },
    { name: 'x5-10-years', code: '4' },
    { name: 'x10-20-years', code: '5' },
    { name: 'More-than-20-years', code: '6' },
    { name: 'Unknown', code: '7' }
  ]

}  




let lyOb = {

  //these get incremented 
  wstate : {  

    Pageid: 99 ,
    CtrlGpid :99 ,
    Ctrlid : 99 
  
  }
  ,

  //may need event listener object within this 
  main: [
    { ky: 'grp', clsnme: 'CARD',   val: 'page', elm: 'lastEl', lisfunc: 'doit'  ,grpid: 1 },
    { ky: 'grp',  clsnme: 'CONDROP' , val: 'cntr', elm: 'lastEl', lisfunc: 'doitagain' , grpid: 2   }

  ]  ,
  
  controls : 
  [

    {
      crtl: 'span',
      grp: 'cntr',
      name: 'CONDROP', //names always used to get thclsnmee group of elemts this is attached first to the classlist
      prefix: 'LB',
      id: 1,
      cls: ['CONE', 'uk-label'],
      freeattr: [],
      attr: [`uk-icon="icon: chevron-down ; ratio: 0.6"`],
      attrname: [`data-con`,`=`],
      attrval: ['rot01'],
      cnt: ['TIME WINNER'],
      after: '<br>',
      nonest: 1, 
      ctype: 'CMRELY',
      drpdwnSelected: [],
      drpdwn: [
        { name: 'Less-than-1-year' },
        { name: '1-3-years' },
        { name: '3-5-years' },
        { name: '5-10-years' },
        { name: '10-20-years' },
        { name: 'More-than-20-years' },
        { name: 'Unknown'}
      ]
    },

   
    {
      crtl: 'div',
      grp: 'cntr',
      name: 'CONDROP',
      prefix: 'PB',
      id: 1,
      cls: ['CONEPILLBOX','flex-container'],
      freeattr: [],
      attr: [],
      attrname: [`data-con`,`=`],
      attrval: ['testdr01'],
      cnt: [],
      after: '',
      nonest: 1, 
    },



    {
      crtl: 'span',
      grp: 'cntr',
      name: 'CONDROP',
      prefix: 'LB',
      id: 1,
      cls: ['CTWO', 'uk-label'],
      freeattr: [],
      attr: [`uk-icon="icon: chevron-down ; ratio: 0.6"`],
      attrname: [`data-con`,`=`],
      attrval: ['rot'],
      cnt: ['TIME HORIZON'],
      after: '<br>',
      nonest: 1 , 
      ctype: 'CMRELYEARS',
  
      drpdwnSelected: [],
      drpdwn: [
        { name: 'Less-than-1-year', code: '1' },
        { name: '1-3-years', code: '2' },
        { name: '3-5-years', code: '3' },
        { name: '5-10-years', code: '4' },
        { name: '10-20-years', code: '5' },
        { name: 'More-than-20-years', code: '6' },
        { name: 'Unknown', code: '7' }
      ]
    },

     
    {
      crtl: 'div',
      grp: 'cntr',
      name: 'CONDROP',
      prefix: 'PB',
      id: 1,
      cls: ['CTWOPILLBOX','flex-container'],
      freeattr: [],
      attr: [],
      attrname: [`data-con`,`=`],
      attrval: ['aval999'],
      cnt: [],
      after: '',
      nonest: 1, 
    },
   
  
    {
      crtl: 'span',
      grp: 'cntr',
      name: 'CONDROP',
      prefix: 'LB',
      id: 1,
      cls: ['CTHREE', 'uk-label'],
      freeattr: [],
      attr: [`uk-icon="icon: chevron-down ; ratio: 0.6"`],
      attrname: [`data-con`,`=`],
      attrval: ['rot'],
      cnt: ['OTHER CONT'],
      after: '<br>' ,
      nonest: 1 , 
      
      ctype: 'CMRELYEARS',
  
      drpdwnSelected: [],
      drpdwn: [
        { name: 'Less-than-1-year', code: '1' },
        { name: '1-3-years', code: '2' },
        { name: '3-5-years', code: '3' },
        { name: '5-10-years', code: '4' },
        { name: '10-20-years', code: '5' },
        { name: 'More-than-20-years', code: '6' },
        { name: 'Unknown', code: '7' }
      ]

    },
  
    {
      crtl: 'div',
      grp: 'cntr',
      name: 'CONDROP',
      prefix: 'PB',
      id: 1,
      cls: ['CTHREEPILLBOX','flex-container'],
      freeattr: [],
      attr: [],
      attrname: [`data-con`,`=`],
      attrval: ['aval999'],
      cnt: [],
      after: '',
      nonest: 1, 
    },
   



    {
      crtl: 'div',
      grp: 'page',
      name: 'GRID-ONE',
      prefix: 'GD',
      id: 12,
      cls: [],
      freeattr: [],
      attr: ['uk-grid'],
      attrname: [`data-con`,`=`],
      attrval: ['aval999'],
      cnt: [],
      after: '' ,
      nonest: 0, 
    },
  
    {
      crtl: 'div',
      grp: 'page',
      name: 'CAL',
      prefix: 'GD',
      id: 3,
      cls: ['uk-width-1-3@m'],
      freeattr: [],
      attr: [],
      attrname: [`data-con`,`=`],
      attrval: ['aval999'],
      cnt: [],
      after: '' ,
      nonest: 0, 

    },
  
    {
      crtl: 'div',
      grp: 'page',
      name: 'CARD',
      prefix: 'C',
      id: 5,
      cls: ['uk-card', 'uk-card-default', 'uk-card-body'],
      freeattr: [],
      attr: [],
      attrname: [`data-con`,`=`],
      attrval: ['aval999'],
      cnt: [],
      after: '' ,
      nonest: 0, 
    }
  ]
  

};







//function runs this based on events, eg, page load , create layout for 'page'
//add contol, create cntrg function

function createContGroup(layoutObj,  key, val, rootEl ) {
 const arob = ArrObjCont(layoutObj.controls, key, val);
  // create the first elemet out of the loop
  //first element will always be a sibling of the root

  let  ht = htmStrg(arob[0] , layoutObj.wstate.Ctrlid  ).htmlstr;
  let  el = $inhtm(ht, 'beforeEnd', rootEl);
  for (let i = 1; i < arob.length; i++) {
   
    ht = htmStrg(arob[i] , layoutObj.wstate.Ctrlid  ).htmlstr;
    //nested or sibling
    if (arob[i].nonest ===1) {
      el = $inhtm(ht, 'beforeEnd', el.gel);
    } else el = $inhtm(ht, 'beforeEnd', el.firstEl);
    //add event listeners here
  }

  console.log(' layoutObj.wstate.Ctrlid +1  ' , layoutObj.wstate );
  return el; // return the element inserted {gel ,firstEl , lastEl   }
}



///helper function to add event listeners
// gets elemtnt, gets class name , gets funtion bname 
// if 1- return function , then add this event listener   , if 0 just add the event lister







//need options for returned fuction after instance 



  /*
  ele.addEventListener('click', e => {
    // decendents of the class should be included , this calles the parent class if the child class is missing
    let tel;
    // console.log(' ele functions  ', ele);
    //put loop here
    if (e.target.classList[0]) {
      tel = e.target;
    } else tel = e.target.parentElement;
    let we = Array.from(tel.classList);
    if (we[0] === clname) {
      //    let nee = funcTable[funcName](we[0])    ; //   let nee = functTable[cntgr[i].lisfunc](we[0]);
      funcTable[funcName](we[0])();
      //  console.log(' nee  ', nee, we[1]);
    }
  });

  */





function mapContrl(lyob, startel) {
  lyob.wstate.Ctrlid++;
  let el;
  let cntgr = lyob.main;
  let cnfirst = lyob.main[0];
  // let lycontrols = lyob.controls;
  console.log(cnfirst);
  let stel = $(startel);
  el = createContGroup(lyob, cnfirst.ky, cnfirst.val, stel); //root add event listener for this
  //if has a listen function- add it

  if (lyob.main[0].lisfunc) {
    addListentoControl(el.gel, cnfirst.clsnme, functTable, cnfirst.lisfunc);
  }

  //add event listener for root element
  for (let i = 1; i < cntgr.length; i++) {
    el = createContGroup(lyob, cntgr[i].ky, cntgr[i].val, el[cntgr[i].elm]);
    if (lyob.main[i].lisfunc) {
    addListentoControl(el.gel, cntgr[i].clsnme, functTable, cntgr[i].lisfunc)
    }
  }

  console.log('addListentoControl(el.gel, ', el.gel);

  // addListentoControl(el.gel, cnfirst.clsnme , functTable, cnfirst.lisfunc);
}




// function removeFromArray(original, remove) {
//   return original.filter(value => !remove.includes(value));
// }


///get infr from selected element 

function remFrArr(or, remove, objkey, mutate) {
  let original;
  if (mutate) {
    original = or;
  } else original = or.slice();
  for (let i = original.length - 1; i >= 0; i--) {
    for (let j = 0; j < remove.length; j++) {
      if (original[i] && original[i][objkey] === remove[j][objkey]) {
        original.splice(i, 1);
      }
    }
  }
  let named = original.map(nme => nme[objkey]);
  return { original, named, remove };
}

//collect class info



function drpmx(id, dropName, drpDivID, afterElemtId, containElemtId, drpArr, selArr) {
  const drpdwnIn = `<div id = '${drpDivID}' uk-dropdown="mode: click" > <ul id ="${dropName}-DROP-${id}" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
  const afterEl = $(afterElemtId);
  const containEl = $(containElemtId);
  const _drpDivID = drpDivID;
  let _id = id;
  let drpMulNoAuto = function() {
    let drparr = remFrArr(drpArr, selArr, 'name').original;
    let remDr = $(`${_drpDivID}`);
    if (remDr) {remDr.remove()}
    $inhtm(drpdwnIn, 'afterEnd', afterEl);
    let ctype = 'WIN';
    let filldrop = $(`${dropName}-DROP-${_id}`);
    for (let i = 0; i < drparr.length; i++) {
      filldrop.insertAdjacentHTML( 'beforeEnd',  `<li><a class ="${ctype} ${drparr[i].code} ${id}"  href="#" >${drparr[i].name}</a></li>` );
      UIkit.dropdown(`#${_drpDivID}`).show();
      filldrop.addEventListener('click', addMulNoAuto);
    }
  };
  function addMulNoAuto(e) {
  
    const pillname = e.target.innerHTML;
     e.currentTarget.parentNode.innerHTML = '';
    const pillBox = containEl;
    let seld = `<span class="closea">${pillname}<span id ='${pillname}' class="close ${pillname}">x</span></span>`;
    selArr.push({ name: pillname, code: 1 });
     $inhtm(seld, 'afterBegin', pillBox);
    pillBox.querySelector(`#${pillname}`).onclick = function(e) {
      selArr = remFrArr(selArr, [{ name: e.target.id ,  code: 1  }], 'name', 1).original; //put whatever code needed
      e.target.parentNode.remove();
    };
  }

  //make this return a function
  return drpMulNoAuto;
}





function T1() {
  mapContrl(lyOb, 'main-box-sel');
}

function T2() {}

function T3() {}


function T4() {


  // drpmx(id, dropName, drpDivID,  afterElemtId, containElemtId, drpArr, selArr)
  
  let inp = $$(`[data-con="rot01"]`)[0];
  let cntn = $$(`[data-con="testdr01"]`)[0];

  console.log( 'inp  ' ,  inp   );
  console.log( 'cntn  ' ,  cntn  );

//myArray = myArray.filter(ar => !toRemove.find(rm => (rm.name === ar.name && ar.place === rm.place) ))

  
let drpf =   drpmx(   100, 'firstdrop', 'MDB'  , inp ,   cntn ,    jew.drpdwn,  jew.drpdwnSelected  ) 

inp.addEventListener('click', drpf );
    


}

// this is the gateway for functions
let functTable = {
  doit: function(clsparm) {
    return function() {
      console.log(`ran  doit  plus ${clsparm}`);
    };
  },

  doitagain: function(clsparm) {
    console.log('i ran here once ', clsparm);

    return function() {
      console.log(`ran  doitagain  plus ${clsparm}`);
    };
  },

  CONE: function(elmt , e ) {

    //takes whatever here for the element and uses that for the functions

    return 'ran control one ok : ' + elmt.dataset.sex;
  }
};



function T5() {
  // need the right cal bacxk here thaty gets the elemet stuff and uses it
  //cb function takes in what it needs , all the id stuff etc as a commn for all

  //event

  function testcall(element) {
    // get list of class stuff

    console.log('elementslist[i].classList : ', element.classList);
    //let sib = getNextSibling(cntrls[i], `.${cntrls[i].classList[0]}`); //incase you need a next div box
    console.log(' cntrls[i].dataset ', element.dataset);

    function xx(e) {

     console.log('in fucttion  ', element.dataset, e.target.innerHTML);
      let tf =functTable.doitanothertime('wow' )
      console.log('tf ',tf );

    }

    element.addEventListener('click', xx);

  }



  function addfunctgrp (element   ) {
    // get list of class stuff
    // element that will add the function listener 
    // funcName : string function name within object e.g. ' doitanothertime'

    // console.log('elementslist[i].classList : ', element.classList);
    // //let sib = getNextSibling(cntrls[i], `.${cntrls[i].classList[0]}`); //incase you need a next div box
    // console.log(' cntrls[i].dataset ', element.dataset);

    function wrapListener (e) {

     console.log('in fucttion  ', element.dataset, e.target.innerHTML);
      let tf =functTable[element.classList[0]](element, e)
      console.log('tf ',tf );

    }

    element.addEventListener('click', wrapListener ) ;
  }





  function lisntoCntrGrp(cntrlWrapEle, commClassName, funct) {
    // commClassName : group class name or common selector for group
    // cntrlWrapEle : parent elemnt
    // funct : callback for each control , then adds listener based on controls

    let cntrls = $$(commClassName, cntrlWrapEle);

    for (let i = 0; i < cntrls.length; i++) {
      funct(cntrls[i]);
    }
  }

  let ne = $('main-box-sel');

  lisntoCntrGrp(ne, '.CONE',  addfunctgrp );
}




let jokex = [
  {
    crtl: 'div',
    grp: 'xxx',
    name: 'PARRA',
    prefix: 'P',
    id: 5,
    statcnt: [],
    cls: ['uk-card', 'uk-card-default', 'uk-card-body'],
    freeattr: [],
    attr: [],
    attrname: [`data-con`, `=`],
    attrval: ['aval999'],
    cnt: [    {
      crtl: 'span',
      grp: 'cntr',
      name: 'CONDROP', //names always used to get thclsnmee group of elemts this is attached first to the classlist
      prefix: 'LB',
      id: 1,
      statcnt: ['FAGG'],
      cls: ['CONE', 'uk-label'],
      freeattr: [],
      attr: [`uk-icon="icon: chevron-down ; ratio: 0.6"`],
      attrname: [`data-con`,`=`],
      attrval: ['rot01'],
      cnt: [],
      after: ['<br>'],
      nonest: 1, 
      ctype: 'CMRELY',
      drpdwnSelected: [],
      drpdwn: [
        { name: 'Less-than-1-year' },
        { name: '1-3-years' },
        { name: '3-5-years' },
        { name: '5-10-years' },
        { name: '10-20-years' },
        { name: 'More-than-20-years' },
        { name: 'Unknown'}
      ]
    }
,
    
    {
      crtl: 'div',
      grp: 'cntr',
      name: 'CONDROP',
      prefix: 'PB',
      id: 1,
      statcnt: [],
      cls: ['CTWOPILLBOX','flex-container'],
      freeattr: [],
      attr: [],
      attrname: [`data-con`,`=`],
      attrval: ['aval999'],
      cnt: [],
      after: '',
      nonest: 1, 
    }
   

    ,
    {
      crtl: 'span',
      grp: 'cntr',
      name: 'CONDROP', //names always used to get thclsnmee group of elemts this is attached first to the classlist
      prefix: 'LB',
      id: 1,
      statcnt: ['NIGRO'],
      cls: ['CONE', 'uk-label'],
      freeattr: [],
      attr: [`uk-icon="icon: chevron-down ; ratio: 0.6"`],
      attrname: [`data-con`,`=`],
      attrval: ['rot01'],
      cnt: [],
      after: ['<br>'],
      nonest: 1, 
      ctype: 'CMRELY',
      drpdwnSelected: [],
      drpdwn: [
        { name: 'Less-than-1-year' },
        { name: '1-3-years' },
        { name: '3-5-years' },
        { name: '5-10-years' },
        { name: '10-20-years' },
        { name: 'More-than-20-years' },
        { name: 'Unknown'}
      ]
    }

  ]
  } 
          
      
  
];


function T6() {

  console.log(jokex[0]['cnt']);

}






function T7() {

 

  function htmStrg(cfgobj, idx) {
    let { crtl, name, prefix, cls, attr,  after , statcnt, attrname  ,attrval  } = cfgobj;
    let tag = `<${crtl} ${mpto(attr,' ')} ${mpto(attrname,' ')}${mpto(attrval,' ')} id="${prefix}-${idx}" class ="${mpto(name,' ')} ${mpto(cls,' ')}">${mpto(statcnt, ' ')}`;
    let tagaft = `</${crtl}>${mpto(after, ' ')}`;
    let htmlstr = `${tag}${tagaft}`;
    return { htmlstr, tag, tagaft };
  }
  

  //1. add single function to element or add listener to group



  function wr(list, next, rootel) {
    let el = $(rootel);
    let count = 0;
    let poo = [];
    function printList(list) {
      for (let i = 0; i < list.length; i++) {
        count++;
        let strn = htmStrg(list[i], count).htmlstr;
        poo.push(list[i]);
        if (list[i].cnt.length == 0) {
          el = $inhtm(strn, 'beforeEnd', el).gel;
        
        } else {
          el = $inhtm(strn, 'beforeEnd', el).firstEl;
         
        }
        if (list[i].hasOwnProperty(next)) {
          printList(list[i][next]);
        }
      }
    }
    printList(list); // starts here runs inthe function until it exits
    return { poo, el };
  }

  let ss = wr(jokex, 'cnt', 'main-box-sel');

  console.log('ss ', ss);
//  let nene =$(ss.el )
 // console.log('nene ',nene);

}



function T8() {



  let jokexxx = [

    {
      crtl: 'div',
      name: 'PARRA',
      statcnt: [],
      cls: ['uk-card', 'uk-card-default', 'uk-card-body'],
      freeattr: [],
      attr: [],
      attrname: [],
      attrval: [],
      cnt: [    {
        crtl: 'span',
        grp: 'cntr',
        name: 'CONDROP', //names always used to get thclsnmee group of elemts this is attached first to the classlist
        prefix: 'LB',
        id: 1,
        statcnt: ['FAGG'],
        cls: ['CONE', 'uk-label'],
        freeattr: [],
  
        cnt: [],
        after: ['<br>'],
        nonest: 1, 
        ctype: 'CMRELY',
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Less-than-1-year' },
          { name: '1-3-years' },
          { name: '3-5-years' },
          { name: '5-10-years' },
          { name: '10-20-years' },
          { name: 'More-than-20-years' },
          { name: 'Unknown'}
        ]
      }
  ,
      
      {
        crtl: 'div',
        grp: 'cntr',
        name: 'CONDROP',
        prefix: 'PB',
        id: 1,
        statcnt: [],
        cls: ['CTWOPILLBOX','flex-container'],
        freeattr: [],
        attr: [],
        attrname: [`data-con`,`=`],
        attrval: ['aval999'],
        cnt: [],
        after: '',
        nonest: 1, 
      }
     
      ,

      {			
        crtl	:	['div']	,
        name	:	[]	,
        statcnt	:	[]	,
        cls	:	[]	,
        freeattr	:	[]	,
        dattr	:	[]	,
        after	:	[]	,
        cnt	:	[]	,
        }			
        
        
      ,
      {
        crtl: ['span'],
        grp: ['cntr'],
        name: ['CONDROP'], //names always used to get thclsnmee group of elemts this is attached first to the classlist
        prefix: ['LB'],
        id: 1,
        statcnt: ['NIGRO'],
        cls: ['CONE', 'uk-label'],
        freeattr: [],
        attr: [`uk-icon="icon: chevron-down ; ratio: 0.6"`],
        attrname: [`data-con`,`=`],
        attrval: ['rot01'],
        cnt: [],
        after: ['<br>'],
        nonest: 1, 
        ctype: ['CMRELY'],
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Less-than-1-year' },
          { name: '1-3-years' },
          { name: '3-5-years' },
          { name: '5-10-years' },
          { name: '10-20-years' },
          { name: 'More-than-20-years' },
          { name: 'Unknown'}
        ]
      }
  
    ]
    } 
            
        
    
  ];

  let jokexx = [
    {
      crtl: 'div',
      name: 'PARRA',
      statcnt: [],
      cls: ['uk-card', 'uk-card-default', 'uk-card-body'],
      cnt: [
        {
          crtl: ['span'],
          name: ['CONE'],
          statcnt: ['TRYNAME'],
          cls: ['uk-label'],
          freeattr: [],
          dattr: [
            { datattr: 'data-sex', val: 'lit' },
            { datattr: 'uk-icon', val: 'icon: chevron-down ; ratio: 0.6' },
            { datattr: 'uk-byee' }
          ],
          after: ['<br>'],
          cnt: [],
          drpdwnSelected: [],
          drpdwn: [
            { name: 'Less-than-1-year' },
            { name: '1-3-years' },
            { name: '3-5-years' },
            { name: '5-10-years' },
            { name: '10-20-years' },
            { name: 'More-than-20-years' },
            { name: 'Unknown'}
          ]

        },
        {
          crtl: ['span'],
          name: ['CONE'],
          statcnt: ['TOO BASIC'],
          cls: ['uk-label'],
          freeattr: [],
          dattr: [
            { datattr: 'data-sex', val: 'lit' },
            { datattr: 'uk-icon', val: 'icon: chevron-down ; ratio: 0.6' },
            { datattr: 'uk-byee' }
          ],
          after: ['<br>'],
          cnt: []
        }

      ]
    }
  ];



  function htmStrgx(cfgobj, idx ) {
    let { crtl, name,  cls,  after , statcnt , dattr } = cfgobj;
    let tag = `<${crtl} ${mpto(dattr,' ')} class ="${mpto(name,' ')} ${mpto(cls,' ')}">${mpto(statcnt, ' ')}`;
    let tagaft = `</${crtl}>${mpto(after, ' ')}`;
    let htmlstr = `${tag}${tagaft}`;
    return { htmlstr, tag, tagaft };
  }
  

  //1. add single function to element or add listener to group



  function wr(list, next, rootel , cbhtml ) {
    let el = $(rootel);
    let count = 0;
    let poo = [];
    function printList(list) {
      for (let i = 0; i < list.length; i++) {
        count++;
        let strn = cbhtml(list[i], count).htmlstr;
        poo.push(list[i]);
        if (list[i].cnt.length == 0) {
          el = $inhtm(strn, 'beforeEnd', el).gel;
        } else {
          el = $inhtm(strn, 'beforeEnd', el).firstEl;
        }
        if (list[i].hasOwnProperty(next)) {
          printList(list[i][next]);
        }
      }
    }
    printList(list); // starts here runs inthe function until it exits
    return { poo, el };
  }

  let ss = wr(jokexx, 'cnt', 'main-box-sel' , htmStrgx);

  console.log('ss ', ss);


  //create a function that returns a function that gets added tro the list of contrls



}









function T9() {

//[...document.querySelectorAll('div')]

  function addLis(ele) {
   
    let xtest = $$(`[data-con="rot"]`, ele);
    console.log(xtest);
    let drpf;
    for (let i = 0; i < xtest.length; i++) {
      console.log('do something here instantite function based on class name : ', xtest[i].classList);
      let sib = getNextSibling(xtest[i], `.${xtest[i].classList[0]}`);  //incase you need a next div box
      let xt = $(xtest[i]);

   //configure function
   //   drpf = drpmx(100, 'firstdrop', 'MDB', xt, sib, jew.drpdwn, jew.drpdwnSelected);
   //   xtest[i].onclick = drpf;

    }
  }
  
  let ne =$ ( 'main-box-sel' )
  addLis(ne )

}



function T10() {


  function htmStrg(cfgobj, idx) {
    let { crtl, name,  cls, cnt, after , drpdwn } = cfgobj;
    let tag = `<${crtl} ${mpto(drpdwn,' ')} class ="${mpto(name,' ')} ${mpto(cls,' ')}">${cnt}`;
    let tagaft = `</${crtl}>${after}`;
    let htmlstr = `${tag}${tagaft}`;
    return { htmlstr, tag, tagaft };
  }
  

  //get data-atribute and use that to get the state pf the elemnt

  function xc(...we) {
    let w = we;
    return w;
  }


  console.log(xc([1, 2, 3, 4, 5, 6]));


let w =
{
  crtl: ['span'],
  grp: ['cntr'],
  name: ['CONDROP'], //names always used to get thclsnmee group of elemts this is attached first to the classlist
  prefix: ['LB'],
  id: 1,
  statcnt: ['NIGRO'],
  cls: ['CONE', 'uk-label'],
  freeattr: [],
  attr: [`uk-icon="icon: chevron-down ; ratio: 0.6"`],
 
  cnt: [],
  after: ['<br>'],
  nonest: 1, 
  ctype: 'CMRELY',
  drpdwnSelected: [],
  drpdwn: [
    { datattr: 'data-sex', val: 'lit' },
    { datattr: 'uk-icon' , val: 'icon: chevron-down ; ratio: 0.6'  },
    { datattr: 'uk-byee'  }
  
  ]
}





let c =   mpto (   w.drpdwn  , ' '   );

console.log( 'c ' , c);

 let d =    htmStrg( w , 100).htmlstr

console.log( 'd ' , d);




}

document.querySelector('#T1').addEventListener('click', T1);
document.querySelector('#T2').addEventListener('click', T2);
document.querySelector('#T3').addEventListener('click', T3);
document.querySelector('#T4').addEventListener('click', T4);
document.querySelector('#T5').addEventListener('click', T5);
document.querySelector('#T6').addEventListener('click', T6);
document.querySelector('#T7').addEventListener('click', T7);
document.querySelector('#T8').addEventListener('click', T8);
document.querySelector('#T9').addEventListener('click', T9);
document.querySelector('#T10').addEventListener('click', T10);
