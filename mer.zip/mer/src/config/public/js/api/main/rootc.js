
/* eslint-disable */


var getNextSibling = function(elem, selector) {
  // Get the next sibling element
  var sibling = elem.nextElementSibling;

  // If there's no selector, return the first sibling
  if (!selector) return sibling;

  // If the sibling matches our selector, use it
  // If not, jump to the next sibling and continue the loop
  while (sibling) {
    if (sibling.matches(selector)) return sibling;
    sibling = sibling.nextElementSibling;
  }
};

/*!
 * Get an array of all matching elements in the DOM
 * (c) 2019 Chris Ferdinandi, MIT License, https://gomakethings.com
 * @param  {String} selector The element selector
 * @param  {Node}   parent   The parent to search in [optional]
 * @return {Array}           The elements
 */
var $$ = function(selector, parent) {
  return Array.prototype.slice.call((parent ? parent : document).querySelectorAll(selector));
};

var $_ = function(selector, parent) {
  return (parent ? parent : document).querySelector(selector);
};

//returns an elemnt with vals

function getatrvals(subarr, objkey, keyval, el) {
  let mp = ArrObjCont(subarr, objkey, 'data-id');
  let eltrue = el.querySelector(`[${mp[0][objkey]}="${mp[0][keyval]}"]`);
  return eltrue;
}


function isElement(o) {
  return typeof HTMLElement === 'object'
    ? o instanceof HTMLElement //DOM2
    : o && typeof o === 'object' && o !== null && o.nodeType === 1 && typeof o.nodeName === 'string';
}

let $ = function(selector, parent) {
  return isElement(selector) ? selector : (parent ? parent : document).querySelector(`#${selector}`);
};

function htmStrg(cfgobj, idx) {
  let { crtl, name, prefix, cls, attr, cnt, after, attrname, attrval } = cfgobj;
  let tag = `<${crtl} ${mpto(attr, ' ')} ${mpto(attrname, ' ')}${mpto( attrval,' ' )} 
  id="${prefix}-${idx}" class ="${mpto(name, ' ')} ${mpto(cls, ' ')}">${cnt}`;
  let tagaft = `</${crtl}>${after}`;
  let htmlstr = `${tag}${tagaft}`;
  return { htmlstr, tag, tagaft };
}


function htmStrgx(cfgobj, idx ) {
  let { crtl, name,  cls,  after , statcnt , dattr } = cfgobj;
  let tag = `<${crtl}  id="${name}-${idx}" ${mpto(dattr,' ')} class ="${mpto(name,' ')} ${mpto(cls,' ')}">${mpto(statcnt, ' ')}`;
  let tagaft = `</${crtl}>${mpto(after, ' ')}`;
  let htmlstr = `${tag}${tagaft}`;
  return { htmlstr, tag, tagaft };
}

function getFirstChild(el) {
  var firstChild = el.firstChild;
  while (firstChild != null && firstChild.nodeType == 3) {
    // skip TextNodes
    firstChild = firstChild.nextSibling;
  }
  return firstChild;
}

//helper for inserting html
function $inhtm(html, pos, element) {
  const gel = $(element);
  gel.insertAdjacentHTML(pos, html);
  const firstEl = getFirstChild(gel);
  const lastEl = gel.lastElementChild;
  return { gel, firstEl, lastEl };
}

function remFrArr(or, remove, objkey, mutate) {
  let original;
  if (mutate) {
    original = or;
  } else original = or.slice();
  for (let i = original.length - 1; i >= 0; i--) {
    for (let j = 0; j < remove.length; j++) {
      if (original[i] && original[i][objkey] === remove[j][objkey]) {
        original.splice(i, 1);
      }
    }
  }
  let named = original.map(nme => nme[objkey]);
  return { original, named, remove };
}


//helper for extracting vaues out of arrays into single strings
//if values is string or number just return
// obkeyname - if has another object , ADD THIS NI OPTIONAL
//if value is array return as joined string
//if array has objects return the values from the key string name, if not return all vales in object

// typeof inp !== "undefined" && (typeof inp !== "object" || !inp)

let mpto = function(inp, joinvalue, obkeyname) {
  let ky;
  let vl;

  if (typeof inp === 'undefined' || typeof inp !== 'object' || !inp) {
    return '';
  } else
    return typeof inp === 'string' || typeof inp === 'number' // ||  typeof inp ==="undefined"
      ? inp
      : //string of object key name
        inp
          .map(function(part) {
            if (typeof inp[0] === 'object') {
              if (Object.values(part).length > 1 && Object.keys(part)[0] == 'datattr') {
                ky = Object.values(part)[0];
                vl = Object.values(part)[1];
                return `${ky} = "${vl}"`;
              }

              if (obkeyname) {
                return Object.values(part[obkeyname]).join(joinvalue);
              } else return Object.values(part).join(joinvalue);
            }
            return part;
          })
          .join(joinvalue);
};

//if the key value matches the objects in the arry return the object selected
//returns all the objects that match the key val so need to [ ] to get the single object
//arr - array of objects
//key - key of object to select
//value of that key to select

function ArrObjCont(arr, key, value) {
  let ar = arr.filter(function(obj) {
    if (obj[key].includes(value)) {
      return obj;
    }
  });
  return ar;
}




//create controlgroup from object 
// let ss = createCntrlGrp(jokexx, 'cnt', 'main-box-sel' , htmStrgx);
// list : the object you want
// next : the container object you want  
//


// function getatrvals(subarr, objkey, keyval, el) {
//   let mp = ArrObjCont(subarr, objkey, 'data-id');
//   let eltrue = el.querySelector(`[${mp[0][objkey]}="${mp[0][keyval]}"]`);
//   return eltrue;
// }


function addfunctgrpx(element, obj , functab ) {
  // get list of class stuff
  // element that will add the function listener
  // funcName : string function name within object e.g. ' doitanothertime'
  // console.log('elementslist[i].classList : ', element.classList);
  // let sib = getNextSibling(cntrls[i], `.${cntrls[i].classList[0]}`); //incase you need a next div box
  // console.log(' cntrls[i].dataset ', element.dataset);
  // existing state, i.e. dropdowns selected, get added to the executed funtion, iffee here e.g.    addpill(e.target.innerHTML, containEl, selArr , 'single');

  //cntfx - control function generate a control inside another control div. 
  let cntfx = mpto(obj.cntfuct);  //this is run after the control to add to it e.g slider 
  let evfx = mpto(obj.evfuct);
 
  //  if it has a function to generate a control inside A DIV WRAPPER then run this

  if (cntfx) {
    let cntF = functab[cntfx];
    //    let cntF = functTable[cntfx];

    if (typeof cntF === 'function') {
      let sf = cntF(element, obj);
      sf();
    }
  }
  
  //1. returns a value for display or executes another function
  //2. return a function, for exection now of later
  //if it has an event functrion add it as a listener

  if (evfx) {
    function wrapListener(e) {
      //console.log('in fucttion  ', element.dataset, e.target.innerHTML);

      //this is the function in the list  e.g.   DROPTEST: function(elmt , e ) {}addfunctgrpx(
      //  functTable['stringfunctionNAME'](element, e)
      // pass the element itself + the event info + the info from the object

      //let tf =functTable[element.classList[0]](element, e , obj)

      let tf = functab[evfx](element, obj ,e );

      if (typeof tf === 'function') {
        tf();
      }
    }

    element.addEventListener(mpto(obj.evtype), wrapListener);
  }

 // let statefx = mpto(obj.statefuct); 
  // if (statefx) {
  //   let stF = functTable[statefx];

  //   if (typeof stF === 'function') {
  //     let sfx = stF(element, obj);
  //     sfx();
  //   }
  // }

}


//createCntrlGrpx(jokexx, 'cnt', 'main-box-sel' , htmStrgx , addfunctgrpx);
// list - array of objectr required for controls in page 
// next - the name of the object to go to in the recursive 'cnt'
// rootel -the rot element to start from , should be already on the page 
// cbhtml - the callback function the creates the control from each 'cnt' object in the aray list
// funct - the cb function thar adds the event listeners from another list of functions , that should also add ieff () for controls that require funcxtions that create controls eg. sliders
// CNTRGRP id for the control group

let CNTRGRP =99 ;

function createCntrlGrpx(list, next, rootel, cbhtml, funct, functab) {
  let el = $(rootel);
  CNTRGRP++;
  console.log('first el ', el);
  let count = 99;
  let elnames = [];
  let elinfo = [];
  function printList(list) {
    for (let i = 0; i < list.length; i++) {
      count++;

      //create the html string for later insertion using aan object to html string cb funct
      let strn = cbhtml(list[i], count).htmlstr;

      //save the list of elemet names that were created
      elnames.push(list[i]);
      // elnames.push(list[i].name);

      //from the object used to create the elemt , gets its datattr
      //example :
      // dattr: [
      //   { datattr: 'data-id', val: 'dark' },
      //   { datattr: 'uk-icon', val: 'icon: chevron-down ; ratio: 0.6' },
      //   { datattr: 'uk-byee' }
      // ],
      let mp = ArrObjCont(list[i].dattr, 'datattr', 'data-id');
      //mp =  [ {datattr: "data-id", val: "PILLBOX"}

      if (list[i].cnt.length == 0) {
        // if this is the last control object , then get the gel
        el = $inhtm(strn, 'beforeEnd', el).gel;

        //add a class to identify the control group e.g CNGRP-100

        el.classList.add(`CTRGP-${CNTRGRP}`);

        //check if the elemt has a data atribute
        let eltrue = el.querySelector(`[${mp[0].datattr}="${mp[0].val}"]`);
        // e.g. turns to let eltrue = el.querySelector(`[data-id="PILLBOX");

        console.log('eltrue ', eltrue);
        //add event listener here

        if (eltrue) {
          console.log('eltrue ', eltrue);
          eltrue.classList.add(`CTRGP-${CNTRGRP}`);

          funct(eltrue, list[i], functab);
          elinfo.push({ elm: eltrue, obj: list[i] }); //keep a ref of the ele and object for updating the save frunction
        }
      } else {
        el = $inhtm(strn, 'beforeEnd', el).firstEl;

        let eltrue = el.querySelector(`[${mp[0].datattr}="${mp[0].val}"]`);

        if (eltrue) {
          console.log('eltrue ', eltrue);
          eltrue.classList.add(`CTRGP-${CNTRGRP}`);
          funct(eltrue, list[i], functab);

          //funct(eltrue, list[i]);

          //   functab

          elinfo.push({ elm: eltrue, obj: list[i] });
        }
      }
      if (list[i].hasOwnProperty(next)) {
        printList(list[i][next]);
      }
    }
  }
  printList(list); // starts here runs in the function until it exits

  return { el, elnames, elinfo };
  //el; the parent elemt / control just below the root el.
  //elnames - alist of names of each control
}




// function drpvauto(drpArr, selArr, afterEl, containEl, inputEl, drpdwnIn, drpDivID, id, cb) {
// //you hsvr 2 arrays
// //1. Dropdown array - drparr - this is used in the dropdown list box.

//   return function() {
//     let drparr = remFrArr(drpArr, selArr, 'name').original;
//     let remDr = $(`${drpDivID}`);

    
//     console.log('remdr ',remDr );

//     if (remDr) {
//       remDr.remove();
//     }
//     $inhtm(drpdwnIn, 'afterEnd', afterEl);

//     let filldrop = $(`${drpDivID}-DROP-${id}`);
//     if (inputEl.tagName == 'INPUT') {
//       console.log('inputEl', inputEl.tagName);
//       let val = inputEl.value.toUpperCase();

//       if (val.length > 0) {
//         for (let i = 0; i < drparr.length; i++) {
//           let mm =drparr[i].name.toUpperCase() 
//           if (mm.substr(mm.indexOf(val), val.length) == val) {
//             filldrop.insertAdjacentHTML(
//               'beforeEnd',
//               `<li><a class ="${drparr[i].name}"  href="#" >${drparr[i].name}</a></li>`
//             );
//             UIkit.dropdown(`#${drpDivID}`).show();
//             filldrop.addEventListener('click', cb);
//           }
//         }
//       } else if (remDr) {
//         remDr.remove();
//       }
//     }


//       for (let i = 0; i < drparr.length; i++) {
//         filldrop.insertAdjacentHTML(
//           'beforeEnd',
//           `<li><a class ="${drparr[i].name}"  href="#" >${drparr[i].name}</a></li>`
//         );
//         UIkit.dropdown(`#${drpDivID}`).show();
//         filldrop.addEventListener('click', cb);
//       } 


//     }
  
// }


//need a function thats takes the pill stuff and then puts the pills in all while adding even listener

function addpill(pillname, pillBox, selArr, drptype) {
  let seld = `<span class="closea">${pillname}<span id ='${pillname}' class="close ${pillname}">x</span></span>`;
  //if its a single select, just get rid of the existing pill , and clear the select array 
  if (drptype == 'single') {
    selArr.splice(0, selArr.length);
    let pill = pillBox.querySelector('span');
    if (pill) {
      pill.remove();
    }
  }
  // after the addpill is executed, push the name into the select arry + instert the pill into the poillbox , ie div
  selArr.push({ name: pillname });
  $inhtm(seld, 'afterBegin', pillBox);

  // also add an event handler to the pill, the cross, this clears that pill from the select array, ie the array that fills the 'select' array 
  pillBox.querySelector(`#${pillname}`).onclick = function(e) {
    selArr = remFrArr(selArr, [{ name: e.target.id }], 'name', 1).original;
    e.target.parentNode.remove();
  };
}


function addpillstate(elmt, obj) {
  let selArr = obj.drpdwnSelected;
  const containEl = elmt.parentElement.querySelector(
    `[data-rel="${ArrObjCont(obj.dattr, 'datattr', 'data-id')[0].val}"]`
  );

  //if singlr add one pill, if multi add array
  return function() {
    addpill('Less-than-1-year', containEl, selArr, 'single');
  };
}


//new version of drop

//returns a function that becomes an event handler fro dropdowns  evfuct: ['DROP'],
//let functTable = { DROP: drp}
// if (evfx) { function wrapListener(e) {
//this is the function in the list  e.g.   DROPTEST: function(elmt , e ) {}addfunctgrpx(
//  functTable['stringfunctionNAME'](element, e)
   // pass the element itself + the event info + the info from the object
    //let tf =functTable[element.classList[0]](element, e , obj)
//let tf = functab[evfx](element, obj ,e );
   // if (typeof tf === 'function') {
   //  tf();
 // element.addEventListener(mpto(obj.evtype), wrapListener);


let drp = function drpmx(elmt, obj) {
  let drpDivID = `${ArrObjCont(obj.dattr, 'datattr', 'data-id')[0].val}`;
  let drpArr = obj.drpdwn;
  let selArr = obj.drpdwnSelected;
  //const inputEl = elmt;
  const afterEl = elmt;
  const containEl = elmt.parentElement.querySelector(`[data-rel="${drpDivID}"]`);
  const drpdwnIn = `<div id = '${drpDivID}-${elmt.id}' uk-dropdown="mode: click" > <ul id ="${drpDivID}-${elmt.id}-DROP" class="uk-nav uk-dropdown-nav"> </ul>  </div>`;

  function drpvauto(cb) {
    //you hsvr 2 arrays
    //1. Dropdown array - drparr - this is used in the dropdown list box.
    return function() {
      let drparrList = remFrArr(drpArr, selArr, 'name').original;
      let remDr = $(`${drpDivID}-${elmt.id}`); //remDr  - dropdown list in html 
      if (remDr) {
        remDr.remove();
      }
      $inhtm(drpdwnIn, 'afterEnd', afterEl);
      let filldrop = $(`${drpDivID}-${elmt.id}-DROP`);
      for (let i = 0; i < drparrList.length; i++) {
        filldrop.insertAdjacentHTML(
          'beforeEnd',
          `<li><a class ="${drparrList[i].name}"  href="#" >${drparrList[i].name}</a></li>`
        );
        UIkit.dropdown(`#${drpDivID}-${elmt.id}`).show();
        filldrop.addEventListener('click', cb);
      }
    };
  }

  function addp(e) {
    e.currentTarget.parentNode.innerHTML = '';
    addpill(e.target.innerHTML, containEl, selArr, 'single');
  }

  let drpf = drpvauto(addp);

  return drpf; //returns a function
};





//   slider array, e,g const YMARR = []; ["201710", "201711", "201712", "201801", "201802", "201803"]
// sliderEl -element of the div
//


function sliderN(slideObj, minEl, maxEl, sldArr, sliderEl) {
  let sldArr_ = sldArr;
  const startSlider = $(sliderEl);
  noUiSlider.create(startSlider, slideObj);

  const marginMin = $(minEl); // the pill with thats gets the first knob value
  const marginMax = $(maxEl); // the pill with thats gets the second knob value

  //add function to update pilss on chanmge of handle
  startSlider.noUiSlider.on('update', function(values, handle) {
    //if you are preessing handle a it will bve 0, if handle b it will be 1

    if (handle) {
      //could be 0 or 1  in this case its 1
      marginMax.innerHTML = sldArr_[Math.trunc(values[handle])]; //datesrg[Math.trunc(values[handle]) ]; orginal value is e.g 20.0, need to make this '2'
    } else {
      marginMin.innerHTML = sldArr_[Math.trunc(values[handle])];
    }
  });
  //in case you need to set something here
  // startSlider.noUiSlider.set();
}


function getconattrb ( elmt, obj , key , objar , objarkey , objarkeyn , objarval   )  {


//( elmt, obj , 'data-id' ,'dattr ', 'datattr', 'data-frm' , 'val'  )  
 return elmt.parentElement.querySelector(`[${key}="${ArrObjCont(obj[objar], objarkey, objarkeyn )[0][objarval]}"]`);

//elemt current elemt that is passed in e.g. slider div
//<div id="slider-108" data-id="SLIDER" data-frm="FROMDATE" data-to="TODATE" class="slider">

//i want to find this element 
 // <span id="FRDTE-106" data-id="FROMDATE" class="FRDTE closeb CTRGP-100">201712</span>
 // using this array of objects
 //   dattr: [
  //     { datattr: 'data-id', val: 'SLIDER' },
  //     { datattr: 'data-frm', val: 'FROMDATE' },...........................
  //     { datattr: 'data-to', val: 'TODATE' }
  //   ],
  //i will create this: elmt.parentElement.querySelector ( [data-id="FROMDATE"]  )


 // const minEl = elmt.parentElement.querySelector(`[data-id="${ArrObjCont(obj.dattr, 'datattr', 'data-frm')[0].val}"]`);

 // elmt.parentElement.querySelector(`[data-rel="${ArrObjCont(obj.dattr, 'datattr', 'data-id')[0].val}"]`);
  //elmt.parentElement.querySelector ( [data-id="FROMDATE"]  )
  
}



let sldx = function sld(elmt, obj) {
  let sldArr = obj.sldarr;
  let sliderEl = elmt;
  let slideObj = obj.sldint;
  //minEl : where you are going to put the value of the min amount from the slider handle
  //in this case the find the pill elemt min via thios queryselector
  //but you use the slider obj div, to then find the pill
 const minEl = elmt.parentElement.querySelector(`[data-id="${ArrObjCont(obj.dattr, 'datattr', 'data-frm')[0].val}"]`);
   
  const minElx =  getconattrb ( elmt, obj , 'data-id' ,'dattr', 'datattr', 'data-frm' , 'val'  ) 

  //this becomes  elmt.parentElement.querySelector ( [data-id="FROMDATE"]  )
  console.log('minelx ', minElx);
 // console.log('query sel slider ' , `[data-id="${ArrObjCont(obj.dattr, 'datattr', 'data-frm')[0].val}"]` );
  // {
  //   crtl: ['div'],
  //   name: ['slider'],
  //   statcnt: [],
  //   cntfuct: ['SLIDE'],
  //   evfuct: [],
  //   evtype: [],
  //   cls: ['sc'],
  //   freeattr: [],
  //   dattr: [
  //     { datattr: 'data-id', val: 'SLIDER' },
  //     { datattr: 'data-frm', val: 'FROMDATE' },...........................
  //     { datattr: 'data-to', val: 'TODATE' }
  //   ],





  //this will find pill:
  // {
  //   crtl: ['span'],
  //   name: ['FRDTE'],
  //   statcnt: [], 
  //   evfuct: [],
  //   evtype: [],
  //   cls: ['closeb'],
  //   freeattr: [],
  //   dattr: [{ datattr: 'data-id', val: 'FROMDATE' }],
  //   after: [],
  //   cnt: []
  // },
  // },



  const maxEl = elmt.parentElement.querySelector(`[data-id="${ArrObjCont(obj.dattr, 'datattr', 'data-to')[0].val}"]`);
  let sld_ = function() {
    sliderN(slideObj, minEl, maxEl, sldArr, sliderEl);
  };
  return sld_;
};

// this is the gateway for functions

let functTable = {

  DROP: drp,

  SLIDE: sldx  ,

  ADDPLST : addpillstate  ,

  doit: function(clsparm) {
    return function() {
      console.log(`ran  doit  plus ${clsparm}`);
    };

  },

  doitagain: function(clsparm) {

    console.log('i ran here once ', clsparm);

    return function() {
      console.log(`ran  doitagain  plus ${clsparm}`);
    };
  },

  CONEx: function(elmt, e, obj) {
    //takes whatever here for the element and uses that for the functions
    //you can use e =event too :)
    console.log('event ', e.currentTarget);
    console.log('element ', elmt);

    return 'ran control one ok : ' + elmt.dataset.id + ' ' + obj.name;
  },

  CONE: function(elmt, e, obj) {
    function xx() {
      return 'ran control one ok : ' + elmt.dataset.id + ' ' + obj.name;
    }

    return xx;
  },

  DROPTEST: function(elmt, e, obj) {
    //takes whatever here for the element and uses that for the functions
    //you can use e =event too :)

    return 'ran control one ok : ' + elmt.dataset.id;
  }
};


function lisntoCntrGrp(cntrlWrapEle, commClassName, funct) {
  // commClassName : group class name or common selector for group
  // cntrlWrapEle : parent elemnt
  // funct : callback function  for each control , then adds listener based on controls

  let cntrls = $$(commClassName, cntrlWrapEle);

  for (let i = 0; i < cntrls.length; i++) {
    funct(cntrls[i]);
  }
}

//needed for dropdown  document.querySelector("#PILLBOX-102")

let jokexx = [
  {
    crtl: ['div'],
    name: ['PARRA'],
    statcnt: [],
    evfuct: [],
    cls: ['uk-card', 'uk-card-default', 'uk-card-body'],
    freeattr: [],
    dattr: [{ datattr: 'data-id', val: 'card' }],
    after: [],
    cnt: [
      {
        crtl: ['span'],
        name: ['CONE'],
        statcnt: ['TRYNAME'],
        evfuct: ['DROP'],
        evtype: ['click'],
        cntfuct: [],
        statefuct: ['ADDPLST'],
        cls: ['uk-label'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'TRYNAME' },
          { datattr: 'uk-icon', val: 'icon: chevron-down ; ratio: 0.6' },
          { datattr: 'uk-byee' }
        ],
        after: ['<br>'],
        cnt: [],

        //extra ones go here

        drpdwnSelected: [ { name: 'More-than-20-years' }],
        drpdwn: [
          { name: 'Less-than-1-year' },
          { name: '_1-3-years' },
          { name: '_3-5-years' },
          { name: '_5-10-years' },
          { name: '_10-20-years' },
        //  { name: 'More-than-20-years' },
          { name: 'Unknown' }
        ]
      },
      {
        crtl: ['div'],
        name: ['PILLBOX'],
        statcnt: [],
        evfuct: ['CONE'],
        cls: ['flex-container'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'PILLBOX' },
          { datattr: 'data-rel', val: 'TRYNAME' }
        ],
        after: [],
        cnt: []
      },

      {
        crtl: ['span'],
        name: ['CONE'],
        statcnt: ['TOO BASIC'],
        cls: ['uk-label'],
        evfuct: ['CONE'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'dark' },
          { datattr: 'uk-icon', val: 'icon: chevron-down ; ratio: 0.6' },
          { datattr: 'uk-byee' }
        ],
        after: ['<br><br>'],
        cnt: []
      },

      {
        crtl: ['input'],
        name: ['CONEZZZZ'],
        statcnt: [],

        cls: ['uk-input', 'uk-form-width-small', 'uk-form-small'],
        evfuct: ['DROP'],
        evtype: ['input'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'TRYNAMEX' },
          { datattr: 'type', val: 'text' },
          { datattr: 'placeholder', val: 'BASIC' }
        ],
        after: ['<br>'],
        cnt: [],
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Lessthanyear' },
          { name: 'xyears' },
          { name: 'syears' },
          { name: 'eeeyears' },
          { name: 'yttttyears' },
          { name: 'Morethan20years' },
          { name: 'Unknown' }
        ]
      },
      {
        crtl: ['span'],
        name: ['RANG'],
        statcnt: ['TIME HORIZON'],
        evfuct: [],
        evtype: ['click'],
        cls: ['uk-label'],
        freeattr: [],
        dattr: [{ datattr: 'data-id', val: 'DATESEL' }],
        after: ['<br>'],
        cnt: []
      },
      {
        crtl: ['span'],
        name: ['FRDTE'],
        statcnt: [],
        evfuct: [],
        evtype: [],
        cls: ['closeb'],
        freeattr: [],
        dattr: [{ datattr: 'data-id', val: 'FROMDATE' }],
        after: [],
        cnt: []
      },
      {
        crtl: ['span'],
        name: ['TODTE'],
        statcnt: [],
        evfuct: [],
        evtype: [],
        cls: ['closeb'],
        freeattr: [],
        dattr: [{ datattr: 'data-id', val: 'TODATE' }],
        after: [],
        cnt: []
      },
      {
        crtl: ['div'],
        name: ['slider'],
        statcnt: [],
        cntfuct: ['SLIDE'],
        evfuct: [],
        evtype: [],
        cls: ['sc'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'SLIDER' },
          { datattr: 'data-frm', val: 'FROMDATE' },
          { datattr: 'data-to', val: 'TODATE' }
        ],

        

        after: [],
        cnt: [],
        sldarr: [
          '201710',
          '201711',
          '201712',
          '201801',
          '201802',
          '201803',
          '201804',
          '201805',
          '201806',
          '201807',
          '201808',
          '201809',
          '201810',
          '201811',
          '201812'
        ],
        sldint: {
          start: [2, 6],
          connect: true,
          step: 1,
          range: {
            min: [1],
            max: [7]
          }
        }
      }
    ]
  }
];



// <div class="uk-margin">
// <input class="uk-input uk-form-width-small uk-form-small" type="text" placeholder="Input">
// </div>


function T1() {

 // let ne = $('main-box-sel');
 // lisntoCntrGrp(ss.el, '.CONE',  addfunctgrp );

 let sssss= document.querySelector("#PILLBOX-102.CTRGP-100")
 console.log(sssss);



}





function T2() {


  console.log(' joke ' ,  jokexx );
 
}




function T3() {

let ss = createCntrlGrpx(jokexx, 'cnt', 'main-box-sel' , htmStrgx , addfunctgrpx , functTable );
console.log('ss :::::: '  ,ss);


function updateState(elobj) {
  let { el, elinfo, elnames } = elobj;

  //lkoop here and change control group

  for (let i = 0; i < elinfo.length; i++) {
    let em = elinfo[i].elm;
    let obj= elinfo[i].obj;    

 let statefx = mpto(obj.statefuct); 

  if (statefx) {
    let stF = functTable[statefx];

    if (typeof stF === 'function') {
      let sfx = stF(em, obj);
      sfx();
    }
  }
  
    console.log('statefx ' , statefx);
  }
}


//updateState( ss)


}




function createSliderArr ( arrObj) {

  const arrobj = arrObj
  
  const YMARR = [];
  for (let i = 0; i < arrobj.length; i++) {
    if (min <= arrobj[i].YMC && max >= arrobj[i].YMC) {
      YMARR.push(arrobj[i].YM);
    }
  }

}


// 
//handle - this is 0 or 1  for 2 handle slider 
//values  an array of the 2 value handles eg  [ '10' , '80']
//datesrg[Math.trunc(values[handle]) / 10 - 1];
// slideObj  is the standard  config object :  
// const objsld = {
//   start: [20, 60], ----where you want the 2 handles to start 
//   connect: true,  -----defaults to true
//   step: 10,   --- how much each strep of the slider is 
//   range: {    the total range of the slider  
//     min: [10],   
//     max: [70]
//   }
// }

//  sldArr   :  this is thge arry of single values that will appear on the target elemet, eg, pill from to date







function T4() {

    
let arr =[]

  let cel =document.querySelector("#PILLBOX-102")


  addpill('Less-than-1-year', cel, arr , 'single');

  console.log(arr);

}






function T5() {


}

function T6() {


/*
1. list with table
2. pagiation
3. continus

USAGE example
  let qury =  {    perPage :10  ,sort : 'MerText:desc'   ,   FUZ:'mcd'       }
  getData( `card/fuzz`  , qury    ,`main-box-sel`, 1 );
*/

 function pagination(apiadd, dataObj, afterElemtId, page = '0', pages = 0) {
  const afterEl = document.querySelector(`#${afterElemtId}`);
  const curpg = parseInt(page);
  const nxtpg = curpg + 1;
  const prvpg = curpg - 1;

  console.log(' pag, data obj  ', dataObj);

  let fist = document.querySelector('#pagea > ul');
  if (fist !== null) {
    fist.remove();
  }

  afterEl.insertAdjacentHTML(
    'afterend',
    `<div id ="pagea" class="uk-flex-center"><ul class="uk-pagination" ></ul></div>`
  );

  console.log('apiadd pgation ', apiadd, 'page ', page, 'pages ', pages);

  let li = afterEl.nextElementSibling.lastElementChild;

  // previous <
  // of current page not 1 you can go back
  if (curpg !== 1) {
    li.insertAdjacentHTML('beforeend', `<li><a  href="#"><span uk-pagination-previous></span></a></li>`);

    li.lastChild.addEventListener(
      'click',
      function() {
        getData(`card/fuzz`, dataObj, `main-box-sel`, prvpg);
      },
      false
    );
  } else {
    li.insertAdjacentHTML('beforeend', `<li><a href="#"><span uk-pagination-previous></span></a></li>`);
  }

  console.log('afterEl ', li);
  
  let outpgarr = generatePagination(curpg, pages);
  console.log('outpgarr ', outpgarr);

  // [1, 2, 3, "...", 46]

  for (let i = 0; i < outpgarr.length; i++) {
    li.insertAdjacentHTML('beforeend', `<li><a href="#">${outpgarr[i]}</a></li>`);

    li.lastChild.addEventListener(
      'click',
      function() {
        getData(`card/fuzz`, dataObj, `main-box-sel`, outpgarr[i]);
      },
      false
    );

    if (outpgarr[i] == '...') {
      li.lastChild.classList.add('uk-disabled');
    }
    if (outpgarr[i] == page) {
      li.lastChild.classList.add('uk-active');
    }
  }

  if (curpg < pages) {
    li.insertAdjacentHTML('beforeend', `<li> <a  href="#"><span uk-pagination-next></span></a>  </li>`);
    li.lastChild.addEventListener(
      'click',
      function() {
        getData(`card/fuzz`, dataObj, `main-box-sel`, nxtpg);
      },
      false
    );
  } else {
    li.insertAdjacentHTML('beforeend', `<li><a   href="#"><span uk-pagination-next>.</span></a></li>`);
  }

  function generatePagination(current, last) {
    const offset = 2;
    const leftOffset = current - offset;
    const rightOffset = current + offset + 1;

    /**
     * Reduces a list into the page numbers desired in the pagination
     * @param {array} accumulator - Growing list of desired page numbers
     * @param {*} _ - Throwaway variable to ignore the current value in iteration
     * @param {*} idx - The index of the current iteration
     * @returns {array} The accumulating list of desired page numbers
     */
    function reduceToDesiredPageNumbers(accumulator, _, idx) {
      const currIdx = idx + 1;

      if (
        // Always include first page
        currIdx === 1 ||
        // Always include last page
        currIdx === last ||
        // Include if index is between the above defined offsets
        (currIdx >= leftOffset && currIdx < rightOffset)
      ) {
        return [...accumulator, currIdx];
      }

      return accumulator;
    }

    /**
     * Transforms a list of desired pages and puts ellipsis in any gaps
     * @param {array} accumulator - The growing list of page numbers with ellipsis included
     * @param {number} currentPage - The current page in iteration
     * @param {number} currIdx - The current index
     * @param {array} src - The source array the function was called on
     */
    function transformToPagesWithEllipsis(accumulator, currentPage, currIdx, src) {
      const prev = src[currIdx - 1];

      if (prev != null && currentPage - prev !== 1) {
        return [...accumulator, '...', currentPage];
      }

      // If page does not meet above requirement, just add it to the list
      return [...accumulator, currentPage];
    }
    const pageNumbers = Array(last)
      .fill()
      .reduce(reduceToDesiredPageNumbers, []);
    const pageNumbersWithEllipsis = pageNumbers.reduce(transformToPagesWithEllipsis, []);
    return pageNumbersWithEllipsis;
  }
}


//table
 const ListFromJSON = function(apiadd, dataObj, afterElemtId ,inJson, tableID = 100) {

  //delete existing table  #table-101
  const containEl = document.querySelector(`#${afterElemtId}`);

    let tbl =   containEl.querySelector("table")
    if (tbl !== null) {
      tbl.remove();
    }

   console.log('dataOBj'   ,  apiadd, dataObj);

  let tableHTML = `
   <table id ="table-${tableID}" class="uk-table uk-table-divider uk-table-hover uk-table-small">
   <thead id ="thead-${tableID}"><tr id="thr-${tableID}"></tr></thead>
   <tbody id ="tbody-${tableID}"></tbody>
   </table>`;
  
  containEl.insertAdjacentHTML('beforeEnd', tableHTML);
  const hdr = document.querySelector(`#thead-${tableID}`).firstChild;
  const bdr = document.querySelector(`#tbody-${tableID}`);

    var col = [];
    let rowdata = '';
    //header
    for (var i = 0; i < inJson.length; i++) {
      for (var key in inJson[0]) {
        if (col.indexOf(key) === -1) {
          col.push(key);
          hdr.insertAdjacentHTML('beforeEnd', `<td>${key}</td>`);
        }
      }
      for (var property in inJson[i]) {
        rowdata += `<td>${inJson[i][property]}</td>`;
      }
      bdr.insertAdjacentHTML('beforeEnd', `<tr class ="thr-${tableID}">${rowdata}</tr>`);
     // console.log(bdr.lastChild); event listener addition



      rowdata = '';
    }
 


  }

  
   const getData = async ( apiadd, dataObj  ,  afterElemtId ,pg ) => {

  let query = [];
  for (let key in dataObj) {
    if (dataObj.hasOwnProperty(key)) {
      query.push(`${encodeURIComponent(key)}=${encodeURIComponent(dataObj[key])}`);
    }
  }
  let srchterm = query.join('&');

  console.log(`/v1/${apiadd}?${srchterm}&page=${pg}`);
  const response = await axios({
    url: `/v1/${apiadd}?${srchterm}&page=${pg}`,
    method: 'get',
    onDownloadProgress: function(progressEvent) {}
  });

  console.log('url ', `/v1/${apiadd}?${srchterm}&page=${pg}`);
  let { data, meta } = await response.data;
  let { perPage, limit, sort, totalCount, pageCount, count, page } = meta;
  let page_ = page.toString();
  await console.log('pagedata: ', perPage, limit, sort, totalCount, pageCount, count, page_);

  await pagination(apiadd, dataObj, afterElemtId , page_, pageCount );
  
  let inJson = await data;
  await console.log('getall: ', inJson);
  await   ListFromJSON(apiadd, dataObj, afterElemtId , inJson, 101);
  return { data, meta };
};

let qury =  {    perPage :10  ,sort : 'MerText:desc'   ,   FUZ:'mcd'       }
getData( `card/fuzz`  , qury    ,`main-box-sel`, 1 );


}

function T7() {}

function T8() {}

function T9() {}

function T10() {

let xxx =  document.querySelector( `[data-rel="TRYNAME"].CTRGP-100`  )

console.log(xxx);

}

document.querySelector('#T1').addEventListener('click', T1);
document.querySelector('#T2').addEventListener('click', T2);
document.querySelector('#T3').addEventListener('click', T3);
document.querySelector('#T4').addEventListener('click', T4);
document.querySelector('#T5').addEventListener('click', T5);
document.querySelector('#T6').addEventListener('click', T6);
document.querySelector('#T7').addEventListener('click', T7);
document.querySelector('#T8').addEventListener('click', T8);
document.querySelector('#T9').addEventListener('click', T9);
document.querySelector('#T10').addEventListener('click', T10);
