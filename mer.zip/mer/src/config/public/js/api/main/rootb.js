/* eslint-disable */

//login functionality
import { PageGrid } from '/js/api/modules/mods/pageGrid.js';
import { LogIn, logModal } from '/js/api/modules/mods/login.js';
import { factoryDrop } from '/js/api/modules/mods/drop.js';
import { ListFromJSON ,pagination ,getData  } from '/js/api/modules/mods/lister.js';

let BoxCardID = 99; //box for the data seg   CreateBoxCard
let BoxCardContID = 99; //smallest level for data seg  let xnewsel = function(id  ,  obj ,  sel )
let BoxMainID = 99; //main-box-sel  the highest level id everything goes in here

function T1() {
  BoxMainID = BoxMainID + 1;
  BoxCardID = BoxCardID + 1;
  BoxCardContID = BoxCardContID + 1;

  let pag = new PageGrid('main-box-sel');
  pag.CreateMain(BoxMainID);
  pag.CreateBoxCard(BoxCardID, 3, `GridStart-${BoxMainID}`, 'xxxxx');

}




function T2() {

  var notifications = UIkit.notification('MyMessage', 'danger');
}



function T3() {

  //this is for thr date slider   document.querySelector("#S100 > div.uk-clearfix > input")
 
  const startSlider = document.getElementById('main-box-sel');
  console.log('startSlider   ', startSlider);

  noUiSlider.create(startSlider, {
    start: [10, 370],
    connect: true,
    step: 10,
    range: {
      min: [10],
      max: [370]
    }
   
  });

  let sld = startSlider;
  console.log(' sld ', sld);

}



function T4() {}

function T5() {}


function T6() {
  
  let qury =  {    perPage :10  ,sort : 'MerText:desc'   ,   FUZ:'mcd'       }
  getData( `card/fuzz`  , qury    ,`main-box-sel`, 1 );

}



function T7() {}
function T8() {}
function T9() {}
function T10() {}





document.querySelector('#T1').addEventListener('click', T1);
document.querySelector('#T2').addEventListener('click', T2);
document.querySelector('#T3').addEventListener('click', T3);
document.querySelector('#T4').addEventListener('click', T4);
document.querySelector('#T5').addEventListener('click', T5);
document.querySelector('#T6').addEventListener('click', T6);
document.querySelector('#T7').addEventListener('click', T7);
document.querySelector('#T8').addEventListener('click', T8);
document.querySelector('#T9').addEventListener('click', T9);
document.querySelector('#T10').addEventListener('click', T10);
