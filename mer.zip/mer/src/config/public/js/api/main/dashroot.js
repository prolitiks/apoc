/* eslint-disable */

let jsn = {
  data: [
    {
      id: '5e2baac0ba931930a81397e9',
      user: '5d49340e1af22213a415f0e7',
      note: 'water',
      storyid: '444',
      chartInfo: {
        chart: { type: 'line', styledMode: true },
        legend: { enabled: true },
        title: { text: 'Monthly Stuff' },
        tooltip: { pointFormat: 'Value: {point.y:.2f}' },
        xAxis: { categories: 'arr', tickInterval: 2 },
        series: [{ name: 'mogas', data: 'ddsdsdsdsd' }]
      },
      createdAt: '2020-01-25T02:41:04.943Z'
    },
   
    {
      id: '5e53796bdddd7a257053e19c',
      user: '5d49340e1af22213a415f0e7',
      note: 'gas',
      storyid: '333',
      chartInfo: {
        chart: { type: 'line', styledMode: true },
        legend: { enabled: true },
        title: { text: 'Monthly Stuff' },
        tooltip: { pointFormat: 'Value: {point.y:.2f}' },
        xAxis: { categories: 'arr', tickInterval: 2 },
        series: [{ name: 'mogas', data: 'ddsdsdsdsd' }]
      },
      createdAt: '2020-02-24T07:21:15.051Z'
    },
  
    {
      id: '5e6ca84807f23d3a60ab8705',
      user: '5d49340e1af22213a415f0e7',
      note: 'gas',
      storyid: '333',
      chartInfo: {
        chart: { type: 'line', styledMode: true },
        legend: { enabled: true },
        title: { text: 'Monthly Stuff' },
        tooltip: { pointFormat: 'Value: {point.y:.2f}' },
        xAxis: { categories: 'arr', tickInterval: 2 },
        series: [{ name: 'mogas', data: 'ddsdsdsdsd' }]
      },
      createdAt: '2020-03-14T09:47:52.901Z'
    }
  ],
  meta: { sort: { createdAt: 1 }, timer: 24.47, timerAvg: 24.47 }
};

function listProj(indata, startNode) {
  const startEl = document.querySelector(startNode);
  let { data } = indata;
  for (let j = 0; j < data.length; j++) {
    console.log(data.length);
    startEl.insertAdjacentHTML(
      'beforeend',
      `<div class="uk-width-1-1@m">
      <div id = '${data[j].id}'    class="uk-card uk-card-default uk-card-body">
      <br>   <br>  
      <a href="/v1/users/${data[j].user}"   class="uk-button  uk-button-default uk-button-small"     >${data[j].note}</a>
      </div>   
     </div>    
     `
    );

    //  document.querySelector(`#id-${data[j].id}`).addEventListener('click',butt );
  }

  //add button event listeners
}

// function butt (e) {

//   console.log(  e.target.id)

// }

let logCookieFind = async cbyes => {
  let cookie = Cookies.get('tokendata');

  if (cookie) {
    const CK = JSON.parse(cookie);
    cbyes(CK.data.user.email);
  
  } else {
    console.log('need to login ', cookie);
  }
};

function putLoggedInInfoInBar(info) {
  console.log('ive put the logged into inf in nav bar ', info);
  //create elemt with email here :
  const startSel =    document.querySelector(`#LG`)
  startSel.insertAdjacentHTML(
    'beforebegin',
    `<span id ='lg-email'  class="uk-badge"  > ${info}</span> `
  );
}

let T1 = function() {

  logCookieFind(putLoggedInInfoInBar);
      const lgButt = document.querySelector(`#LG`)
      //change id and add event listener to button
      lgButt.textContent = 'SIGNOFF';
    //  lgButt.id= 'SOUT';
    //  lgButt.removeEventListener('click', LgIn);
    //  lgButt.addEventListener('click',  signOut );

};


document.querySelector('#T1').addEventListener('click', T1);
listProj(jsn, '#START');