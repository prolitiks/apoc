/* eslint-disable */

//login functionality
import { PageGrid } from '/js/api/modules/mods/pageGrid.js';
import { LogIn , logModal} from '/js/api/modules/mods/login.js';
import { factoryDrop } from '/js/api/modules/mods/drop.js';






let T5  = function () {

  console.log(UIkit);
}


let lginst

  let T4 = function () {

  
   let countries  =['australia' , 'asia' ,'algeria', 'england'  ,'ireland'    ]
 
   
//  (id, dropName,  drpDivID  ,inputElemtId, afterElemtId , containElemtId  ,   drpArr ) 
   let dropinst = new DropDown (   100, 'firstdrop', 'MDB'  , 'inputb' , 'B50',   'BOX1' ,    countries  , ['ireland']    ) 



   
 //  dropinst.consoleTest () 

  // dropinst.addDropEl() 
    
 // dropinst.drpS(   )


  dropinst.drpInp (   )
 
  const nums = [1, 2, 3, 4, 5, 6];
  const remove = [1, 2, 4, 6];
  
  function removeFromArray(original, remove) {
    return original.filter(value => !remove.includes(value)  );
  }
  
  console.log(removeFromArray(nums, remove));

    
  }


 function  T1 () {
   
  lginst = new LogIn('sdds', 'sssss' ,logModal);
  lginst.addhandle( )
   //creates an initialised function
   //  const lgs = logModal(lginst.logsub, lginst.logCookieEmail, lginst.signOut, lginst.lgButt);
   // document.querySelector(`#LG`).addEventListener('click', lgs);
    
  let weee =  factoryDrop ('factory drop')
   

  //console.log('factdrop ',  weee.tj());


 };




let T2 =function () {

  let tmpf =function(props) {
    let wes = props.todos.map(function(todo, ww) {   return `<li>weee  ${todo}</li> </h1> <div >fag</div>`; }).join('');
      console.log( 'wes ' ,wes   )
    return ` ${props.heading} <ul>   ${wes} </ul>`;
  }


  store = Reef.Store({
    data: {
      heading: 'My Todos',
      todos: dtlist()
    }
  });



  // Use the store in the app instead of a data object
  var app = new Reef('#B50', {
    store: store,

    template:  tmpf 
  });



  // Log a message to the console whenever a render happens
  document.addEventListener(
    'render',
    function(event) {
      //do something with elemt
      let nd = null;
      // Only run for elements with the #app ID
      if (!event.target.matches('#app')) return;

      // Log the data at the time of render need to add onclick  document.querySelector("#app > ul")

      nd = event.target.querySelectorAll('li');

      for (let i = 0; i < nd.length; i++) {
        nd[i].onclick = function() {
          return console.log('clicked dave ', store.data.todos.splice([i], 1));
        };
      }
    },
    false
  );

  app.render();



}



let BoxCardID = 99; //box for the data seg   CreateBoxCard
let BoxCardContID  = 99; //smallest level for data seg  let xnewsel = function(id  ,  obj ,  sel )
let BoxMainID = 99; //main-box-sel  the highest level id everything goes in here




let T6 = function() {
   
   let we= () => {   console.log('cb works ' );  } 

  lginst = new LogIn('sdds', 'sssss', we);
  lginst.remhandle() 
  console.log('T6 this ' , this );
};



let T8 = function() {
  BoxMainID  = BoxMainID  + 1
  BoxCardID  = BoxCardID + 1
  BoxCardContID  = BoxCardContID+ 1

  let pag = new  PageGrid ( 'main-box-sel'  ) 
  pag.CreateMain(BoxMainID) 
  pag.CreateBoxCard (BoxCardID , 3  , `GridStart-${BoxMainID}` , 'xxxxx' );
  pag.CreateBoxCardContent (BoxCardContID,  BoxCardID , 'winner'  )
  pag.CreateBoxCardContent (BoxCardContID,  BoxCardID , 'winner'  )
  pag.CreateBoxCardContent (BoxCardContID,  BoxCardID , 'winner'  )
  
};

let store

let T9 = function() {   console.log(' store.data.todos',  store.data.todos );  };



let T7 = function() {

 // store.data.todos.pop();
 // console.log( store.data.todos.splice(2,1));  
 // store.data.todos.push('Take a nap... zzzz');


 let remDr = document.querySelector(`#inputa`);

  // console.log(remDr.getAttribute('class'));     
   
  remDr.classList.toggle('tomato')
    
   console.log(remDr.classList);

};




let T3 = function () {

  let countries  =['australia' , 'asia' ,'algeria', 'england'  ,'ireland'    ]
  let win = []  ;

 // (id, dropName,  drpDivID  ,inputElemtId, afterElemtId , containElemtId  ,   drpArr ) 
     let dropf = factoryDrop (   100, 'firstdrop', 'MDB'  , 'inputb' , 'inputb',   'BOX1' ,    countries  , win   ) 
      dropf.drpMult()
    //   dropf.drpSing()
 
}




function dtlist () {
  
  let DRPOB=  
      {
        name: 'CUSTOMER-TENURE',
        code: '3',
        ctype: 'CMRELYEARS',
        prefix: 'RL',
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Less-than-1-year', code: '1' },
          { name: '1-3-years', code: '2' },
          { name: '3-5-years', code: '3' },
          { name: '5-10-years', code: '4' },
          { name: '10-20-years', code: '5' },
          { name: 'More-than-20-years', code: '6' },
          { name: 'Unknown', code: '7' }
        ]
      }


    //dropdown selected is the state  
    let ee =DRPOB.drpdwn.map(x => x.name )   

  console.log('DRPOB '   ,  ee  )

return ee

}

let cfa = function ()  {   
  
  console.log ( 'you are one ') 

}



let T10 = function() {
 
   store = Reef.Store({
    data: {
      heading: 'My Todos',
      todos: dtlist ()
    }
  });

  // Use the store in the app instead of a data object
  var app = new Reef('#app',  {
    store: store,

    template: function (props) {
      let wes =props.todos.map(function (todo , ww) {   return `<h1><li>weee  ${todo}</li> </h1> <div >fag</div>`; }).join('')
      return `
        <h1>${props.heading}</h1>
        <ul>
          ${wes}
        </ul>`;

    }
  });
  // Log a message to the console whenever a render happens
   document.addEventListener('render', function (event) {
      //do something with elemt 
      let nd =null
    // Only run for elements with the #app ID
    if (!event.target.matches('#app')) return;
    
    // Log the data at the time of render need to add onclick  document.querySelector("#app > ul")
   
    nd = event.target.querySelectorAll("li")
     

    for (let i = 0; i < nd.length; i++) {
           nd[i].onclick = function () {  return console.log('clicked dave ' ,     store.data.todos.splice([i],1) )     }  
                                    
    
    }

  
  }, false);

  
  app.render();

  Reef.emit(document, 'partyTime', {
    msg: `It's party time!`
  });



  // Log a message to the console whenever a render happens  https://lit-element.polymer-project.org/guide/start
 

};

document.querySelector('#T1').addEventListener('click', T1);
document.querySelector('#T2').addEventListener('click', T2);
document.querySelector('#T3').addEventListener('click', T3);
document.querySelector('#T4').addEventListener('click', T4);
document.querySelector('#T5').addEventListener('click', T5);
document.querySelector('#T6').addEventListener('click', T6);
document.querySelector('#T7').addEventListener('click', T7);
document.querySelector('#T8').addEventListener('click', T8);
document.querySelector('#T9').addEventListener('click', T9);
document.querySelector('#T10').addEventListener('click', T10);
