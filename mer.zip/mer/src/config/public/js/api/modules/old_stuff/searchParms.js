

/* eslint-disable */

var params ={};
var inJson;
var instory;
//ge

let crSrchterm;
let crPg;
let crApiadd;
let crSortby;
//let crsortdir = crSortby.split(':').pop();

 function sorted ( sortvar  )
  {
      //clear direction arrow code here delete all arrows
    let sortdir = crSortby.split(':').pop();
    sortdir = `:${sortdir}`
  
    if (sortdir ===  `:desc`) {
      sortdir   = "";
       //put direction arrow code here - up 
    } else {
      sortdir= `:desc`;
       //put direction arrow code here - down
    }
    crSortby = `&sort=${sortvar}${sortdir}` ;
   getAllStuff2  (crSrchterm, crPg , crApiadd ,crSortby) 

  }

let circ =document.querySelector("#spina")
let tabshow =document.querySelector("#showData")
circ.style.display = "none";

//document.querySelector("#spina")
//common function to remoove dom 
//document.querySelector("#pagea > ul > li > a > span > svg") need to handle no results
let removestuff = ()  =>  {
 
  let tabshow =document.querySelector("#showData > table")
  if ( tabshow !== null )
  {
    tabshow.remove(); 
  }
  let fist =document.querySelector("#pagea > ul")
  if ( fist !== null )
    {
      fist.remove()
    }
  
}


let buildQuery = function (data) {
  if (typeof (data) === 'string') return data;
  let query = [];
  for (let key in data) {
    if (data.hasOwnProperty(key)) {
      query.push(`${encodeURIComponent(key)  }=${  encodeURIComponent(data[key])}`);
    }
  }
  return query.join('&');
};
//http://localhost:3009/v1/abr?limit=100&skip=50&TRADNF=MAJESTIC%20NURSERIES
//need to make generic 
const getData= async (srchterm=srchterm, pg=1, apiadd  ,sortby = `&sort=MerText:desc` ) => {
  console.log(`/v1/${apiadd}?${srchterm}&page=${pg}${sortby}`)

   crSrchterm=srchterm;
   crPg =pg;
   crApiadd=apiadd ;
   crSortby=sortby;


  const response = await axios({
 url: `/v1/${apiadd}?${srchterm}&page=${pg}${sortby}`,
 method: 'get',
 onDownloadProgress: function(progressEvent) {

 }
})
let  {data , meta } = await response.data
let { perPage , limit , sort  , totalCount  , pageCount   , count  ,page}  = meta;
let page_ = page.toString()    ;  
 await console.log('pagedata: ', perPage , limit , sort  , totalCount  , pageCount   , count  , page_)
 //await pagination(apiadd, page_ , pageCount   ) 
 await pagination(srchterm ,apiadd, page_ , pageCount   ) 
inJson= await data
 await console.log('getall: ', inJson)
 return data
}



const getDataGoogle= async (srchterm=srchterm, pg=1, apiadd   ) => {
  console.log(`/v1/${apiadd}?${srchterm}`)
  const response = await axios({
 url: `/v1/${apiadd}?${srchterm}`,
 method: 'get',
 onDownloadProgress: function(progressEvent) {

 }
})
let  {candidates}= await response.data
 // console.log(data)
 return candidates
}



async  function googleser (e)  
{
  //console.log('keys :' , e.code  )  /mer/getexternal?place_id=ChIJm0LtxDWklWsRblaGGrzuZ9I
  let curval =document.getElementById("in4").value
    if ( curval.length >  4  )
   {
    let fuzcode =`input=${encodeURIComponent(curval)}`
  getAllStuff3 (`${fuzcode}`, 1, `mer/getexternal`  ,`` )
    console.log('curval google :' , fuzcode )
   }
  }



