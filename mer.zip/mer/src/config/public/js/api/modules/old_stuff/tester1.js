
/* eslint-disable */
let T8 = function() {};

let mObj = [{ name: '', code: '0', content: '' }];

let ModalObj = {
  Name: '',
  content: ''
};

let SEEDR = [
  {
    name: 'COMPLAINT-TYPE',
    code: '2',
    ctype: 'CMTYPE',
    prefix: 'T',
    drpdwnSelected: [],
    drpdwn: [
      { name: 'Access', code: '01' },
      { name: 'Advisor-Issues', code: '02' },
      { name: 'Business-Decision', code: '03' },
      { name: 'Comms-Information-Advice', code: '04' },
      { name: 'Credit-Decision', code: '05' },
      { name: 'Introducer', code: '06' },
      { name: 'Investment-Issues', code: '07' },
      { name: 'Letter-of-Notification', code: '08' },
      { name: 'Other-Bank-ATM', code: '09' },
      { name: 'Process', code: '10' },
      { name: 'Product-Features', code: '11' },
      { name: 'Rates-Fees-Charges', code: '12' },
      { name: 'Security', code: '13' },
      { name: 'Service-Failure', code: '14' },
      { name: 'Service-Quality', code: '15' },
      { name: 'St-George-Bank-SA-ATM', code: '16' },
      { name: 'Westpac-ATM	', code: '17' }
    ]
  },

  {
    name: 'RESOLVE-TIME',
    code: '1',
    ctype: 'CMRESTIME',
    prefix: 'CR',
    drpdwnSelected: [],
    drpdwn: [
      { name: 'Immediately', code: '0' },
      { name: 'Within-7-days', code: '1' },
      { name: 'More-than-7-days', code: '2' },
      { name: 'Unknown', code: '3' }
    ]
  },

  {
    name: 'CUSTOMER-TENURE',
    code: '3',
    ctype: 'CMRELYEARS',
    prefix: 'RL',
    drpdwnSelected: [],
    drpdwn: [
      { name: 'Less-than-1-year', code: '1' },
      { name: '1-3-years', code: '2' },
      { name: '3-5-years', code: '3' },
      { name: '5-10-years', code: '4' },
      { name: '10-20-years', code: '5' },
      { name: 'More-than-20-years', code: '6' },
      { name: 'Unknown', code: '7' }
    ]
  }
];

//console.log( Object.entries( DRPOBC))   pillfill(SEEDR, 'ctype', SEEDR[j].ctype, `${id}`);

function pushObj(ob, key, value) {
  ob.filter(function(obj) {
    if (obj[key].includes(value)) {
      const { name, drpdwn, drpdwnSelected, ctype } = obj;
      // console.log(  drpdwn    )
      console.log(name);
    }
  });
}

pushObj(SEEDR, 'ctype', 'CMRELYEARS');

//<ul id="list"></ul>
var list = document.querySelector('#list')
var fruits = ['Apple', 'Orange', 'Banana', 'Melon']

var fragment = new DocumentFragment()

fruits.forEach(function (fruit) {
  var li = document.createElement('li')
  li.innerHTML = fruit
  fragment.appendChild(li)
})

list.appendChild(fragment)

