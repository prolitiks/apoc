/* eslint-disable */

//import constants


//this saves the data for each selection, it should be run each time something changes for ste updates
let T2 = function() {
  //SAVE
  function puobSel(SEEDR, id) {   //this does one sectoin at a time based on the id idx 
    const idSelInx = id - 100;
    console.log('idSelInx  ', idSelInx);
    for (let j = 0; j < SEEDR.length; j++) {
      SEEDR[j].drpdwnSelected[idSelInx] = []; //this clears it before putting in the new value
      pushObjcc(SEEDR, 'ctype', SEEDR[j].ctype, id);
    }
    //save the dates  this need sown funtion??

    const sldr = sld.noUiSlider.get();
    const mindte = Math.trunc(sldr[0] / 10) + 9;
    const maxdte = Math.trunc(sldr[1] / 10) + 9;
    const min = document.querySelector(`#slider-min-${id}`).innerHTML;
    const max = document.querySelector(`#slider-max-${id}`).innerHTML;

    //need to clear it first

    DTR.DTSEL[idSelInx] = [];
    DTR.DTSEL[idSelInx].push({ YMC: mindte, YM: min }, { YMC: maxdte, YM: max });

    //need to save names
    const selName = document.querySelector(`#S${id} > input`).value;
    console.log('idSelInx  ', idSelInx);
    console.log('selName   ', selName );

    DTR.SELNAME[idSelInx] = [];
    DTR.SELNAME[idSelInx].push({ selname: selName }, { idx: idSelInx }, { id: id });

    //copy this into the selected 
    //DRPOBC.SEEDR[0].drpdwn  is the data elector dropdown copied into this

   // DRPOBC.SEEDR[0].drpdwn= []
    DRPOBC.SEEDR[0].drpdwn.push( { name : DTR.SELNAME[idSelInx][0].selname ,code: idSelInx  }   );




    console.log(' DRPOBC.SEEDR[0].drpdwn  ',     DRPOBC.SEEDR[0].drpdwn);
    console.log('DTR.DTSEL  ', DTR.DTSEL);
    console.log('SEEDR  ', DRPOB.SEEDR);
    console.log('ConfigObj  ', ConfigObj);
  }

  function puobchart(CHARTOBJ, id) {
    const idchartInx = id - 100;
    console.log('idchartInx ', idchartInx);
    console.log('CHARTOBJ', CHARTOBJ);

    const chartName = document.querySelector(`#C${id} > input`).value;
    console.log('idchartInx ', idchartInx);
    DTR.CHRSELNAME[idchartInx] = [];
    DTR.CHRSELNAME[idchartInx].push({ selname: chartName }, { idx: idchartInx }, { id: id });
    console.log(' DTR.CHRSELNAME ',  DTR.CHRSELNAME);
   
    // sldr =  chrSld.noUiSlider.get();
    const chrtype = document.querySelector(`#slider-chart-type-${id}`).innerHTML;
 
    console.log(' chrtype ', chrtype);

    DTR.CHRSEL[idchartInx] = [];
    DTR.CHRSEL[idchartInx].push({ chartype: chrtype });

  }

  //need to change this too loop it  get the number of elememnts that have the 'sel' class
  const selList= document.getElementsByClassName("Sel").length;
  console.log( 'selList  '  ,selList     )
  for (let k = 0; k < selList; k++) {
    
    DRPOB.SEEDR[k].drpdwnSelected = []
    puobSel(DRPOB.SEEDR, k+100);
  }


 // puobSel(DRPOB.SEEDR, 100);

 const chlList= document.getElementsByClassName("Ch").length;
  console.log( 'chlList   '  ,chlList   )
  for (let m = 0; m < chlList ; m++) {
    puobchart(DTR.CHRNAME, m+100);
    puobchart(DTR.CHRNAME, m+100);

  }

  console.log( 'DTR  '  ,DTR  )
   // puobchart(DTR.CHRNAME, 100);
  // puob(DRPOB.SEEDR ,101 );


  //console.log( 'selmane '  , DTR.SELNAME[0][0]  )


};