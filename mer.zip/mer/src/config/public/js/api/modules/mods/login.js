/* eslint-disable */

//login functionality


export  class LogIn {
  constructor(buttonSel, urlin  ,cb )   {
    this.buttonSel = buttonSel;
    this.urlin = urlin;
    this.lgButt = document.querySelector(`#LG`);
    this.cb = cb 
    this.lgs
  //  this.remhandle = this.remhandle.bind(this)
    //  // bind all methods
 //       this.cb = this.cb.bind(this);
   
  }
     
  //  need a test method that attaches event handler then drops it off

  remhandle() {
    console.log('fag  this ' , this )
  }

  
  addhandle() {
     this.lgs = this.cb( this.logsub , this.logCookieEmail , this.signOut , this.lgButt  )
     this.lgButt.addEventListener('click',  this.lgs );
     console.log( this.remhandle ); 
  }


  async logsub(e) {
    //delete existing cookies
    console.log('logsub works.....', e);

    Cookies.remove('tokendata');
    let transport = axios.create({
      withCredentials: true
    });

    await transport.interceptors.response.use(
      function(response) {
        console.log('intercepted.....');
        return response;
      },
      function(error) {
        const errorResponse = error.response;
        console.log('err.....', errorResponse.status);
        console.log('errmessage.....', errorResponse.data.message);
        console.log('errobj.....', errorResponse);
        let badpass = errorResponse.data.message;

        //put message in the login screen here
        document
          .querySelector(`#passin`)
          .insertAdjacentHTML('afterEnd', `<div id='l1' class ='badattemp'>${badpass}</div>`);
        return Promise.reject(error);
      }
    );

    //get imput fields from login

    let userin = document.getElementById('userin').value;
    let passin = document.getElementById('passin').value;
    console.log('userin... ', userin);
    console.log('passin... ', passin);
    const lgin = {
      email: userin, //create a form for the user and password
      password: passin
    };
    console.log('lgin  ... ', lgin);

    try {
      const response = await transport({
        url: `/v1/auth/login`,
        method: 'post',
        data: lgin,
        onDownloadProgress: function(progressEvent) {}
      });

      await response.data;
      console.log('axios data ', response.data);
      await Cookies.set('tokendata', response.data);

      //change the dom here if sucess
      //window.location.replace('/v1/users/5d49340e1af22213a415f0e7/profile');

      return response.data;
    } catch (e) {
      console.log(e.message);
    }
  }
  signOut(lgb , cb) {
    //returns a function that you can add to an event handler
   
    return function sgout() {
      console.log('we signed out ', lgb);
      Cookies.remove('tokendata');
      lgb.textContent = 'LOGIN';
   
      let d = document.getElementById('nav-top-m');
      let d_nested = document.getElementById('lg-email');
      console.log(' d_nested ', d_nested);
      if (d_nested) {
        d.removeChild(d_nested);
      }
      console.log('sgout   ', sgout)
    
      lgb.removeEventListener('click', sgout);
    let lginst = new LogIn('sdds', 'sssss' ,logModal);
      lginst.addhandle( )
          
    };
  }

  //pass in the event target
  async logCookieEmail(lgb) {
    let cookie = Cookies.get('tokendata');

    console.log('  this.lgButt. ', lgb);

    if (cookie) {
      const CK = JSON.parse(cookie);
      lgb.insertAdjacentHTML('beforebegin', `<span id ='lg-email'  class="uk-badge"  > ${CK.data.user.email}</span> `);
    } else {
      console.log('need to login ', cookie);
    }
  }
}



export function logModal( logsub  ,logCookieEmail  ,signOut  , lgb ) {
  return function lg ( )
   {
   let dom = `<div class="uk-margin">
 <H3>Login</H3><input id ='userin' class="uk-input uk-form-width-small uk-form-small" type="text" placeholder="User" required>
 </div><div class="uk-margin"><input id ='passin'  class="uk-input uk-form-width-small uk-form-small" type="password" placeholder="Password" required>
 </div> <br> Keep me logged in:  <input class="uk-checkbox" type="checkbox">
 `;
   UIkit.modal.confirmx(dom, logsub).then(
     function() {
       console.log('Confirmed. '   );
 
       //change id and add event listener to button
       lgb.textContent = 'SIGNOFF';
        logCookieEmail ( lgb)
   
   
 lgb.removeEventListener('click',  lg );  
 lgb.addEventListener('click', signOut (lgb)  );  
 
     // need a signoff event listener here
    
     },


     function() {
       console.log('Rejected.');
     }
   );
    } 
 }
