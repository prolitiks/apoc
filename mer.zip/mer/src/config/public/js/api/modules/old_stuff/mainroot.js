/* eslint-disable */

//import {}   from  './modules/Selectors/selv2.js'

import {
  addPill,
  addPilly,
  ConfigObj,
  ProjObj,
  getDataComp,
  pickReduce,
  combineArrays,

  // getDropObsListCode,
  seeddropX,
  // getDropObsListCodeX,
  createSeedsDrop
} from '/js/api/modules/mods/dataSelect.js';

import { logsub } from '/js/api/modules/mods/auth.js';

//based on what goes into it
let ModalObj = {
  Name: '',
  content: ''
};

let stateObj = {
  DataSegID: 99,
  selID: 99,
  chartID: 99,
  gridID: 99,
  projID: 99
};

let sld;
let chrSld;
console.log(addPill);
console.log(ConfigObj);
console.log(' sld before ', sld);
let mObj = [];

//const { DRPOB } = ConfigObj;
const { DRPOBC, DRPOB, DTR } = ConfigObj;

//global vars
//Select serioes var
let dataSegID = 99; //box for the data seg   CreateBoxCard
let selID = 99; //smallest level for data seg  let xnewsel = function(id  ,  obj ,  sel )
let chartID = 99;
let mdlID = 99;
let gridID = 99; //main-box-sel  the highest level id everything goes in here
let projID = 99; // the id for the project only one for each page

//this is part of the save function for state
function pushObj(ob, key, value, id) {
  const idx = id - 100;
  ob.filter(function(obj) {
    if (obj[key].includes(value)) {
      const { name, drpdwn, drpdwnSelected, ctype } = obj;
      let dp = document.querySelector(`#${value}-B-${id}`).childNodes;
      console.log('dp  ', dp);
      for (let i = 1; i < dp.length; i++) {
        let pilln = dp[i].textContent; //need to get rid of x at end
        let pillname = pilln.substring(0, pilln.length - 1);
        let pillcode = dp[i].classList[2]; //this is the name of the group
       drpdwnSelected.push([{ name: pillname, code: pillcode }]);
      }
    }
  });
}

//this saves the state for each selection group e.g. #S100
//this for edit, need one for delete update
function SaveSelectData(SEEDR, id) {
  const idSelInx = id - 100;
  console.log('idSelInx  ', idSelInx);

  for (let j = 0; j < SEEDR.length; j++) {
  //  SEEDR[j].drpdwnSelected[idSelInx] = []; //this clears it before putting in the new value
  //  SEEDR[j].drpdwnSelected = []; //this clears it before putting in the new value
    pushObj(SEEDR, 'ctype', SEEDR[j].ctype, id);
  }
  //save the dates  this need sown funtion??

  const sldr = sld.noUiSlider.get();
  const mindte = Math.trunc(sldr[0] / 10) + 9;
  const maxdte = Math.trunc(sldr[1] / 10) + 9;
  const min = document.querySelector(`#slider-min-${id}`).innerHTML;
  const max = document.querySelector(`#slider-max-${id}`).innerHTML;


  DTR.DTSEL.push([ { YMC: mindte, YM: min }, { YMC: maxdte, YM: max }]);


  //need to save names
  const selName = document.querySelector(`#S${id} > div.uk-clearfix > input`).value;
  console.log('idSelInx  ', idSelInx);
 

  console.log('selName   ', selName);

  DTR.SELNAME[idSelInx] = [];
  DTR.SELNAME[idSelInx].push({ selname: selName }, { idx: idSelInx }, { id: id });

  DRPOBC.SEEDR[0].drpdwn.push({ name: DTR.SELNAME[idSelInx][0].selname, code: idSelInx });

  console.log(' DRPOBC.SEEDR[0].drpdwn  ', DRPOBC.SEEDR[0].drpdwn);
  console.log('DTR.DTSEL  ', DTR.DTSEL);
  console.log('SEEDR  ', DRPOB.SEEDR);
  console.log('ConfigObj  ', ConfigObj);
}

function SaveChartData(CHARTOBJ, id) {
  const idchartInx = id - 100;
  console.log('idchartInx ', idchartInx);
  console.log('CHARTOBJ', CHARTOBJ);

  const chartName = document.querySelector(`#C${id} > input`).value;
  console.log('idchartInx ', idchartInx);
  DTR.CHRSELNAME[idchartInx] = [];
  DTR.CHRSELNAME[idchartInx].push({ selname: chartName }, { idx: idchartInx }, { id: id });
  console.log(' DTR.CHRSELNAME ', DTR.CHRSELNAME);

  // sldr =  chrSld.noUiSlider.get();
  const chrtype = document.querySelector(`#slider-chart-type-${id}`).innerHTML;

  console.log(' chrtype ', chrtype);

  DTR.CHRSEL[idchartInx] = [];
  DTR.CHRSEL[idchartInx].push({ chartype: chrtype });
}

//new small selector
let xnewsel = function(id, obj, sel , title) {
  const { DRPOBC, DRPOB, DTR } = obj;
  const startgrid = document.querySelector(`#${sel}`);
  startgrid.insertAdjacentHTML(
    'beforeend',
    `<div id='S${id}' class="uk-lbcont Sel">        <br>
     <div class="uk-clearfix">      <input class="uk-input uk-form-width-small uk-form-small" value="${title} ${id - 99}"></input> 
      <div class="uk-float-right">
     <a id='ss-${id}' ><span uk-icon="icon:  trash; ratio: .5"></span></a> 
     </div>
     </div>
    <span class="uk-label">TIME HORIZON </span> <span id="X1" class="uk-badge">100</span>  
    <br> <span id='slider-min-${id}' class="closeb"></span>
    <span id='slider-max-${id}' class="closeb"></span> <br>
    <div id ="slider-${id}" class ="sc" >  </div>  
    </div>   `
  );

  const anch= document.querySelector(`#ss-${id}`);
  console.log( ' anch  '  , anch        )
//add click listener  

function delSel(  e ) {
  const deS= this.id.substring(3,6)  
  const el = document.getElementById(`S${deS}`);
  el.remove();
}

//anch.addEventListener('click',  delSel);

UIkit.util.on(`#ss-${id}`, 'click', function (e) {
  e.preventDefault();
  e.target.blur();
  UIkit.modal.confirm('<h4>Are you sure you want to deletle this segment? </H4>').then(function () {
      console.log('Confirmed. ' )
   //   delSel(   )
   const deS= id
   const el = document.getElementById(`S${deS}`);
   el.remove();
      
  }, function () {
      console.log('Rejected.')
  });
});




  //this is for thr date slider   document.querySelector("#S100 > div.uk-clearfix > input")
  const arrobj = DTR.DTARR;
  const min = 10;
  const max = 47;
  const sliderDt = `S${id}`;
  const sliderEl = `slider-${id}`;

  const YMARR = [];
  for (let i = 0; i < arrobj.length; i++) {
    if (min <= arrobj[i].YMC && max >= arrobj[i].YMC) {
      YMARR.push(arrobj[i].YM);
    }
  }

  let datesrg = YMARR;
  const startSliderDate = document.getElementById(sliderDt); //A2
  console.log('startSliderDate ', startSliderDate);

  const startSlider = document.getElementById(sliderEl);
  console.log('startSlider   ', startSlider);

  noUiSlider.create(startSlider, {
    start: [10, 370],
    connect: true,
    step: 10,
    range: {
      min: [10],
      max: [370]
    }
  });

  sld = startSlider;
  console.log(' sld ', sld);

  const marginMin = document.getElementById(`slider-min-${id}`),
    marginMax = document.getElementById(`slider-max-${id}`);

  startSlider.noUiSlider.on('update', function(values, handle) {
    if (handle) {
      marginMax.innerHTML = datesrg[Math.trunc(values[handle]) / 10 - 1];
      console.log('handle  ', values, handle, 'arr ', Math.trunc(values[handle]) / 10 - 1);
    } else {
      marginMin.innerHTML = datesrg[Math.trunc(values[handle]) / 10 - 1];
      console.log('handle  ', values, handle, 'arr ', Math.trunc(values[handle]) / 10 - 1);
    }
  });
  startSlider.noUiSlider.set([80, 300]);

  //based on the object saved
  function pillfill(ob, key, value, id) {
    ob.filter(function(obj) {
      //3 loops for each
      if (obj[key].includes(value)) {
        const { name, drpdwn, drpdwnSelected, ctype } = obj;
        const idx = id - 100;
        if (Array.isArray(drpdwnSelected[idx]) && drpdwnSelected[idx].length) {
          for (let i = 0; i < drpdwnSelected[idx].length; i++) {
            addPilly(ctype, drpdwnSelected[idx][i].name, drpdwnSelected[idx][i].code, id);
          }
        }
      }
    });
  }

  function seeddrop(SEEDR) {
    for (let j = 0; j < SEEDR.length; j++) {
      createSeedsDrop(SEEDR, 'ctype', SEEDR[j].ctype, `${id}`, `#S`);
      pillfill(SEEDR, 'ctype', SEEDR[j].ctype, `${id}`);
    }
  }

  seeddrop(DRPOB.SEEDR);

  //need to push the selection in to the chart cdropdown

  console.log('selmane ', DTR.SELNAME);
};

async function HC(arr, xcat, id) {
  //need to create a div caled chart container
  await Highcharts.chart(`CHART-${id}`, {
    chart: {
      type: 'line',
      styledMode: true
    },

    legend: {
      enabled: true
    },
    title: {
      text: 'Monthly Stuff'
    },

    tooltip: {
      pointFormat: 'Am: {point.y:.2f}'
    },
    xAxis: {
      categories: xcat,
      tickInterval: 2
    },
    series: [
      {
        name: 'mogas',
        data: arr
      }
    ]
  });

  console.log(arr);
}

//need order of blocks

//idx represnts the index of the numer of selectors
async function getExz(idx) {
  const dr = await seeddropX(DRPOB.SEEDR, idx);
  const selected_fields = await combineArrays(dr); // for the group of 3 dropdowns
  const mindte = DTR.DTSEL[idx][0].YMC;
  const maxdte = DTR.DTSEL[idx][1].YMC;
  const jsonObj = await getDataComp(mindte, maxdte);
  const coll = await jsonObj.data;

  await console.log('selected_fields  ', selected_fields);
  await console.log('coll ', coll);
  await console.log('SLIDE------------------ ', mindte, maxdte);

  let arr = [];
  let xcat = [];
  await coll.map(function(prps, x) {
    let date = prps.CYM.substring(2, 6) + prps.CYM.substring(6);
    let obj = { name: parseInt(prps.CYM.substring(2, 8)), y: pickReduce(prps, selected_fields) };
    arr.push(obj);
    xcat.push(date);
  });
  await console.log('xcat  ', xcat);
  await console.log('arr    ', arr);
  await HC(arr, xcat, 1);
}


//<input class="uk-input uk-form-width-small uk-form-small" value="Selection ${id - 99}"></input> 
function CreateBoxCard (CardId, gridSize, selmain, selTitle) {
  const startSel = document.querySelector(`#${selmain}`);
  startSel.insertAdjacentHTML(
    'beforeend',
    ` <div class="uk-width-1-${gridSize}@m">
       <div id="SelCard-${CardId}" class="uk-card uk-card-default uk-card-body">  
       <div class="uk-clearfix">
      ${selTitle}  <div class="uk-float-right">
      <a id='seg-show-add-${CardId}' ><span  id='seg-show-add-${CardId}'  uk-icon="icon: plus; ratio: .75"></span> </a> 
      </div> </div> <br>
      <section  id ='seg-card-add-${CardId}'  >
      </section> </div> </div> `
  );
}


function CreateProj(projID, gridSize, selmain, selTitle) {
  const startSel = document.querySelector(`#${selmain}`);
  startSel.insertAdjacentHTML(
    'beforeend',
    `  <div class="uk-width-1-${gridSize}@m">
       <span class="uk-label">${selTitle} </span> 
       <button id='proj-add-${projID}' class="uk-button  uk-button-default uk-button-small">Add</button> <br><br>
       </div>
      </div>`
  );
}

function CreateStartGrid(GridId, selmain) {
  const startSel = document.querySelector(`#${selmain}`);
  startSel.insertAdjacentHTML(
    'beforeend',
    `<div id ='GridStart-${GridId}' uk-grid  >
    </div>`
  );
}

///need a funtion that creates a container with chart   ${CardId}

//create chart cell

//
let T1 = function() {
  // let we = { name: 'apollo', code: '1', content: 'The cat is on the mat' };
  // mObj.push(we);ls

  console.log(mObj);
  let  fragment = new DocumentFragment()
};



// select insertElemtId  <input id="MB-TEST" class="uk-input uk-form-width-small uk-form-small">
//the cat is om 



function createDrop(id, dropName, insertElemtId, drpArr) {
  const drpdwnIn = `<div id = 'MBD' uk-dropdown  > <ul id ="${dropName}-DROP-${id}" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
  const inEl = document.querySelector(`#${insertElemtId}`);
  inEl.insertAdjacentHTML('afterEnd', drpdwnIn);  //start of the dropdown list
  let filldrop = document.getElementById(`${dropName}-DROP-${id}`);
  function addP(e) {
    const pillgroup = e.target.classList[0];
    const pillname = e.target.innerHTML;
    console.log('pillgroup ', pillgroup);
    console.log('pillname ', pillname);
    inEl.value = pillname;
  }

  const drpdwn = drpArr;
  for (let i = 0; i < drpdwn.length; i++) {
    filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ='DROP-${id}'  href="#" >${drpdwn[i]}</a></li>`);

    //add listener

    filldrop.addEventListener('click', addP);
  }
}


let T2 = function() {

let droparrx =['one' ,'two' ,'three'  ,'four'   ]
  createDrop(100, 'firstdrop', 'MB-TEST' ,  droparrx   )


};


let T3 = function() {

  let dom = `ddsdsds`

  UIkit.modal.confirm(dom).then(function () {
    console.log('Confirmed. ' )

}, function () {
    console.log('Rejected.')
});

};


let T4 = function() {

  let dom = `ddsdsds`

  UIkit.modal.alertz(dom).then(function () {
    console.log('Confirmed. ' )

}, function () {
    console.log('Rejected.')
});

};


let T5 = function()  {   

 

};
let T6 = function()  {};
let T7 = function()  {};
let T8 = function()  {};
let T9 = function()  {};
let T10 = function() {};

//creates a modal return 3 controls in arrary

function CreateModalGeneric(mainSelector, modalid, title, buttonName, innerTemplate, cbFunct) {
  const startSel = document.querySelector(`#${mainSelector}`);
  startSel.insertAdjacentHTML(
    'beforeend',
    `<div id="modal-a-${modalid}" uk-modal >
     <div class="uk-modal-dialog uk-modal-body" uk-overflow-auto>
     <h6 class="uk-modal-title">${title}</h6>
     <div id='MB-content-${modalid}'   > </div>
     <input  id='MB-input-${modalid}' class="uk-input uk-form-width-small uk-form-small" ></input> 
     <button id='MB-button-${modalid}' class="uk-button uk-button-primary uk-button-small uk-modal-close" type="button">${buttonName}</button>
     <button class="uk-modal-close-default" type="button" uk-close></button> 
   </div>  
  </div>`
  );


  document.querySelector(`#MB-content-${modalid}`).insertAdjacentHTML('beforeend',  innerTemplate);

  const startSe = document.querySelector(`#modal-a-${modalid}`);
  const inName = document.querySelector(`#MB-input-${modalid}`);
  const modButn = document.querySelector(`#MB-button-${modalid}`);

  function modalUpdate() {
    let we = { name: title, code: modalid, content: inName.value };
    mObj.push(we);
  }

  modButn.addEventListener('click', modalUpdate);
  modButn.addEventListener('click', cbFunct);
  UIkit.modal(startSe).show();

}


let SaveAll = function() {
  const selList = document.getElementsByClassName('Sel')   //need to get the actual sel ids 
  //clear all before  
  DTR.DTSEL= []
  DRPOBC.SEEDR[0].drpdwn = [];

//clear the dropdown selected
  for (let j = 0; j < DRPOB.SEEDR.length; j++) {
    DRPOB.SEEDR[j].drpdwnSelected = []; 
   
  }
  

  for (let k = 0; k < selList.length; k++) {

    console.log ('k ', k )

    SaveSelectData(DRPOB.SEEDR, selList[k].id.substring(1,4) );

  }
};

//opening  first modeal creates a project

//create modal obect first ????
//create dropdown with name

let startPrj = async function() {
  mdlID = mdlID + 1;
  CreateModalGeneric('main-box-sel', mdlID, 'NEW Project', 'Create', `<h6>POOOOO</h6>`, ModalCb);
  
  
let droparrx =['one' ,'two' ,'three'  ,'four'   ]
//createDrop(100, 'firstdrop',  `MB-input-${mdlID}` ,  droparrx   )

//  'MB-input-${mdlID}' 

 // return mdlID;
};

let ModalCb = function() {
  gridID = gridID + 1;
  projID = projID + 1;

//need to get data from the mpdal onject
 const idx =  mdlID - 100;
 const mdlCont =  mObj[idx].content
  console.log(  mObj[idx]   )

  CreateStartGrid(gridID, 'main-box-sel');
  CreateProj(projID, 1, `GridStart-${gridID}`, mdlCont);
  let Prj = function() {
    mdlID = mdlID + 1;
    CreateModalGeneric('main-box-sel', mdlID, 'NEW Data Group Select', 'Create', `<h6>Seg</h6>`, sectIn);
  };
  document.querySelector(`#proj-add-${projID}`).addEventListener('click', Prj);
};



let sectIn = function() {
  dataSegID = dataSegID + 1;
  const idx =  mdlID - 100;
  const mdlCont =  mObj[idx].content
   console.log(  mObj[idx]   )

  //put modal here  
  CreateBoxCard(dataSegID, 3, `GridStart-${gridID}`, mdlCont) ;
  console.log('ProjObj  ', ProjObj);
  //add event listener

  function shwHde() {
    let x = document.querySelector(`#seg-card-add-${dataSegID}`)
    if (x.style.display === 'none') {
      x.style.display = 'block';
    } else {
      x.style.display = 'none';
    }
  }
  let Seltitle =document.querySelector(`#SelCardIn-${dataSegID}`)
  let addSec =document.querySelector(`#seg-card-add-${dataSegID}`)

  let SmallSel = function() {
    selID = selID + 1;
    xnewsel(selID, ConfigObj, `SelCard-${dataSegID}` , 'Selection' );
    console.log('selid ', selID);
    console.log('`SelCard-${dataSegID}`', `SelCardIn-${dataSegID}`);
    
  };
  //document.querySelector(`#seg-add-${dataSegID}`).addEventListener('click', SmallSel);
  //document.querySelector(`#seg-show-add-${dataSegID}`).addEventListener('click', shwHde);
  document.querySelector(`#seg-show-add-${dataSegID}`).addEventListener('click', SmallSel);

};

document.querySelector('#T1').addEventListener('click', T1);
document.querySelector('#T2').addEventListener('click', T2);
document.querySelector('#T3').addEventListener('click', T3);
document.querySelector('#T4').addEventListener('click', T4);
document.querySelector('#T5').addEventListener('click', T5);
document.querySelector('#T6').addEventListener('click', T6);
document.querySelector('#T7').addEventListener('click', T7);
document.querySelector('#T8').addEventListener('click', T8);
document.querySelector('#T9').addEventListener('click', T9);
document.querySelector('#T10').addEventListener('click', T10);
document.querySelector('#T11').addEventListener('click', SaveAll);
document.querySelector('#T12').addEventListener('click', startPrj);

//need to insert the slider , need to lable the grid boxes.  CreateSlideDate   document.querySelector("#GRIDSTARTx > div.uk-first-column")


let modalPrpt =  function  ( sel ,dom  )  {

  let qsel = '';
  UIkit.util.on(`#T${sel}`, 'click', function (e) {
    e.preventDefault();
    e.target.blur();
    UIkit.modal.confirm(dom).then(function () {
        console.log('Confirmed. ' )
     //   delSel(   )
    //  const deS= id
    //  const el = document.getElementById(`S${deS}`);
    //  el.remove();
        
    }, function () {
        console.log('Rejected.')
    });
  });


}