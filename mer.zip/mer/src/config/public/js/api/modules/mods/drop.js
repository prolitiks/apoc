/* eslint-disable */
/*
1. single dropdown single selection
2. multi selection , takes away from dropdown
3. fuzz select local
4. add to state
5. ad chevron button
6. type of array , single or multi object 
7. where to put the selected 
8. scroll 
9. pagiation
*/
function isElement(o) {
  return typeof HTMLElement === 'object'
    ? o instanceof HTMLElement //DOM2
    : o && typeof o === 'object' && o !== null && o.nodeType === 1 && typeof o.nodeName === 'string';
}

let $ = function(selector, parent) {
  return isElement(selector) ? selector : (parent ? parent : document).querySelector(`#${selector}`);
};
export const factoryDrop = function(
  id,
  dropName,
  drpDivID,
  inputElemtId,
  afterElemtId,
  containElemtId,
  drpArr,
  selArr
) {
  const drpdwnIn = `<div id = '${drpDivID}' uk-dropdown="mode: click" > <ul id ="${dropName}-DROP-${id}" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
  const inputEl = $(inputElemtId);
  const afterEl = $(afterElemtId);
  const containEl = $(containElemtId);
  const _drpDivID = drpDivID;
  let _id = id;


  function removeFromArray(original, remove) {
    return original.filter(value => !remove.includes(value));
  }

  let drpMulti = function() {
    let drpCurrent = removeFromArray(drpArr, selArr);
    let remDr = $(_drpDivID);
    if (remDr) {
      remDr.remove();
    }
    afterEl.insertAdjacentHTML('afterEnd', drpdwnIn);
    let val = inputEl.value;
    let arr = drpCurrent;
    let filldrop = $(`${dropName}-DROP-${_id}`);
    if (val.length > 0) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].substr(arr[i].indexOf(val), val.length).toUpperCase() == val.toUpperCase()) {
          filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ='DROP-${_id}' href="#" >${arr[i]}</a></li>`);
          UIkit.dropdown(`#${_drpDivID}`).show();
          filldrop.addEventListener('click', addMulti);
        }
      }
    } else remDr.remove();
  };

  let drpSingle = function() {
    afterEl.insertAdjacentHTML('afterEnd', drpdwnIn);
    let arr = drpArr;
    let filldrop = $(`${dropName}-DROP-${_id}`);
    for (let i = 0; i < arr.length; i++) {
      filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ='DROP-${_id}' href="#" >${arr[i]}</a></li>`);
      UIkit.dropdown(`#${_drpDivID}`).show();
      filldrop.addEventListener('click', addSingle);
    }
  };

  let drpMulNoAuto = function() {
    let drpCurrent = removeFromArray(drpArr, selArr);
    let remDr = document.getElementById(`${_drpDivID}`);
    if (remDr) {
      remDr.remove();
    }

    afterEl.insertAdjacentHTML('afterEnd', drpdwnIn);
   
    let arr = drpCurrent;
    let filldrop = $(`${dropName}-DROP-${_id}`);
    for (let i = 0; i < arr.length; i++) {
      filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ='DROP-${_id}' href="#" >${arr[i]}</a></li>`);
      UIkit.dropdown(`#${_drpDivID}`).show();
      filldrop.addEventListener('click', addMulNoAuto);
    }
  };

  // a bit of dry here , get the pill info frtom the dropdown
  function getPillinfo(e) {
    const pillgroup = e.target.classList[0];
    const pillid = e.target.classList[1];
    const pillname = e.target.innerHTML;
    const pillparent = e.currentTarget.parentNode; console.log('e.currentTarget. ' , e.currentTarget );
    pillparent.innerHTML = '';
    const pillBox = containEl;
    let seld = `<span class="closea">${pillname}<span id ='${pillname}' class="close ${pillname}">x</span></span>`;

  return {
      pillgroup,
      pillid,
      pillname,
      pillparent,
      pillBox,
      seld
    };
  }

  function addMulti(e) {
    let { pillgroup, pillid, pillname, pillparent, pillBox, seld } = getPillinfo(e);
    selArr.push(pillname);

    pillBox.insertAdjacentHTML('afterBegin', seld);
    pillBox.querySelector(`#${pillname}`).onclick = function(e) {
      selArr = removeFromArray(selArr, [e.target.id]);
      e.target.parentNode.remove();
    };
  }
  function addMulNoAuto(e) {
    let { pillgroup, pillid, pillname, pillparent, pillBox, seld } = getPillinfo(e);
    selArr.push(pillname);

    pillBox.insertAdjacentHTML('afterBegin', seld);
    pillBox.querySelector(`#${pillname}`).onclick = function(e) {
      selArr = removeFromArray(selArr, [e.target.id]);
      e.target.parentNode.remove();
    };
  }
  //only add a single pill keep all the dropdown elements  document.querySelector("#BOX1 > span")
  function addSingle(e) {
    let { pillgroup, pillid, pillname, pillparent, pillBox, seld } = getPillinfo(e);
    let pill = pillBox.querySelector('span');
    if (pill) {
      pill.remove();
    }
    pillBox.insertAdjacentHTML('afterBegin', seld);
  }
  return {
    drpMultNa() {
      inputEl.addEventListener('click', drpMulNoAuto );
    },
    drpMult() {
      inputEl.addEventListener('input', drpMulti);
    },
    drpSing() {
      inputEl.addEventListener('click', drpSingle);
    }
  };
};



export const factoryDropxxxx = function(
  id,
  dropName,
  drpDivID,
  inputElemtId,
  afterElemtId,
  containElemtId,
  drpArr,
  selArr
) {
  const drpdwnIn = `<div id = '${drpDivID}' uk-dropdown > <ul id ="${dropName}-DROP-${id}" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
  const inputEl = document.querySelector(`#${inputElemtId}`);
  const afterEl = document.querySelector(`#${afterElemtId}`);
  const containEl = document.querySelector(`#${containElemtId}`);
  const _drpDivID = drpDivID;
  let _id = id;
  function removeFromArray(original, remove) {
    return original.filter(value => !remove.includes(value));
  }

  let drpMulti = function() {
    let drpCurrent = removeFromArray(drpArr, selArr);
    let remDr = document.getElementById(`${_drpDivID}`);
    if (remDr) {
      remDr.remove();
    }
    afterEl.insertAdjacentHTML('afterEnd', drpdwnIn);
    let val = inputEl.value;
    let arr = drpCurrent;
    let filldrop = document.getElementById(`${dropName}-DROP-${_id}`);
    if (val.length > 0) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].substr(arr[i].indexOf(val), val.length).toUpperCase() == val.toUpperCase()) {
          filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ='DROP-${_id}' href="#" >${arr[i]}</a></li>`);
          UIkit.dropdown(`#${_drpDivID}`).show();
          filldrop.addEventListener('click', addMulti);
        }
      }
    } else remDr.remove();
  };

  let drpSingle = function() {
    afterEl.insertAdjacentHTML('afterEnd', drpdwnIn);
    let arr = drpArr;
    let filldrop = document.getElementById(`${dropName}-DROP-${_id}`);
    for (let i = 0; i < arr.length; i++) {
      filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ='DROP-${_id}' href="#" >${arr[i]}</a></li>`);
      UIkit.dropdown(`#${_drpDivID}`).show();
      filldrop.addEventListener('click', addSingle);
    }
  };

  let drpMulNoAuto = function() {
    let drpCurrent = removeFromArray(drpArr, selArr);
    let remDr = document.getElementById(`${_drpDivID}`);
    if (remDr) {
      remDr.remove();
    }

    afterEl.insertAdjacentHTML('afterEnd', drpdwnIn);
   
    let arr = drpCurrent;
    let filldrop = document.getElementById(`${dropName}-DROP-${_id}`);
    for (let i = 0; i < arr.length; i++) {
      filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ='DROP-${_id}' href="#" >${arr[i]}</a></li>`);
      UIkit.dropdown(`#${_drpDivID}`).show();
      filldrop.addEventListener('click', addMulNoAuto);
    }
  };



  // a bit of dry here
  function getPillinfo(e) {
    const pillgroup = e.target.classList[0];
    const pillid = e.target.classList[1];
    const pillname = e.target.innerHTML;
    const pillparent = e.currentTarget.parentNode;
    pillparent.innerHTML = '';
    const pillBox = document.querySelector(`#${containElemtId}`);
    let seld = `<span class="closea">${pillname}<span id ='${pillname}' class="close ${pillname}">x</span></span>`;

    return {
      pillgroup,
      pillid,
      pillname,
      pillparent,
      pillBox,
      seld
    };
  }
  function addMulti(e) {
    let { pillgroup, pillid, pillname, pillparent, pillBox, seld } = getPillinfo(e);
    selArr.push(pillname);

    pillBox.insertAdjacentHTML('afterBegin', seld);
    pillBox.querySelector(`#${pillname}`).onclick = function(e) {
      selArr = removeFromArray(selArr, [e.target.id]);
      e.target.parentNode.remove();
    };
  }
  function addMulNoAuto(e) {
    let { pillgroup, pillid, pillname, pillparent, pillBox, seld } = getPillinfo(e);
    selArr.push(pillname);

    pillBox.insertAdjacentHTML('afterBegin', seld);
    pillBox.querySelector(`#${pillname}`).onclick = function(e) {
      selArr = removeFromArray(selArr, [e.target.id]);
      e.target.parentNode.remove();
    };
  }

  //only add a single pill keep all the dropdown elements  document.querySelector("#BOX1 > span")
  function addSingle(e) {
    let { pillgroup, pillid, pillname, pillparent, pillBox, seld } = getPillinfo(e);
    let pill = pillBox.querySelector('span');
    if (pill) {
      pill.remove();
    }
    pillBox.insertAdjacentHTML('afterBegin', seld);
  }

  return {

    drpMultNa() {
      inputEl.addEventListener('click', drpMulNoAuto );
    },

    
    drpMult() {
      inputEl.addEventListener('input', drpMulti);
    },

    drpSing() {
      inputEl.addEventListener('click', drpSingle);
    }
  };
};




function drpmx(id, dropName, drpDivID,  afterElemtId, containElemtId, drpArr, selArr) {
  const drpdwnIn = `<div id = '${drpDivID}' uk-dropdown="mode: click" > <ul id ="${dropName}-DROP-${id}" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
 
  const afterEl = $(afterElemtId);
  const containEl = $(containElemtId);
  const _drpDivID = drpDivID;
  let _id = id;

  function createPillfromDropdown(e) {
    const pillgroup = e.target.classList[0];
    const pillid = e.target.classList[1];
    const pillname = e.target.innerHTML;
    const pillparent = e.currentTarget.parentNode;
    pillparent.innerHTML = '';
    const pillBox = containEl;
    let seld = `<span class="closea">${pillname}<span id ='${pillname}' class="close ${pillname}">x</span></span>`;
  
  return {
      pillgroup,
      pillid,
      pillname,
      pillparent,
      pillBox,
      seld
    };
  }
  
let drpMulNoAuto = function() {
  let drpCurrent = removeFromArray(drpArr, selArr);
  let remDr = document.getElementById(`${_drpDivID}`);
  if (remDr) {
    remDr.remove();
  }

  afterEl.insertAdjacentHTML('afterEnd', drpdwnIn);
 
  let arr = drpCurrent;
  let filldrop = $(`${dropName}-DROP-${_id}`);
  for (let i = 0; i < arr.length; i++) {
    filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ='DROP-${_id}' href="#" >${arr[i]}</a></li>`);
    UIkit.dropdown(`#${_drpDivID}`).show();
    filldrop.addEventListener('click', addMulNoAuto);
  }
};
function addMulNoAuto(e) {
  let { pillgroup, pillid, pillname, pillparent, pillBox, seld } = createPillfromDropdown(e);
  selArr.push(pillname);

  pillBox.insertAdjacentHTML('afterBegin', seld);
  pillBox.querySelector(`#${pillname}`).onclick = function(e) {
    selArr = removeFromArray(selArr, [e.target.id]);
    e.target.parentNode.remove();
  };
}


//make this return a function 
 return drpMulNoAuto 
    

}














