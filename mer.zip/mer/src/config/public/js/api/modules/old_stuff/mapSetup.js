
/* eslint-disable */
// need this in a loop  

const LeafBR =
  "#mapid > div.leaflet-control-container > div.leaflet-bottom.leaflet-right > div.info.legend.leaflet-control";
const mapboxAccessToken =
"pk.eyJ1IjoibW9nYXMiLCJhIjoiY2ppaWsxeXV3MWtuZzNxcG4zNTVmN3RteSJ9.2OsUOp70d2VPpc-51-fmcg";

const grayscale = L.tileLayer(
"https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=" +
  mapboxAccessToken,
{
  id: "mapbox.light",
  attribution: "Westpac"
}
);

let map = L.map("mapid", {
center: [-33.53434354312, 147.061051828579],
zoom: 6,
layers: [grayscale]
});


let info = L.control();
info.onAdd = function(map) {
  this._div = L.DomUtil.create("div", "info"); // create a div with a class "info"
  this.update();
  return this._div;
};

async function getEx() {
  let dates = await getSelCodes(YM_A);
  let mers = await getSelCodes(MERCAT_A);
  let sex = await getSelCodes(SEX_A);
  let dob = await getSelCodes(AGE_A);
  let selected_fields = await selectPop('M', dates, mers, sex, dob);
  let jsonObj = await getDataCed();
  let mapcoll = await jsonObj.features;
  let extx = await mapcoll.map(function(prps, x) {
    prps.tran[0].Total = pickReduce(prps.tran[0], selected_fields);
    return pickReduce(prps.tran[0], selected_fields);
  });
  let Colr = d3
    .scaleQuantile()
    .domain(d3.extent(extx))
    .range(red8);

  function highlightFeature(e) {
    let layer = e.target;
    layer.setStyle({
      weight: 3,
      color: '#666',
      dashArray: '',
      fillOpacity: 0.7
    });

    if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
      layer.bringToFront();
    }
  }

  function resetHighlight(e) {
    geoj.resetStyle(e.target);
  }

  function onEachFeature(feature, layer) {
    layer.on({
      mouseover: highlightFeature,
      mouseout: resetHighlight
    });
  }

  let geoj = await L.geoJson(jsonObj, {
    onEachFeature: onEachFeature,
    style: style
  }).addTo(map);

  function style(mapcoll) {
    return {
      fillColor: Colr(mapcoll.tran[0].Total),
      weight: 2,
      opacity: 1,
      color: 'white',
      dashArray: '3',
      fillOpacity: 0.7
    };
  }

  let sclock
  let createchartf=1
  let svg

  let legend = L.control({
    position: "bottomright"
  });
  legend.onAdd = function(map) {
    let div = L.DomUtil.create("div", "info legend");
    return div;
  };
   legend.addTo(map);

  if (createchartf == 1) {
    const canvas = d3.select(LeafBR).attr("height", 150);
    canvas.select("svg").remove();
    svg = canvas
      .append("svg")
      .attr("width", 85)
      .attr("height", 105);
    svg
      .append("g")
      .attr("class", "legendQuant")
      .attr("transform", "scale(0.60)");
     legend = d3
      .legendColor()
      .labelFormat(d3.format( "$.3s"))
      .useClass(false)
      .shapeWidth(20)
      .shapeHeight(20)
      .scale(Colr);
    svg.select(".legendQuant").call(legend);
  }


}



