/* eslint-disable */

// let BoxCardID = 99; //box for the data seg   CreateBoxCard
// let BoxCardContID  = 99; //smallest level for data seg  let xnewsel = function(id  ,  obj ,  sel )
// let BoxMainID = 99; //main-box-sel  the highest level id everything goes in here
export class PageGrid {
  constructor(selmain) {
    this.selmain = selmain;
  }

  CreateMain(BoxMainID) {
    const startSel = document.querySelector(`#${this.selmain}`);
    startSel.insertAdjacentHTML(
      'beforeend',
      `<div id ='GridStart-${BoxMainID}' uk-grid  >
          </div>`
    );
  }

  CreateBoxCard(BoxCardID, gridSize, BoxMainID, selTitle) {
    const startSel = document.querySelector(`#${BoxMainID}`);
    startSel.insertAdjacentHTML(
      'beforeend',
      ` <div class="uk-width-1-${gridSize}@m">
            <div id="SelCard-${BoxCardID}" class="uk-card uk-card-default uk-card-body">  
            <div class="uk-clearfix">
           ${selTitle}  <div class="uk-float-right">
           <a id='seg-show-add-${BoxCardID}' ><span  id='seg-show-add-${BoxCardID}'  uk-icon="icon: plus; ratio: .75"></span> </a> 
           </div> </div> <br>
           <section  id ='seg-card-add-${BoxCardID}'  >
           </section> </div> </div> `
    );
  }

  CreateBoxCardContent(BoxCardContID, BoxCardID, htmlContent) {
    const startgrid = document.querySelector(`#SelCard-${BoxCardID}`);
    startgrid.insertAdjacentHTML(
      'beforeend',
      `<div id='S${BoxCardContID}' class="uk-lbcont Sel"> <br>    
         ${htmlContent} 
          </div>
          </div>
         </div>`
    );
  }
}


