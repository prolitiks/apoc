/* eslint-disable */

function T2(e) {
 
  //need a set with just the ones included 
  //creATE one big object, the object also can be made to recreate the selected and can bew stored on the mopngo db
  // plus also an upload csv.
  //need a list of meta data  to store the state

    console.log ('CMTYPE   ' ,  CMTYPE ) 
    console.log ('CMRESTIME   ' , CMRESTIME  ) 
    console.log ('CMRELYEARS  ' , CMRELYEARS  ) 
        
  const node = document.createElement("BUTTON");
  const textn = document.createTextNode('x');
    node.appendChild(textn);
    node.setAttribute("class", "uk-button uk-button-default uk-button-small");
      document.getElementById('seedxx').appendChild(node);
      let allobj = {}
        //need to save this somewhere 
        console.log ('node ' ,  node   ) 
  }
  
//https://dev.to/basilcea/remaining-stateless-jwt-cookies-in-node-js-3lle


//function to set the cookes one you have a refresh token ;
//inputs

let transport = axios.create({
  withCredentials: true  
})
//need a login function 
//this is the first function and last resort if the token does not work
const T1= async ( ) => {

  //delete existing cookies 
  Cookies.remove('tokendata')

//this is the login method , sets the tken and then logs in 
  transport = axios.create({
    withCredentials: true  
  })

 const da = {  email:'dave@prolitiks.com',  //create a form for the user and password
                password: 'thewinner'}

  const response = await transport({
    url: `v1/auth/login`,
    method: 'post',
    data : da  ,
    onDownloadProgress: function(progressEvent) {}

  });
   await response.data;
   console.log('axios data '  , response.data)
   await  Cookies.set('tokendata', response.data);
   
};



const T1x= async ( ) => {

//only used

  await transport.interceptors.request.use(function(config) {
    let {data}= Cookies.getJSON('tokendata')
  
    if ( token != null ) {
      config.headers.Authorization = 'bearer '+ data.token['accessToken'];
    }
    console.log( 'token.....' , transport.interceptors)
    return config;
  }, function(err) {
    return Promise.reject(err);
  });
  

};






const T5= async ( e) => {

 let tokendata= Cookies.getJSON('tokendata')
 console.log('tokendata.....',tokendata )
 console.log('accessToken....',tokendata.data.token['accessToken'] )
 console.log('refreshToken.....',tokendata.data.token['refreshToken'] )
 console.log('email....',tokendata.data.user['email'] )

  }



const T3= async ( ) => {

     let {data}= await Cookies.getJSON('tokendata')
     let user =data.user['id'] 
     let token = 'bearer '+ data.token['accessToken']
    //get token from cookie

    const config = {
        method: 'get',
        url: `v1/users/${user}/notes`,
        headers: {'Authorization': 'bearer '+ data.token['accessToken']}
    }

    let res = await axios(config)

    console.log('user' , user);
    console.log('data token ', token);
    console.log('res  ' , res);

  };

  const T4= async ( ) => {

  
      const response = await  customAxios.get( `/v1x/complaint?limit=24&sort=CYM`);
      console.log(response);

  
 };


    const customAxios = axios.create({
     
    })
   
    customAxios.interceptors.response.use(
      function(response) {
        // If the request succeeds, we don't have to do anything and just return the response
        console.log('intercepted.....')
        return response
      },
      function(error) {
        const errorResponse = error.response
       if (isTokenExpiredError(errorResponse)) {
         return resetTokenAndReattemptRequest(error)
       }
     // console.log('err.....'  ,errorResponse.status )
        // If the error is due to other reasons, we just throw it back to axios
        return Promise.reject(error)
      }
    )


   function isTokenExpiredError(errorResponse) {
      //Your own logic to determine if the error is due to JWT token expired returns a boolean value
      //get the response code  
       // let stcode =errorResponse.status
       console.log('expired true...', errorResponse)
     return true


   }

   async function resetTokenAndReattemptRequest(error) {
    const { response: errorResponse } = error;

      console.log( 'poooed..trying again.' ,error   )

      const response = await  customAxios.get( `/v1/complaint?limit=24&sort=CYM`);

      console.log('response ....'  ,    response);
      console.log(' error response ....'  ,     errorResponse);

   }

   


   const rese = () => {
    axios.interceptors.response.use( (response) => {
      // Return a successful response back to the calling service
      return response;
    }, (error) => {
      // Return any error which is not due to authentication back to the calling service
      if (error.response.status !== 401) {
        return new Promise((resolve, reject) => {
          reject(error);
        });
      }
  
      // Logout user if token refresh didn't work or user is disabled
      if (error.config.url == '/api/token/refresh' || error.response.message == 'Account is disabled.') {
        
        TokenStorage.clear();
        router.push({ name: 'root' });
  
        return new Promise((resolve, reject) => {
          reject(error);
        });
      }
  
      // Try request again with new token
      return TokenStorage.getNewToken()
        .then((token) => {
  
          // New request with new token
          const config = error.config;
          config.headers['Authorization'] = `Bearer ${token}`;
  
          return new Promise((resolve, reject) => {
            axios.request(config).then(response => {
              resolve(response);
            }).catch((error) => {
              reject(error);
            })
          });
  
        })
        .catch((error) => {
          Promise.reject(error);
        });
    });
  }
  

document.querySelector('#T1').addEventListener('click',  T1);
document.querySelector('#T2').addEventListener('click',  T2);
document.querySelector('#T3').addEventListener('click',  T3);
document.querySelector('#T4').addEventListener('click',  T4);
document.querySelector('#T5').addEventListener('click',  T5);



/*****************************************/


/*****************************************/





