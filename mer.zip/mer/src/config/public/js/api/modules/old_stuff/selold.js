/* eslint-disable */


export let wee ='xxxxxxx'

let viewpop=  'M' //merchant or customer
let dates =[ '201908','201908' ]
let mers =[ '01','02','03' ]
let dob =[ '11','12','13','15','16' ]
let sex =[ 'A' ]



//temp store for added 

let YM_A=[]

let Y_A=[]
let M_A=[]

let AGE_A = []
let MERCAT_A = []
let SEX_A = []


let YM= [{ name: '201907'  , code : '201907'  , action: addPillblack }, 
         { name: '201908'    , code : '201908' , action: addPillblack }  
];


let Y= [{ name: '2019'  , code : '2019'  ,  subgrp :true  , subgroup :  'M'    ,   action: addPillblack  ,  actionSub :  addInnerPill}, 
         { name: '2018'    , code : '2018' ,  subgrp :true  , subgroup :  'M'  , action: addPillblack  ,  actionSub : addInnerPill}  
];

let M= [{ name: 'JAN'  , code : '01'  ,  subgrp :true  , subgroup :  ''    ,   action: addPillblack  ,  actionSub :  addInnerPill}, 
{ name: 'FEB'  , code : '02'   ,  subgrp :false  , subgroup :  ''    ,   action: addPillblack  ,  actionSub :  addInnerPill}, 
{ name: 'MAR'  , code : '03'  ,  subgrp :false , subgroup :  ''    ,   action: addPillblack  ,  actionSub :  addInnerPill}, 
{ name: 'APR'  , code : '04'  ,  subgrp :false  , subgroup :  ''    ,   action: addPillblack  ,  actionSub :  addInnerPill}, 
{ name: 'MAY'  , code : '05'  ,  subgrp :false  , subgroup :  ''    ,   action: addPillblack  ,  actionSub :  addInnerPill}
];




let ALLD= [{ name: '201907'  , code : '201907'  , action: addPillblack }, 
         { name: '201908'    , code : '201908' , action: addPillblack }  
];






// let MERCAT = [{ name: 'Apparel' , code : '01'  ,     action: addPill}
// , { name: 'Automotive'  , code : '02'   , action: addPill }  
// ,  { name: 'Child-Care' , code : '03'   , action: addPill}    
// , { name: 'Day-Out-Entertainment'  , code : '04'  , action: addPill }      
// , { name: 'Education'  , code : '05'  , action: addPill }      
// , { name: 'Entertainment'  , code : '06'  , action: addPill }      
// , { name: 'Food-Liquor'  , code : '07'  , action: addPill }      
// , { name: 'Food-Catering'  , code : '08'  , action: addPill }      
// , { name: 'Gambling'  , code : '09'  , action: addPill }      
// , { name: 'General-Retail'  , code : '10'  , action: addPill }      
// , { name: 'Healthcare'  , code : '11'  , action: addPill }      
// , { name: 'Home-Maintenance'  , code : '12'  , action: addPill }      
// , { name: 'Household-Goods'  , code : '13'  , action: addPill }      
// , { name: 'Insurance'  , code : '14'  , action: addPill }      
// , { name: 'Leisure'  , code : '15'  , action: addPill }      
// , { name: 'Non-food-Major'  , code : '16'  , action: addPill }      
// , { name: 'Property-Rentals'  , code : '17'  , action: addPill }      
// , { name: 'Retail-Services'  , code : '18'  , action: addPill }     
// , { name: 'Supermarkets'  , code : '19'  , action: addPill }     
// , { name: 'Transport'  , code : '20'  , action: addPill }     
// , { name: 'Travel-Accommodation'  , code : '21'  , action: addPill }     


// ];  

// let AGE = [
//    { name: '18-24'  , code : '01'  , action: addPill}
//  , { name: '25-34'   , code : '02'  , action: addPill }  
//  , { name: '35-44'   , code : '03'  , action: addPill}    
//  , { name: '45-54'   , code : '04' , action: addPill }      
//  , { name: '55-54'   , code : '05' , action: addPill }      
//  , { name: '65-74'   , code : '06' , action: addPill }      
//  , { name: '75-84'   , code : '07' , action: addPill }      
//  , { name: '85 + '   , code : '08' , action: addPill }      

// ];

//    let SEX = [{ name: 'ALL' , code : 'A'  ,    action: addPill}     

// ];




  //inserts dropdown after the selected button or element
  //this is the root, need to attach this to a single element  
/*

1. root
2. first drop 
3. next ones  
......
2 versions 1 for the any combination , the other for strict hieracy  
switch between new pills and push pulls
*/

 
   export function addInnerPill  (e)
{

  const actiontype = e.target.innerHTML; //send the class name to the close button from dropdown text
    // name of the object
    console.log('actiontype inner', actiontype )  
    let targObj = eval(e.target.classList[0]);  //whats leftover from taking it out
    let tartype = e.target.classList[0];
    let tartcode = e.target.classList[1];

    console.log('targObjinner ', targObj )  
    console.log('tartypeinner', tartype )  
    console.log('tartcodeinner ', tartcode)  

   console.log('inner this' , this.parentNode.parentNode  )

   let appush = this.parentNode.parentNode
   const textn = document.createTextNode(`- ${actiontype} `);
   appush.appendChild(textn);



     //  add to the array version of the select object
    // select the value of the array
    let arrtype = eval(`${tartype}_A`);
    console.log('arrtype ', arrtype  )  
    //take out the selected from the dropdown for next time  document.querySelector("#MERCAT-DROP")
    for (let m = 0; m < targObj.length; m++) {
      if (targObj[m].name === actiontype) {
        console.log('targObj[m].name  ', targObj[m]);
        arrtype.push(targObj[m]);
        targObj.splice(m, 1);
        e.target.parentNode.remove();
     
      }
    }





}



  export function hovDrop(e) {
    let targ = e.target.id;
    const drpdwnIn = `<div  uk-dropdown > <ul id ="${targ}-DROP" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
 //   const drpdwnIn = `</span> <div  uk-dropdown ="pos: middle-top"> <ul id ="${targ}-DROP" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
    let dropob = eval(targ);
    this.insertAdjacentHTML('afterEnd', drpdwnIn);
    console.log('this', this  )  
    let filldrop = document.getElementById(`${targ}-DROP`);
    for (var k = 0; k < dropob.length; k++) {
      filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ="${e.target.id} ${dropob[k].code} ${dropob[k].subgroup}"  href="#" >${dropob[k].name}</a></li>`);
      filldrop.addEventListener('click', dropob[k].action); //the action will be to add the pill and reduce the dropdown list
    }
  
  }


  
//based on the click from the dropdown    
//  nested loop for the inner objects
// first root then leads to another and another etc.

  export function addPillblack (e) {
    const actiontype = e.target.innerHTML; //send the class name to the close button from dropdown text
    // name of the object
    console.log('actiontype', actiontype )  
    let targObj = eval(e.target.classList[0]);  //This is the actual object that is selected
    let tartype = e.target.classList[0];  //the first elemt in the clas list , this is a proxy for the name of the object eg Y
    let tartcode = e.target.classList[1];
    let targsub = e.target.classList[2];

    console.log('targObj ', targObj )  
    console.log('tartype  ', tartype )  
    console.log('tartcode ', tartcode)  
    console.log('targsub ', targsub  )

      //create a span within a span  

      //create a span within  aspan just to confuse the fuck out of me 
    const node= document.createElement('SPAN');   // this wll contain the class ids like <span class="closea Y 2018">2018<span class="close" aria-expanded="false">x</span>
    const node2 = document.createElement('SPAN');
    const textnode2 = document.createTextNode('x');
  
    const textnode = document.createTextNode(actiontype);  //create a text node of the dropdoen for th pill 
    node.appendChild(textnode);
    node.appendChild(node2);
    node2.appendChild(textnode2);
    // this is for the css stuff
  
    node2.classList.add('close');
    node.classList.add('closea');

    node.classList.add(tartype, tartcode);

    document.getElementById('selmulti').appendChild(node);

    //  add to the array version of the select object
    // select the value of the array
    let arrtype = eval(`${tartype}_A`);
    console.log('arrtype ', arrtype  )  
    //take out the selected from the dropdown for next time  document.querySelector("#MERCAT-DROP")
    for (let m = 0; m < targObj.length; m++) {
      if (targObj[m].name === actiontype) {
        console.log('targObj[m].name  ', targObj[m]);
        arrtype.push(targObj[m]);
        targObj.splice(m, 1);
        e.target.parentNode.remove();
     
      }
    }

////////////////////////////////////////////////////////////
//inner pill insert here
// need to get the month for the dropdown year   
// so make everything before all the 
////////////////////////////////////////////////////////////


   //only put inner dropdown if object is  subgrp :true 
    
      let  tartype2 =targsub  
      const drpdwnIn = `<div  uk-dropdown ="pos: bottom-center" > <ul id ="${tartype2}-DROP" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
     
      let dropob = eval(tartype2)
      node2.insertAdjacentHTML('afterEnd', drpdwnIn);
      let tst =  node.childNodes[2].querySelector("ul")
       console.log( 'dropob  tst ----'   ,   tst   )

      //this must be the Month instead of the year
    //   let filldrop = document.getElementById(`${tartype}-DROP`);
    let filldrop =node.childNodes[2].querySelector("ul")
      for (var k = 0; k < dropob.length; k++) {
        filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ="${tartype2} ${dropob[k].code}"  href="#" >${dropob[k].name}</a></li>`);   // this should be month, but will test with year
        filldrop.addEventListener('click', dropob[k].actionSub); //the action will be to add the pill and reduce the dropdown list  #Y-DROP
      }
    
    

    node.addEventListener('click', function() {
      let ps = this.classList[2];
      let name = this.firstChild.nodeValue;
      console.log('ps ', this.classList);
     // this.remove();
      targObj.splice(0, 0, { name: name, code: ps, action: addPillblack });
      //need to remove here get index first
      let removeIndex = arrtype
        .map(function(item) {
          return item.name;
        })
        .indexOf(actiontype);
      arrtype.splice(removeIndex, 1);

      console.log('targObj remove ', targObj);
      console.log('arrtype remove ', arrtype);

      let targ = e.target.classList[0];
      let dropob = targObj;
      let filldrop = document.getElementById(`${targ}-DROP`);

     console.log('targ ', targ);

    //  remove siblinings first
      while (filldrop.hasChildNodes()) {
        filldrop.removeChild(filldrop.firstChild);
      }
      for (var k = 0; k < dropob.length; k++) {
        filldrop.insertAdjacentHTML(
          'beforeEnd',
          `<li><a class ="${e.target.classList[0]} ${ps}"  href="#" >${dropob[k].name}</a></li>`
        );
        filldrop.addEventListener('click', dropob[k].action);
      }
    });
  }


  //inserts dropdown after the selected button or element


export function dtSAStoJS_(dtSAS, dtType = "DATE") {
 if (dtSAS === null) {
   return null;
 } else if (dtType === "DATE") {

return new Date(-315619200000 + (dtSAS-36000) * 86400000);
 } else if (dtType === "DATETIME") {
   return new Date(-315619200000 + (dtSAS-36000) * 1000);
 } else {
   return null;
 }
}


/**************************************** */

let newcm =
[{"CYM":"YM201712","T12CR1RL4":12,"T01CR1RL3":null,"T01CR1RL4":3,"T01CR1RL5":5,"T01CR1RL6":14,"T01CR1RL7":null,"T01CR2RL3":null,"T01CR2RL4":1,"T01CR2RL5":2,"T01CR2RL6":5,"T03CR1RL2":2,"T03CR1RL3":4,"T03CR1RL4":5,"T03CR1RL5":12,"T03CR1RL6":8,"T03CR1RL7":null,"T03CR2RL2":null,"T03CR2RL3":null,"T03CR2RL4":8,"T03CR2RL5":7,"T03CR2RL6":11,"T03CR2RL7":null,"T04CR1RL2":9,"T04CR1RL3":7,"T04CR1RL4":17,"T04CR1RL5":56,"T04CR1RL6":60,"T04CR2RL2":9,"T04CR2RL3":7,"T04CR2RL4":11,"T04CR2RL5":31,"T04CR2RL6":37,"T04CR2RL7":2,"T04CR3RL5":null,"T08CR1RL6":1,"T08CR2RL4":null,"T09CR1RL3":1,"T09CR1RL6":3,"T10CR1RL2":49,"T10CR1RL3":17,"T10CR1RL4":35,"T10CR1RL5":101,"T10CR1RL6":120,"T10CR1RL7":12,"T10CR2RL2":23,"T10CR2RL3":17,"T10CR2RL4":45,"T10CR2RL5":107,"T10CR2RL6":97,"T10CR2RL7":13,"T10CR3RL7":1,"T11CR1RL2":21,"T11CR1RL3":2,"T11CR1RL4":6,"T11CR1RL5":26,"T11CR1RL6":33,"T11CR2RL4":3,"T11CR2RL5":15,"T11CR2RL6":24,"T12CR1RL2":3,"T12CR1RL3":7,"T12CR1RL5":30,"T12CR1RL6":50,"T12CR1RL7":null,"T12CR2RL2":10,"T12CR2RL3":6,"T12CR2RL4":7,"T12CR2RL5":22,"T12CR2RL6":40,"T12CR2RL7":null,"T13CR1RL3":null,"T13CR1RL7":null,"T13CR2RL6":null,"T15CR1RL2":8,"T15CR1RL3":9,"T15CR1RL4":28,"T15CR1RL5":44,"T15CR1RL6":64,"T15CR1RL7":3,"T15CR2RL2":4,"T15CR2RL3":6,"T15CR2RL4":5,"T15CR2RL5":24,"T15CR2RL6":24,"T15CR2RL7":3,"T16CR1RL6":null,"T16CR2RL5":null,"T17CR1RL3":null,"T17CR1RL6":3,"T17CR2RL5":null,"T17CR2RL6":2,"T01CR1RL2":2,"T01CR2RL7":null,"T04CR1RL7":1,"T08CR1RL5":null,"T08CR2RL6":1,"T09CR1RL5":1,"T09CR2RL3":null,"T10CR3RL6":null,"T11CR2RL3":1,"T13CR1RL5":1,"T13CR2RL5":1,"T15CR3RL7":null,"T16CR1RL4":null,"T17CR1RL4":null,"T17CR1RL5":2,"T17CR1RL7":null,"T01CR3RL5":null,"T02CR2RL5":null,"T03CR3RL7":null,"T04CR3RL7":null,"T06CR2RL5":null,"T08CR2RL5":1,"T09CR1RL4":1,"T09CR2RL2":null,"T11CR2RL2":2,"T12CR3RL6":null,"T13CR1RL4":null,"T14CR1RL3":null,"T16CR1RL2":null,"T16CR1RL7":null,"T17CR3RL7":null,"T02CR2RL4":null,"T09CR2RL5":1,"T09CR2RL6":null,"T11CR1RL7":null,"T17CR2RL4":null,"T01CR2RL2":1,"T08CR1RL7":null,"T11CR3RL7":null,"T13CR1RL2":null,"T14CR1RL5":null,"T14CR2RL7":null,"T16CR2RL6":null,"T17CR2RL3":null,"T02CR1RL5":null,"T02CR1RL6":null,"T04CR3RL4":null,"T09CR2RL4":null,"T10CR3RL2":null,"T12CR3RL7":null,"T13CR1RL6":1,"T13CR2RL4":null,"T02CR2RL6":null,"T14CR1RL6":null,"T14CR2RL5":null,"T16CR1RL3":null,"T17CR1RL2":1,"T05CR2RL3":null,"T08CR1RL3":null,"T08CR1RL4":1,"T08CR2RL3":null,"T13CR2RL2":null,"T07CR1RL6":null,"T10CR3RL5":null,"T14CR1RL7":null,"T05CR2RL6":null,"T11CR2RL7":null,"T16CR1RL5":null,"T07CR2RL7":null,"T17CR2RL7":null,"T03CR1RL1":null,"T09CR1RL2":null,"T11CR3RL3":null,"T02CR1RL3":null,"T02CR1RL7":null,"T10CR1RL1":null,"T17CR2RL2":null,"T09CR1RL7":null,"T05CR2RL4":null,"T14CR1RL2":null,"T05CR1RL2":null,"T03CR3RL5":null,"T10CR3RL4":null,"T14CR2RL6":null,"T16CR2RL2":null,"T03CR2RL1":null,"T05CR2RL7":null,"T01CR1RL1":null,"T04CR1RL1":null,"T04CR3RL6":null,"T10CR2RL1":null,"T11CR1RL1":null,"T12CR1RL1":null,"T12CR2RL1":null,"T15CR1RL1":null,"T15CR2RL1":null,"T15CR3RL4":null,"T15CR3RL6":null,"T02CR1RL4":null,"T04CR2RL1":null,"T07CR2RL6":null,"T11CR2RL1":null,"T03CR3RL4":null,"T03CR3RL6":null,"T13CR1RL1":null,"T14CR1RL1":null,"T11CR3RL6":null,"T15CR3RL2":null,"T17CR1RL1":null,"T03CR3RL1":null,"T07CR1RL7":null,"T13CR2RL1":null,"T01CR3RL7":null,"T05CR2RL5":null,"T08CR1RL2":null,"T08CR3RL7":null,"T10CR3RL3":null,"T02CR1RL2":null,"T04CR3RL2":null,"T05CR2RL2":null,"T11CR3RL5":null,"T12CR3RL5":null,"T01CR2RL1":null,"T05CR1RL5":null,"T14CR2RL4":null,"T15CR3RL1":null,"T15CR3RL3":null,"T01CR3RL6":null,"T08CR1RL1":null,"T08CR2RL2":null,"T11CR3RL2":null,"T15CR3RL5":null,"T17CR2RL1":null,"T03CR3RL2":null,"T04CR3RL3":null,"T06CR1RL6":null,"T09CR1RL1":null,"T11CR3RL4":null,"T03CR3RL3":null,"T07CR1RL4":null,"T08CR3RL6":null,"T10CR3RL1":null,"T12CR3RL4":null,"T13CR3RL5":null,"T14CR1RL4":null,"T01CR3RL1":null,"T01CR3RL2":null,"T01CR3RL3":null,"T04CR3RL1":null,"T06CR1RL1":null,"T08CR3RL3":null,"T08CR3RL5":null,"T11CR3RL1":null,"T12CR3RL1":null,"T12CR3RL2":null,"T12CR3RL3":null,"T13CR3RL3":null,"T13CR3RL6":null,"T17CR3RL5":null,"T17CR3RL6":null},{"CYM":"YM201801","T12CR1RL4":18,"T01CR1RL3":2,"T01CR1RL4":1,"T01CR1RL5":10,"T01CR1RL6":22,"T01CR1RL7":null,"T01CR2RL3":null,"T01CR2RL4":2,"T01CR2RL5":3,"T01CR2RL6":4,"T03CR1RL2":4,"T03CR1RL3":2,"T03CR1RL4":5,"T03CR1RL5":10,"T03CR1RL6":14,"T03CR1RL7":1,"T03CR2RL2":3,"T03CR2RL3":1,"T03CR2RL4":3,"T03CR2RL5":10,"T03CR2RL6":13,"T03CR2RL7":null,"T04CR1RL2":17,"T04CR1RL3":9,"T04CR1RL4":20,"T04CR1RL5":58,"T04CR1RL6":63,"T04CR2RL2":5,"T04CR2RL3":2,"T04CR2RL4":5,"T04CR2RL5":33,"T04CR2RL6":22,"T04CR2RL7":2,"T04CR3RL5":null,"T08CR1RL6":null,"T08CR2RL4":null,"T09CR1RL3":null,"T09CR1RL6":null,"T10CR1RL2":47,"T10CR1RL3":16,"T10CR1RL4":41,"T10CR1RL5":101,"T10CR1RL6":119,"T10CR1RL7":3,"T10CR2RL2":20,"T10CR2RL3":13,"T10CR2RL4":40,"T10CR2RL5":85,"T10CR2RL6":89,"T10CR2RL7":9,"T10CR3RL7":1,"T11CR1RL2":23,"T11CR1RL3":10,"T11CR1RL4":8,"T11CR1RL5":30,"T11CR1RL6":43,"T11CR2RL4":2,"T11CR2RL5":5,"T11CR2RL6":9,"T12CR1RL2":8,"T12CR1RL3":5,"T12CR1RL5":59,"T12CR1RL6":59,"T12CR1RL7":1,"T12CR2RL2":4,"T12CR2RL3":4,"T12CR2RL4":4,"T12CR2RL5":33,"T12CR2RL6":27,"T12CR2RL7":null,"T13CR1RL3":null,"T13CR1RL7":null,"T13CR2RL6":1,"T15CR1RL2":13,"T15CR1RL3":5,"T15CR1RL4":22,"T15CR1RL5":42,"T15CR1RL6":57,"T15CR1RL7":3,"T15CR2RL2":12,"T15CR2RL3":3,"T15CR2RL4":11,"T15CR2RL5":35,"T15CR2RL6":25,"T15CR2RL7":3,"T16CR1RL6":1,"T16CR2RL5":null,"T17CR1RL3":1,"T17CR1RL6":3,"T17CR2RL5":null,"T17CR2RL6":1,"T01CR1RL2":5,"T01CR2RL7":2,"T04CR1RL7":6,"T08CR1RL5":2,"T08CR2RL6":null,"T09CR1RL5":1,"T09CR2RL3":null,"T10CR3RL6":null,"T11CR2RL3":null,"T13CR1RL5":3,"T13CR2RL5":null,"T15CR3RL7":1,"T16CR1RL4":null,"T17CR1RL4":1,"T17CR1RL5":2,"T17CR1RL7":null,"T01CR3RL5":null,"T02CR2RL5":null,"T03CR3RL7":null,"T04CR3RL7":1,"T06CR2RL5":null,"T08CR2RL5":null,"T09CR1RL4":null,"T09CR2RL2":null,"T11CR2RL2":3,"T12CR3RL6":1,"T13CR1RL4":null,"T14CR1RL3":null,"T16CR1RL2":null,"T16CR1RL7":null,"T17CR3RL7":null,"T02CR2RL4":null,"T09CR2RL5":null,"T09CR2RL6":null,"T11CR1RL7":1,"T17CR2RL4":null,"T01CR2RL2":1,"T08CR1RL7":null,"T11CR3RL7":null,"T13CR1RL2":null,"T14CR1RL5":null,"T14CR2RL7":null,"T16CR2RL6":null,"T17CR2RL3":null,"T02CR1RL5":null,"T02CR1RL6":null,"T04CR3RL4":null,"T09CR2RL4":null,"T10CR3RL2":null,"T12CR3RL7":null,"T13CR1RL6":1,"T13CR2RL4":null,"T02CR2RL6":null,"T14CR1RL6":null,"T14CR2RL5":null,"T16CR1RL3":null,"T17CR1RL2":2,"T05CR2RL3":null,"T08CR1RL3":null,"T08CR1RL4":null,"T08CR2RL3":null,"T13CR2RL2":null,"T07CR1RL6":null,"T10CR3RL5":null,"T14CR1RL7":null,"T05CR2RL6":null,"T11CR2RL7":null,"T16CR1RL5":null,"T07CR2RL7":null,"T17CR2RL7":1,"T03CR1RL1":null,"T09CR1RL2":null,"T11CR3RL3":null,"T02CR1RL3":1,"T02CR1RL7":1,"T10CR1RL1":null,"T17CR2RL2":null,"T09CR1RL7":null,"T05CR2RL4":null,"T14CR1RL2":null,"T05CR1RL2":null,"T03CR3RL5":null,"T10CR3RL4":null,"T14CR2RL6":null,"T16CR2RL2":null,"T03CR2RL1":null,"T05CR2RL7":null,"T01CR1RL1":null,"T04CR1RL1":null,"T04CR3RL6":null,"T10CR2RL1":null,"T11CR1RL1":null,"T12CR1RL1":null,"T12CR2RL1":null,"T15CR1RL1":null,"T15CR2RL1":null,"T15CR3RL4":null,"T15CR3RL6":null,"T02CR1RL4":null,"T04CR2RL1":null,"T07CR2RL6":null,"T11CR2RL1":null,"T03CR3RL4":null,"T03CR3RL6":null,"T13CR1RL1":null,"T14CR1RL1":null,"T11CR3RL6":null,"T15CR3RL2":null,"T17CR1RL1":null,"T03CR3RL1":null,"T07CR1RL7":null,"T13CR2RL1":null,"T01CR3RL7":null,"T05CR2RL5":null,"T08CR1RL2":null,"T08CR3RL7":null,"T10CR3RL3":null,"T02CR1RL2":null,"T04CR3RL2":null,"T05CR2RL2":null,"T11CR3RL5":null,"T12CR3RL5":null,"T01CR2RL1":null,"T05CR1RL5":null,"T14CR2RL4":null,"T15CR3RL1":null,"T15CR3RL3":null,"T01CR3RL6":null,"T08CR1RL1":null,"T08CR2RL2":null,"T11CR3RL2":null,"T15CR3RL5":null,"T17CR2RL1":null,"T03CR3RL2":null,"T04CR3RL3":null,"T06CR1RL6":null,"T09CR1RL1":null,"T11CR3RL4":null,"T03CR3RL3":null,"T07CR1RL4":null,"T08CR3RL6":null,"T10CR3RL1":null,"T12CR3RL4":null,"T13CR3RL5":null,"T14CR1RL4":null,"T01CR3RL1":null,"T01CR3RL2":null,"T01CR3RL3":null,"T04CR3RL1":null,"T06CR1RL1":null,"T08CR3RL3":null,"T08CR3RL5":null,"T11CR3RL1":null,"T12CR3RL1":null,"T12CR3RL2":null,"T12CR3RL3":null,"T13CR3RL3":null,"T13CR3RL6":null,"T17CR3RL5":null,"T17CR3RL6":null},{"CYM":"YM201802","T12CR1RL4":19,"T01CR1RL3":1,"T01CR1RL4":4,"T01CR1RL5":9,"T01CR1RL6":16,"T01CR1RL7":null,"T01CR2RL3":2,"T01CR2RL4":3,"T01CR2RL5":3,"T01CR2RL6":4,"T03CR1RL2":6,"T03CR1RL3":8,"T03CR1RL4":8,"T03CR1RL5":16,"T03CR1RL6":13,"T03CR1RL7":2,"T03CR2RL2":5,"T03CR2RL3":2,"T03CR2RL4":6,"T03CR2RL5":13,"T03CR2RL6":21,"T03CR2RL7":2,"T04CR1RL2":17,"T04CR1RL3":7,"T04CR1RL4":16,"T04CR1RL5":48,"T04CR1RL6":50,"T04CR2RL2":12,"T04CR2RL3":3,"T04CR2RL4":12,"T04CR2RL5":33,"T04CR2RL6":36,"T04CR2RL7":3,"T04CR3RL5":null,"T08CR1RL6":1,"T08CR2RL4":null,"T09CR1RL3":null,"T09CR1RL6":2,"T10CR1RL2":58,"T10CR1RL3":28,"T10CR1RL4":35,"T10CR1RL5":108,"T10CR1RL6":135,"T10CR1RL7":11,"T10CR2RL2":23,"T10CR2RL3":11,"T10CR2RL4":54,"T10CR2RL5":97,"T10CR2RL6":110,"T10CR2RL7":7,"T10CR3RL7":1,"T11CR1RL2":22,"T11CR1RL3":2,"T11CR1RL4":10,"T11CR1RL5":19,"T11CR1RL6":44,"T11CR2RL4":5,"T11CR2RL5":8,"T11CR2RL6":8,"T12CR1RL2":7,"T12CR1RL3":8,"T12CR1RL5":50,"T12CR1RL6":79,"T12CR1RL7":4,"T12CR2RL2":3,"T12CR2RL3":6,"T12CR2RL4":10,"T12CR2RL5":32,"T12CR2RL6":24,"T12CR2RL7":1,"T13CR1RL3":null,"T13CR1RL7":null,"T13CR2RL6":null,"T15CR1RL2":11,"T15CR1RL3":3,"T15CR1RL4":9,"T15CR1RL5":50,"T15CR1RL6":57,"T15CR1RL7":2,"T15CR2RL2":9,"T15CR2RL3":3,"T15CR2RL4":9,"T15CR2RL5":32,"T15CR2RL6":30,"T15CR2RL7":3,"T16CR1RL6":null,"T16CR2RL5":null,"T17CR1RL3":null,"T17CR1RL6":null,"T17CR2RL5":1,"T17CR2RL6":null,"T01CR1RL2":null,"T01CR2RL7":1,"T04CR1RL7":3,"T08CR1RL5":1,"T08CR2RL6":null,"T09CR1RL5":null,"T09CR2RL3":null,"T10CR3RL6":null,"T11CR2RL3":1,"T13CR1RL5":null,"T13CR2RL5":1,"T15CR3RL7":null,"T16CR1RL4":null,"T17CR1RL4":null,"T17CR1RL5":1,"T17CR1RL7":1,"T01CR3RL5":null,"T02CR2RL5":null,"T03CR3RL7":null,"T04CR3RL7":null,"T06CR2RL5":null,"T08CR2RL5":null,"T09CR1RL4":1,"T09CR2RL2":1,"T11CR2RL2":2,"T12CR3RL6":null,"T13CR1RL4":null,"T14CR1RL3":null,"T16CR1RL2":null,"T16CR1RL7":null,"T17CR3RL7":null,"T02CR2RL4":null,"T09CR2RL5":null,"T09CR2RL6":2,"T11CR1RL7":2,"T17CR2RL4":null,"T01CR2RL2":2,"T08CR1RL7":null,"T11CR3RL7":1,"T13CR1RL2":null,"T14CR1RL5":null,"T14CR2RL7":null,"T16CR2RL6":null,"T17CR2RL3":null,"T02CR1RL5":1,"T02CR1RL6":null,"T04CR3RL4":null,"T09CR2RL4":null,"T10CR3RL2":null,"T12CR3RL7":1,"T13CR1RL6":3,"T13CR2RL4":null,"T02CR2RL6":null,"T14CR1RL6":null,"T14CR2RL5":null,"T16CR1RL3":null,"T17CR1RL2":null,"T05CR2RL3":null,"T08CR1RL3":null,"T08CR1RL4":null,"T08CR2RL3":null,"T13CR2RL2":null,"T07CR1RL6":null,"T10CR3RL5":1,"T14CR1RL7":null,"T05CR2RL6":null,"T11CR2RL7":null,"T16CR1RL5":null,"T07CR2RL7":null,"T17CR2RL7":null,"T03CR1RL1":null,"T09CR1RL2":2,"T11CR3RL3":null,"T02CR1RL3":null,"T02CR1RL7":null,"T10CR1RL1":1,"T17CR2RL2":null,"T09CR1RL7":null,"T05CR2RL4":null,"T14CR1RL2":null,"T05CR1RL2":null,"T03CR3RL5":null,"T10CR3RL4":null,"T14CR2RL6":null,"T16CR2RL2":null,"T03CR2RL1":null,"T05CR2RL7":null,"T01CR1RL1":null,"T04CR1RL1":null,"T04CR3RL6":null,"T10CR2RL1":null,"T11CR1RL1":null,"T12CR1RL1":null,"T12CR2RL1":null,"T15CR1RL1":null,"T15CR2RL1":null,"T15CR3RL4":null,"T15CR3RL6":null,"T02CR1RL4":null,"T04CR2RL1":null,"T07CR2RL6":null,"T11CR2RL1":null,"T03CR3RL4":null,"T03CR3RL6":null,"T13CR1RL1":null,"T14CR1RL1":null,"T11CR3RL6":null,"T15CR3RL2":null,"T17CR1RL1":null,"T03CR3RL1":null,"T07CR1RL7":null,"T13CR2RL1":null,"T01CR3RL7":null,"T05CR2RL5":null,"T08CR1RL2":null,"T08CR3RL7":null,"T10CR3RL3":null,"T02CR1RL2":null,"T04CR3RL2":null,"T05CR2RL2":null,"T11CR3RL5":null,"T12CR3RL5":null,"T01CR2RL1":null,"T05CR1RL5":null,"T14CR2RL4":null,"T15CR3RL1":null,"T15CR3RL3":null,"T01CR3RL6":null,"T08CR1RL1":null,"T08CR2RL2":null,"T11CR3RL2":null,"T15CR3RL5":null,"T17CR2RL1":null,"T03CR3RL2":null,"T04CR3RL3":null,"T06CR1RL6":null,"T09CR1RL1":null,"T11CR3RL4":null,"T03CR3RL3":null,"T07CR1RL4":null,"T08CR3RL6":null,"T10CR3RL1":null,"T12CR3RL4":null,"T13CR3RL5":null,"T14CR1RL4":null,"T01CR3RL1":null,"T01CR3RL2":null,"T01CR3RL3":null,"T04CR3RL1":null,"T06CR1RL1":null,"T08CR3RL3":null,"T08CR3RL5":null,"T11CR3RL1":null,"T12CR3RL1":null,"T12CR3RL2":null,"T12CR3RL3":null,"T13CR3RL3":null,"T13CR3RL6":null,"T17CR3RL5":null,"T17CR3RL6":null},{"CYM":"YM201803","T12CR1RL4":23,"T01CR1RL3":5,"T01CR1RL4":2,"T01CR1RL5":16,"T01CR1RL6":21,"T01CR1RL7":null,"T01CR2RL3":2,"T01CR2RL4":1,"T01CR2RL5":4,"T01CR2RL6":12,"T03CR1RL2":5,"T03CR1RL3":null,"T03CR1RL4":2,"T03CR1RL5":8,"T03CR1RL6":24,"T03CR1RL7":2,"T03CR2RL2":2,"T03CR2RL3":4,"T03CR2RL4":9,"T03CR2RL5":19,"T03CR2RL6":25,"T03CR2RL7":1,"T04CR1RL2":22,"T04CR1RL3":6,"T04CR1RL4":16,"T04CR1RL5":46,"T04CR1RL6":71,"T04CR2RL2":12,"T04CR2RL3":7,"T04CR2RL4":12,"T04CR2RL5":44,"T04CR2RL6":45,"T04CR2RL7":1,"T04CR3RL5":null,"T08CR1RL6":1,"T08CR2RL4":null,"T09CR1RL3":null,"T09CR1RL6":1,"T10CR1RL2":40,"T10CR1RL3":17,"T10CR1RL4":28,"T10CR1RL5":91,"T10CR1RL6":135,"T10CR1RL7":3,"T10CR2RL2":22,"T10CR2RL3":21,"T10CR2RL4":43,"T10CR2RL5":121,"T10CR2RL6":103,"T10CR2RL7":8,"T10CR3RL7":1,"T11CR1RL2":6,"T11CR1RL3":3,"T11CR1RL4":18,"T11CR1RL5":44,"T11CR1RL6":77,"T11CR2RL4":3,"T11CR2RL5":12,"T11CR2RL6":26,"T12CR1RL2":16,"T12CR1RL3":6,"T12CR1RL5":70,"T12CR1RL6":73,"T12CR1RL7":1,"T12CR2RL2":3,"T12CR2RL3":5,"T12CR2RL4":14,"T12CR2RL5":39,"T12CR2RL6":47,"T12CR2RL7":1,"T13CR1RL3":null,"T13CR1RL7":null,"T13CR2RL6":2,"T15CR1RL2":13,"T15CR1RL3":8,"T15CR1RL4":21,"T15CR1RL5":44,"T15CR1RL6":63,"T15CR1RL7":6,"T15CR2RL2":14,"T15CR2RL3":5,"T15CR2RL4":11,"T15CR2RL5":44,"T15CR2RL6":29,"T15CR2RL7":3,"T16CR1RL6":null,"T16CR2RL5":null,"T17CR1RL3":null,"T17CR1RL6":3,"T17CR2RL5":1,"T17CR2RL6":1,"T01CR1RL2":4,"T01CR2RL7":null,"T04CR1RL7":1,"T08CR1RL5":3,"T08CR2RL6":null,"T09CR1RL5":null,"T09CR2RL3":null,"T10CR3RL6":null,"T11CR2RL3":2,"T13CR1RL5":null,"T13CR2RL5":null,"T15CR3RL7":null,"T16CR1RL4":null,"T17CR1RL4":null,"T17CR1RL5":1,"T17CR1RL7":null,"T01CR3RL5":null,"T02CR2RL5":null,"T03CR3RL7":1,"T04CR3RL7":1,"T06CR2RL5":null,"T08CR2RL5":null,"T09CR1RL4":null,"T09CR2RL2":null,"T11CR2RL2":2,"T12CR3RL6":null,"T13CR1RL4":null,"T14CR1RL3":null,"T16CR1RL2":null,"T16CR1RL7":null,"T17CR3RL7":null,"T02CR2RL4":null,"T09CR2RL5":1,"T09CR2RL6":null,"T11CR1RL7":1,"T17CR2RL4":null,"T01CR2RL2":null,"T08CR1RL7":null,"T11CR3RL7":null,"T13CR1RL2":null,"T14CR1RL5":1,"T14CR2RL7":null,"T16CR2RL6":null,"T17CR2RL3":null,"T02CR1RL5":null,"T02CR1RL6":null,"T04CR3RL4":null,"T09CR2RL4":1,"T10CR3RL2":null,"T12CR3RL7":null,"T13CR1RL6":1,"T13CR2RL4":null,"T02CR2RL6":null,"T14CR1RL6":null,"T14CR2RL5":null,"T16CR1RL3":null,"T17CR1RL2":null,"T05CR2RL3":null,"T08CR1RL3":null,"T08CR1RL4":1,"T08CR2RL3":null,"T13CR2RL2":null,"T07CR1RL6":null,"T10CR3RL5":null,"T14CR1RL7":null,"T05CR2RL6":null,"T11CR2RL7":1,"T16CR1RL5":null,"T07CR2RL7":null,"T17CR2RL7":1,"T03CR1RL1":null,"T09CR1RL2":1,"T11CR3RL3":null,"T02CR1RL3":null,"T02CR1RL7":null,"T10CR1RL1":null,"T17CR2RL2":1,"T09CR1RL7":null,"T05CR2RL4":null,"T14CR1RL2":null,"T05CR1RL2":null,"T03CR3RL5":null,"T10CR3RL4":null,"T14CR2RL6":null,"T16CR2RL2":null,"T03CR2RL1":null,"T05CR2RL7":null,"T01CR1RL1":null,"T04CR1RL1":null,"T04CR3RL6":null,"T10CR2RL1":null,"T11CR1RL1":null,"T12CR1RL1":null,"T12CR2RL1":null,"T15CR1RL1":null,"T15CR2RL1":null,"T15CR3RL4":null,"T15CR3RL6":null,"T02CR1RL4":null,"T04CR2RL1":null,"T07CR2RL6":null,"T11CR2RL1":null,"T03CR3RL4":null,"T03CR3RL6":null,"T13CR1RL1":null,"T14CR1RL1":null,"T11CR3RL6":null,"T15CR3RL2":null,"T17CR1RL1":null,"T03CR3RL1":null,"T07CR1RL7":null,"T13CR2RL1":null,"T01CR3RL7":null,"T05CR2RL5":null,"T08CR1RL2":null,"T08CR3RL7":null,"T10CR3RL3":null,"T02CR1RL2":null,"T04CR3RL2":null,"T05CR2RL2":null,"T11CR3RL5":null,"T12CR3RL5":null,"T01CR2RL1":null,"T05CR1RL5":null,"T14CR2RL4":null,"T15CR3RL1":null,"T15CR3RL3":null,"T01CR3RL6":null,"T08CR1RL1":null,"T08CR2RL2":null,"T11CR3RL2":null,"T15CR3RL5":null,"T17CR2RL1":null,"T03CR3RL2":null,"T04CR3RL3":null,"T06CR1RL6":null,"T09CR1RL1":null,"T11CR3RL4":null,"T03CR3RL3":null,"T07CR1RL4":null,"T08CR3RL6":null,"T10CR3RL1":null,"T12CR3RL4":null,"T13CR3RL5":null,"T14CR1RL4":null,"T01CR3RL1":null,"T01CR3RL2":null,"T01CR3RL3":null,"T04CR3RL1":null,"T06CR1RL1":null,"T08CR3RL3":null,"T08CR3RL5":null,"T11CR3RL1":null,"T12CR3RL1":null,"T12CR3RL2":null,"T12CR3RL3":null,"T13CR3RL3":null,"T13CR3RL6":null,"T17CR3RL5":null,"T17CR3RL6":null},{"CYM":"YM201804","T12CR1RL4":8,"T01CR1RL3":1,"T01CR1RL4":3,"T01CR1RL5":16,"T01CR1RL6":31,"T01CR1RL7":9,"T01CR2RL3":6,"T01CR2RL4":3,"T01CR2RL5":6,"T01CR2RL6":8,"T03CR1RL2":2,"T03CR1RL3":3,"T03CR1RL4":4,"T03CR1RL5":9,"T03CR1RL6":9,"T03CR1RL7":null,"T03CR2RL2":4,"T03CR2RL3":2,"T03CR2RL4":5,"T03CR2RL5":17,"T03CR2RL6":15,"T03CR2RL7":4,"T04CR1RL2":10,"T04CR1RL3":1,"T04CR1RL4":14,"T04CR1RL5":36,"T04CR1RL6":66,"T04CR2RL2":9,"T04CR2RL3":1,"T04CR2RL4":10,"T04CR2RL5":29,"T04CR2RL6":40,"T04CR2RL7":3,"T04CR3RL5":null,"T08CR1RL6":null,"T08CR2RL4":1,"T09CR1RL3":null,"T09CR1RL6":1,"T10CR1RL2":32,"T10CR1RL3":17,"T10CR1RL4":34,"T10CR1RL5":78,"T10CR1RL6":104,"T10CR1RL7":11,"T10CR2RL2":24,"T10CR2RL3":15,"T10CR2RL4":46,"T10CR2RL5":91,"T10CR2RL6":106,"T10CR2RL7":21,"T10CR3RL7":null,"T11CR1RL2":10,"T11CR1RL3":4,"T11CR1RL4":6,"T11CR1RL5":25,"T11CR1RL6":35,"T11CR2RL4":2,"T11CR2RL5":6,"T11CR2RL6":18,"T12CR1RL2":11,"T12CR1RL3":4,"T12CR1RL5":51,"T12CR1RL6":62,"T12CR1RL7":4,"T12CR2RL2":5,"T12CR2RL3":8,"T12CR2RL4":12,"T12CR2RL5":33,"T12CR2RL6":38,"T12CR2RL7":1,"T13CR1RL3":null,"T13CR1RL7":null,"T13CR2RL6":2,"T15CR1RL2":13,"T15CR1RL3":4,"T15CR1RL4":13,"T15CR1RL5":44,"T15CR1RL6":61,"T15CR1RL7":5,"T15CR2RL2":9,"T15CR2RL3":5,"T15CR2RL4":15,"T15CR2RL5":30,"T15CR2RL6":29,"T15CR2RL7":4,"T16CR1RL6":1,"T16CR2RL5":null,"T17CR1RL3":null,"T17CR1RL6":2,"T17CR2RL5":null,"T17CR2RL6":1,"T01CR1RL2":1,"T01CR2RL7":null,"T04CR1RL7":2,"T08CR1RL5":null,"T08CR2RL6":null,"T09CR1RL5":null,"T09CR2RL3":null,"T10CR3RL6":null,"T11CR2RL3":1,"T13CR1RL5":null,"T13CR2RL5":1,"T15CR3RL7":1,"T16CR1RL4":null,"T17CR1RL4":null,"T17CR1RL5":null,"T17CR1RL7":null,"T01CR3RL5":null,"T02CR2RL5":null,"T03CR3RL7":null,"T04CR3RL7":1,"T06CR2RL5":null,"T08CR2RL5":2,"T09CR1RL4":null,"T09CR2RL2":null,"T11CR2RL2":1,"T12CR3RL6":null,"T13CR1RL4":null,"T14CR1RL3":null,"T16CR1RL2":null,"T16CR1RL7":null,"T17CR3RL7":null,"T02CR2RL4":null,"T09CR2RL5":null,"T09CR2RL6":1,"T11CR1RL7":1,"T17CR2RL4":1,"T01CR2RL2":2,"T08CR1RL7":null,"T11CR3RL7":null,"T13CR1RL2":1,"T14CR1RL5":null,"T14CR2RL7":null,"T16CR2RL6":null,"T17CR2RL3":null,"T02CR1RL5":null,"T02CR1RL6":null,"T04CR3RL4":null,"T09CR2RL4":null,"T10CR3RL2":null,"T12CR3RL7":null,"T13CR1RL6":null,"T13CR2RL4":null,"T02CR2RL6":null,"T14CR1RL6":null,"T14CR2RL5":null,"T16CR1RL3":null,"T17CR1RL2":null,"T05CR2RL3":null,"T08CR1RL3":null,"T08CR1RL4":null,"T08CR2RL3":null,"T13CR2RL2":null,"T07CR1RL6":null,"T10CR3RL5":null,"T14CR1RL7":null,"T05CR2RL6":null,"T11CR2RL7":null,"T16CR1RL5":null,"T07CR2RL7":null,"T17CR2RL7":null,"T03CR1RL1":null,"T09CR1RL2":null,"T11CR3RL3":null,"T02CR1RL3":null,"T02CR1RL7":null,"T10CR1RL1":null,"T17CR2RL2":null,"T09CR1RL7":4,"T05CR2RL4":null,"T14CR1RL2":null,"T05CR1RL2":null,"T03CR3RL5":null,"T10CR3RL4":null,"T14CR2RL6":null,"T16CR2RL2":null,"T03CR2RL1":null,"T05CR2RL7":null,"T01CR1RL1":null,"T04CR1RL1":null,"T04CR3RL6":null,"T10CR2RL1":null,"T11CR1RL1":null,"T12CR1RL1":null,"T12CR2RL1":null,"T15CR1RL1":null,"T15CR2RL1":null,"T15CR3RL4":null,"T15CR3RL6":null,"T02CR1RL4":null,"T04CR2RL1":null,"T07CR2RL6":null,"T11CR2RL1":null,"T03CR3RL4":null,"T03CR3RL6":null,"T13CR1RL1":null,"T14CR1RL1":null,"T11CR3RL6":null,"T15CR3RL2":null,"T17CR1RL1":null,"T03CR3RL1":null,"T07CR1RL7":null,"T13CR2RL1":null,"T01CR3RL7":null,"T05CR2RL5":null,"T08CR1RL2":null,"T08CR3RL7":null,"T10CR3RL3":null,"T02CR1RL2":null,"T04CR3RL2":null,"T05CR2RL2":null,"T11CR3RL5":null,"T12CR3RL5":null,"T01CR2RL1":null,"T05CR1RL5":null,"T14CR2RL4":null,"T15CR3RL1":null,"T15CR3RL3":null,"T01CR3RL6":null,"T08CR1RL1":null,"T08CR2RL2":null,"T11CR3RL2":null,"T15CR3RL5":null,"T17CR2RL1":null,"T03CR3RL2":null,"T04CR3RL3":null,"T06CR1RL6":null,"T09CR1RL1":null,"T11CR3RL4":null,"T03CR3RL3":null,"T07CR1RL4":null,"T08CR3RL6":null,"T10CR3RL1":null,"T12CR3RL4":null,"T13CR3RL5":null,"T14CR1RL4":null,"T01CR3RL1":null,"T01CR3RL2":null,"T01CR3RL3":null,"T04CR3RL1":null,"T06CR1RL1":null,"T08CR3RL3":null,"T08CR3RL5":null,"T11CR3RL1":null,"T12CR3RL1":null,"T12CR3RL2":null,"T12CR3RL3":null,"T13CR3RL3":null,"T13CR3RL6":null,"T17CR3RL5":null,"T17CR3RL6":null},{"CYM":"YM201805","T12CR1RL4":19,"T01CR1RL3":1,"T01CR1RL4":4,"T01CR1RL5":18,"T01CR1RL6":45,"T01CR1RL7":5,"T01CR2RL3":null,"T01CR2RL4":null,"T01CR2RL5":8,"T01CR2RL6":6,"T03CR1RL2":2,"T03CR1RL3":3,"T03CR1RL4":2,"T03CR1RL5":16,"T03CR1RL6":18,"T03CR1RL7":2,"T03CR2RL2":7,"T03CR2RL3":3,"T03CR2RL4":10,"T03CR2RL5":12,"T03CR2RL6":9,"T03CR2RL7":2,"T04CR1RL2":18,"T04CR1RL3":5,"T04CR1RL4":16,"T04CR1RL5":39,"T04CR1RL6":59,"T04CR2RL2":6,"T04CR2RL3":5,"T04CR2RL4":16,"T04CR2RL5":30,"T04CR2RL6":35,"T04CR2RL7":null,"T04CR3RL5":null,"T08CR1RL6":1,"T08CR2RL4":null,"T09CR1RL3":null,"T09CR1RL6":1,"T10CR1RL2":44,"T10CR1RL3":13,"T10CR1RL4":36,"T10CR1RL5":99,"T10CR1RL6":123,"T10CR1RL7":8,"T10CR2RL2":33,"T10CR2RL3":21,"T10CR2RL4":49,"T10CR2RL5":103,"T10CR2RL6":115,"T10CR2RL7":9,"T10CR3RL7":1,"T11CR1RL2":7,"T11CR1RL3":3,"T11CR1RL4":7,"T11CR1RL5":36,"T11CR1RL6":54,"T11CR2RL4":2,"T11CR2RL5":6,"T11CR2RL6":14,"T12CR1RL2":12,"T12CR1RL3":5,"T12CR1RL5":74,"T12CR1RL6":87,"T12CR1RL7":2,"T12CR2RL2":5,"T12CR2RL3":5,"T12CR2RL4":14,"T12CR2RL5":30,"T12CR2RL6":33,"T12CR2RL7":1,"T13CR1RL3":null,"T13CR1RL7":null,"T13CR2RL6":null,"T15CR1RL2":9,"T15CR1RL3":3,"T15CR1RL4":13,"T15CR1RL5":41,"T15CR1RL6":60,"T15CR1RL7":3,"T15CR2RL2":6,"T15CR2RL3":9,"T15CR2RL4":13,"T15CR2RL5":35,"T15CR2RL6":35,"T15CR2RL7":2,"T16CR1RL6":null,"T16CR2RL5":null,"T17CR1RL3":null,"T17CR1RL6":null,"T17CR2RL5":null,"T17CR2RL6":null,"T01CR1RL2":1,"T01CR2RL7":null,"T04CR1RL7":3,"T08CR1RL5":1,"T08CR2RL6":null,"T09CR1RL5":1,"T09CR2RL3":null,"T10CR3RL6":1,"T11CR2RL3":null,"T13CR1RL5":2,"T13CR2RL5":1,"T15CR3RL7":null,"T16CR1RL4":null,"T17CR1RL4":2,"T17CR1RL5":3,"T17CR1RL7":null,"T01CR3RL5":null,"T02CR2RL5":null,"T03CR3RL7":null,"T04CR3RL7":1,"T06CR2RL5":null,"T08CR2RL5":null,"T09CR1RL4":null,"T09CR2RL2":null,"T11CR2RL2":2,"T12CR3RL6":null,"T13CR1RL4":null,"T14CR1RL3":null,"T16CR1RL2":null,"T16CR1RL7":null,"T17CR3RL7":null,"T02CR2RL4":null,"T09CR2RL5":1,"T09CR2RL6":null,"T11CR1RL7":3,"T17CR2RL4":1,"T01CR2RL2":null,"T08CR1RL7":null,"T11CR3RL7":null,"T13CR1RL2":null,"T14CR1RL5":null,"T14CR2RL7":null,"T16CR2RL6":null,"T17CR2RL3":null,"T02CR1RL5":null,"T02CR1RL6":2,"T04CR3RL4":null,"T09CR2RL4":null,"T10CR3RL2":null,"T12CR3RL7":1,"T13CR1RL6":1,"T13CR2RL4":null,"T02CR2RL6":2,"T14CR1RL6":1,"T14CR2RL5":null,"T16CR1RL3":null,"T17CR1RL2":null,"T05CR2RL3":null,"T08CR1RL3":null,"T08CR1RL4":null,"T08CR2RL3":null,"T13CR2RL2":null,"T07CR1RL6":null,"T10CR3RL5":null,"T14CR1RL7":null,"T05CR2RL6":1,"T11CR2RL7":1,"T16CR1RL5":null,"T07CR2RL7":null,"T17CR2RL7":null,"T03CR1RL1":null,"T09CR1RL2":null,"T11CR3RL3":null,"T02CR1RL3":null,"T02CR1RL7":1,"T10CR1RL1":null,"T17CR2RL2":null,"T09CR1RL7":null,"T05CR2RL4":2,"T14CR1RL2":1,"T05CR1RL2":null,"T03CR3RL5":null,"T10CR3RL4":null,"T14CR2RL6":null,"T16CR2RL2":null,"T03CR2RL1":null,"T05CR2RL7":null,"T01CR1RL1":null,"T04CR1RL1":null,"T04CR3RL6":null,"T10CR2RL1":null,"T11CR1RL1":null,"T12CR1RL1":null,"T12CR2RL1":null,"T15CR1RL1":null,"T15CR2RL1":null,"T15CR3RL4":null,"T15CR3RL6":null,"T02CR1RL4":null,"T04CR2RL1":null,"T07CR2RL6":null,"T11CR2RL1":null,"T03CR3RL4":null,"T03CR3RL6":null,"T13CR1RL1":null,"T14CR1RL1":null,"T11CR3RL6":null,"T15CR3RL2":null,"T17CR1RL1":null,"T03CR3RL1":null,"T07CR1RL7":null,"T13CR2RL1":null,"T01CR3RL7":null,"T05CR2RL5":null,"T08CR1RL2":null,"T08CR3RL7":null,"T10CR3RL3":null,"T02CR1RL2":null,"T04CR3RL2":null,"T05CR2RL2":null,"T11CR3RL5":null,"T12CR3RL5":null,"T01CR2RL1":null,"T05CR1RL5":null,"T14CR2RL4":null,"T15CR3RL1":null,"T15CR3RL3":null,"T01CR3RL6":null,"T08CR1RL1":null,"T08CR2RL2":null,"T11CR3RL2":null,"T15CR3RL5":null,"T17CR2RL1":null,"T03CR3RL2":null,"T04CR3RL3":null,"T06CR1RL6":null,"T09CR1RL1":null,"T11CR3RL4":null,"T03CR3RL3":null,"T07CR1RL4":null,"T08CR3RL6":null,"T10CR3RL1":null,"T12CR3RL4":null,"T13CR3RL5":null,"T14CR1RL4":null,"T01CR3RL1":null,"T01CR3RL2":null,"T01CR3RL3":null,"T04CR3RL1":null,"T06CR1RL1":null,"T08CR3RL3":null,"T08CR3RL5":null,"T11CR3RL1":null,"T12CR3RL1":null,"T12CR3RL2":null,"T12CR3RL3":null,"T13CR3RL3":null,"T13CR3RL6":null,"T17CR3RL5":null,"T17CR3RL6":null}]
/*

let viewpop=  'M' //merchant or customer
let dates =[ '201908','201908' ]
let mers =[ '01','02','03' ]
let dob =[ '11','12','13','15','16' ]
let sex =[ 'A' ]

*/


export function selectPop(viewpop = 'M', dates, mers , sex , dob) {
 
 let final = [];
 const CAT = 'CAT';
 const A = 'A';

 //set defaults
 if (dates.length < 1)    {  dates=  [ '201907','201908' ]} 
 if (mers.length < 1)  {  mers=[ '01','02','03','05','06','07','08','09','10','11','12','13','15','16','17','18','19','20','21' ]} 
 if (dob.length < 1)  { dob =[ '01','02','03','05','06','07','08']} 
 if (sex.length < 1)  {  sex=  [ 'A'] } 

 for (let i = 0; i < dates.length; i++) {
   let dt = `${viewpop}${dates[i]}`;
   for (let j = 0; j < mers.length; j++) {
     let mdt = `${dt}${CAT}${mers[j]}`;
     for (let k = 0; k < sex.length; k++) {
       let sx = `${mdt}${A}${sex[k]}`;
       for (let m = 0; m < dob.length; m++) {
         let db = `${sx}${dob[m]}`;
         final.push(db);
       }
     }
   }
 }
 return final;
}

// takes an array of objects spits out codes
export function getSelCodes  ( arrObj   , keycode )   {
  let scrape =[]
 arrObj.forEach(el => {
   scrape.push(el[keycode])
 });

 return scrape
}

//picks selected vales and aggreagtes them

export function pickReduce (object, [...userSelect ] ) {
 //selected object  
 const kval= userSelect.reduce((o, e) => {return o[e] = object[e], o}, {});
  //get values from selected key value and create array
  const jval= Object.values(kval) 
  const jv= jval.filter( Number );
  let sum = jv.reduce(function (accumulator, currentValue) {
   return accumulator + currentValue;
   
 }, 0);
 
 return sum
}



let comp ={"CYM":"YM201609","T12C18CR1RL4":1,"T01C01CR1RL5":1,"T01C01CR1RL6":1,"T01C01CR1RL7":1,"T01C01CR2RL6":1,"T01C03CR1RL6":1,"T01C04CR1RL6":1,"T01C06CR1RL5":1,"T01C06CR1RL6":1,"T01C06CR1RL7":1,"T01C06CR2RL3":1,"T01C07CR1RL3":1,"T01C07CR1RL4":1,"T01C07CR1RL6":1,"T01C09CR1RL5":1,"T01C15CR1RL6":1,"T01C18CR1RL3":1,"T01C18CR1RL4":1,"T01C18CR1RL5":1,"T01C18CR1RL6":1,"T01C18CR2RL4":1,"T01C18CR2RL6":1,"T01C19CR1RL4":1,"T01C19CR1RL5":1,"T01C19CR2RL5":1,"T01C19CR2RL6":1,"T01C31CR1RL5":1,"T01C31CR1RL6":1,"T01C31CR2RL5":1,"T01C31CR2RL6":1,"T01C44CR1RL4":1,"T01C50CR1RL4":1,"T01C50CR1RL5":1,"T01C50CR1RL6":1,"T01C50CR2RL4":1,"T01C50CR2RL5":1,"T01C51CR1RL6":1,"T03C11CR1RL5":1,"T03C11CR2RL6":1,"T03C18CR1RL2":1,"T03C18CR1RL3":1,"T03C18CR1RL6":1,"T03C18CR1RL7":1,"T03C18CR2RL2":1,"T03C18CR2RL3":1,"T03C18CR2RL4":1,"T03C18CR2RL5":1,"T03C18CR2RL6":1,"T03C18CR2RL7":1,"T03C19CR2RL3":1,"T03C24CR1RL4":1,"T03C24CR1RL5":1,"T03C24CR1RL6":1,"T03C24CR2RL5":1,"T03C24CR2RL6":1,"T03C26CR2RL5":1,"T03C37CR1RL4":1,"T03C37CR2RL2":1,"T03C37CR2RL5":1,"T03C41CR1RL5":1,"T03C41CR1RL6":1,"T03C41CR2RL2":1,"T03C41CR2RL5":1,"T03C41CR2RL6":1,"T03C42CR1RL5":1,"T03C42CR2RL6":1,"T03C47CR2RL5":1,"T03C51CR1RL6":1,"T04C01CR1RL6":1,"T04C03CR2RL6":1,"T04C04CR2RL6":1,"T04C06CR1RL5":1,"T04C06CR1RL6":1,"T04C06CR2RL3":1,"T04C06CR2RL4":1,"T04C06CR2RL5":1,"T04C06CR2RL6":1,"T04C07CR1RL4":1,"T04C07CR1RL5":1,"T04C09CR1RL6":1,"T04C09CR2RL5":1,"T04C09CR2RL6":1}

;

let newman=[
  {"ABSCODE":401011002,"ARAN":"North Adelaide","C201912CAT11AF11":112718,"M201911CAT11AM11":102467},
  {"ABSCODE":401021004,"ARAN":"Aldgate - Stirling","C201912CAT11AF11":86637,"M201911CAT11AM11":123918},
  {"ABSCODE":401011001,"ARAN":"Adelaide","C201912CAT11AF11":2603925,"M201911CAT11AM11":3327075},
  {"ABSCODE":401021005,"ARAN":"Hahndorf - Echunga","C201912CAT11AF11":41779,"M201911CAT11AM11":40658},
  {"ABSCODE":401021007,"ARAN":"Mount Barker","C201912CAT11AF11":519521,"M201911CAT11AM11":616551},
  {"ABSCODE":401021006,"ARAN":"Lobethal - Woodside","C201912CAT11AF11":35678,"M201911CAT11AM11":70998},
  {"ABSCODE":401021009,"ARAN":"Nairne","C201912CAT11AF11":5490,"M201911CAT11AM11":11209},
  {"ABSCODE":401021008,"ARAN":"Mount Barker Region","C201912CAT11AF11":29501,"M201911CAT11AM11":19401},
  {"ABSCODE":401021003,"ARAN":"Adelaide Hills","C201912CAT11AF11":9035,"M201911CAT11AM11":25432},
  {"ABSCODE":401021010,"ARAN":"Uraidla - Summertown","C201912CAT11AF11":1401,"M201911CAT11AM11":5010}
  ]


 const ALLOWED_FIELDS = [
 'T03C26CR2RL5',
 'T01C15CR1RL6',
 'T03C37CR2RL5',  'xxxxxxxxxxxx'  ,'4444'
 ];



 let weex = getSelCodes (newman  , 'ABSCODE')

 let poo= pickReduce (comp, ALLOWED_FIELDS )
 console.log('pickReduce ',  poo  , weex)

 let ne = selectPop('M', dates, mers , sex , dob)

 console.log('ne  ',  ne )



//T01C01CR0RL0


let CMTYPE=[ '01','02' ]  //T01 -  Cmplnt_Type
let CMCAT=[ '01','02','03','04','05','06' ]  //C07 - Cmplnt_Category up to 54
let CMRESTIME=[ '0','1','2','3' ]  // CR1 -  CRESTIME resolution with 7 days 
let CMRELYEARS=[ '0','1','2','3','4','5','6','7']  //  RL6 - LENGTH_OF_RELATIONSHIP

export function selectPopC( CMTYPE, CMCAT , CMRESTIME , CMRELYEARS) {
 
  let final = [];
  const C = 'C';
  const T ='T'
  const CR ='CR'
  const RL ='RL'

  //set defaults
  if (CMTYPE.length < 1)    {  CMTYPE=  [ '01','02','03','04','05','06','07','08','09','10','11','12','13','15','16','17' ] } 

  if (CMCAT.length < 1)  {  CMCAT=[ '01','02','03','05','06','07','08','09','10','11','12','13','15','16','17','18','19','20','21' ]} 
 
  if (CMRESTIME.length < 1)  {  CMRESTIME=  [ '0','1','2','3' ]} 

  if (CMRELYEARS.length < 1)  { CMRELYEARS =[ '0','1','2','3','4','5','6','7']} 



  for (let i = 0; i < CMTYPE.length; i++) {
    let c1 = `${T}${CMTYPE[i]}`;

    for (let j = 0; j < CMCAT.length; j++) {
      let c2 = `${c1}${C}${CMCAT[j]}`;


      for (let k = 0; k < CMRESTIME.length; k++) {
        let c3 = `${c2}${CR}${CMRESTIME[k]}`;


        for (let m = 0; m < CMRELYEARS.length; m++) {
          let c4 = `${c3}${RL}${CMRELYEARS[m]}`;


          final.push(c4);


        }
      }
    }
  }
  return final;
 }
 
 const xcc =selectPopC( CMTYPE, CMCAT , CMRESTIME , CMRELYEARS)
 console.log('xcc ' ,xcc)



 export function selectPopD( CMTYPE,  CMRESTIME , CMRELYEARS) {
 
  let final = [];
  const C = 'C';
  const T ='T'
  const CR ='CR'
  const RL ='RL'

  //set defaults
  if (CMTYPE.length < 1)    {  CMTYPE=  [ '01','02','03','04','05','06','07','08','09','10','11','12','13','15','16','17' ] } 

 
  if (CMRESTIME.length < 1)  {  CMRESTIME=  [ '0','1','2','3' ]} 

  if (CMRELYEARS.length < 1)  { CMRELYEARS =[ '0','1','2','3','4','5','6','7']} 



  for (let i = 0; i < CMTYPE.length; i++) {
    let c1 = `${T}${CMTYPE[i]}`;

  

      for (let k = 0; k < CMRESTIME.length; k++) {
        let c2 = `${c1}${CR}${CMRESTIME[k]}`;


        for (let m = 0; m < CMRELYEARS.length; m++) {
          let c3 = `${c2}${RL}${CMRELYEARS[m]}`;


          final.push(c3);


        }
      }
    
  }
  return final;
 }



 /*


 T01C07CR1RL6

 T01 -  Cmplnt_Type
 C07 - Cmplnt_Category
 CR1 -  CRESTIME 
 RL6 - LENGTH_OF_RELATIONSHIP

 if LENGTH_OF_RELATIONSHIP  < =12 then LR ='RL1';
if    36  >=   LENGTH_OF_RELATIONSHIP  > 12 then LR ='RL2';
if    60  >=   LENGTH_OF_RELATIONSHIP  > 36 then LR ='RL3';
if    120  >=   LENGTH_OF_RELATIONSHIP  > 60 then LR ='RL4';
if   240  >=   LENGTH_OF_RELATIONSHIP  > 120 then LR ='RL5';
if      LENGTH_OF_RELATIONSHIP  > 240 then LR ='RL6';
if      LENGTH_OF_RELATIONSHIP = .  then LR ='RL7';


if CRESTIME =0 then R_ = 'CR0'; 
if CRESTIME <= 7 and CRESTIME  not in (.)  then R_ = 'CR1';
if CRESTIME > 7 and CRESTIME  not in (.)  then R_ = 'CR2';
if CRESTIME  in (.)  then R_ = 'CR3';

Access	101
Advisor Issues	102
Business Decision	103
Communicat. Information Advice	104
Credit Decision	105
Introducer	106
Investment Issues	107
Letter of Notification	108
Other Bank ATM	109
Process	110
Product Features	111
Rates, Fees & Charges	112
Security	113
Service Failure	114
Service Quality	115
St George/Bank SA ATM	116
Westpac ATM	117


 */