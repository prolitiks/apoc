/* eslint-disable */

//login functionality

export const logsub = async e => {
  //delete existing cookies
  console.log('logsub works.....', e);

  Cookies.remove('tokendata');
  let transport = axios.create({
    withCredentials: true
  });

  await transport.interceptors.response.use(
    function(response) {
      console.log('intercepted.....');
      return response;
    },
    function(error) {
      const errorResponse = error.response;
      console.log('err.....', errorResponse.status);
      console.log('errmessage.....', errorResponse.data.message);
      console.log('errobj.....', errorResponse);
      let badpass = errorResponse.data.message;

      //put message in the login screen here
      document
        .querySelector(`#passin`)
        .insertAdjacentHTML('afterEnd', `<div id='l1' class ='badattemp'>${badpass}</div>`);
      return Promise.reject(error);
    }
  );

  //get imput fields from login

  let userin = document.getElementById('userin').value;
  let passin = document.getElementById('passin').value;
  console.log('userin... ', userin);
  console.log('passin... ', passin);
  const lgin = {
    email: userin, //create a form for the user and password
    password: passin
  };
  console.log('lgin  ... ', lgin);

  try {
    const response = await transport({
      url: `/v1/auth/login`,
      method: 'post',
      data: lgin,
      onDownloadProgress: function(progressEvent) {}
    });

    await response.data;
    console.log('axios data ', response.data);
    await Cookies.set('tokendata', response.data);

    //change the dom here if sucess
    //window.location.replace('/v1/users/5d49340e1af22213a415f0e7/profile');

    return response.data;
  } catch (e) {
    console.log(e.message);
  }
};

export function putLoggedInInfoInBar(info) {
  console.log('ive put the logged into inf in nav bar ', info);

  //create elemt with email here :
  const startSel = document.querySelector(`#LG`);
  startSel.insertAdjacentHTML('beforebegin', `<span id ='lg-email'  class="uk-badge"  > ${info}</span> `);
}

//signout fuction

export function signOut() {
  console.log('we signed out ');

  Cookies.remove('tokendata');
  const lgButt = document.querySelector(`#LG`);

  lgButt.textContent = 'LOGIN';

  lgButt.addEventListener('click', LgIn);

  let d = document.getElementById('nav-top-m');
  let d_nested = document.getElementById('lg-email');

  console.log(' d_nested ', d_nested);
  if (d_nested) {
    d.removeChild(d_nested);
  }
}

export const logCookieFind = async cbyes => {
  let cookie = Cookies.get('tokendata');

  if (cookie) {
    const CK = JSON.parse(cookie);
    cbyes(CK.data.user.email);
  } else {
    console.log('need to login ', cookie);
  }
};

