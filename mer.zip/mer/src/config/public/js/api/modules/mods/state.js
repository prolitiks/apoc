/* eslint-disable */




//https://www5.putlockerhd.io/film/war-of-the-worlds-2019-season-1/watching.html?ep=1



export let ProjObj = {
  ProjectName : ''
}

export let ConfigObj = {
  SELDATA: { RAR_DATA: [] },

  CHFIG: {},

  DTR: {
    CHRNAME: [
      { key: '20.00', val: 'LINE' },
      { key: '30.00', val: 'BAR' },
      { key: '40.00', val: 'PIE' },
      { key: '50.00', val: 'MAP' }
    ],

    CHRSEL: [],

    CHRSELNAME: [],

    SELNAME: [],

    DTSEL: [],
    //slider staTE
    DTARR: [
      { YMC: 1, YM: '201601' },
      { YMC: 2, YM: '201602' },
      { YMC: 3, YM: '201603' },
      { YMC: 4, YM: '201604' },
      { YMC: 5, YM: '201605' },
      { YMC: 6, YM: '201606' },
      { YMC: 7, YM: '201607' },
      { YMC: 8, YM: '201608' },
      { YMC: 9, YM: '201609' },
      { YMC: 10, YM: '201610' },
      { YMC: 11, YM: '201611' },
      { YMC: 12, YM: '201612' },
      { YMC: 13, YM: '201701' },
      { YMC: 14, YM: '201702' },
      { YMC: 15, YM: '201703' },
      { YMC: 16, YM: '201704' },
      { YMC: 17, YM: '201705' },
      { YMC: 18, YM: '201706' },
      { YMC: 19, YM: '201707' },
      { YMC: 20, YM: '201708' },
      { YMC: 21, YM: '201709' },
      { YMC: 22, YM: '201710' },
      { YMC: 23, YM: '201711' },
      { YMC: 24, YM: '201712' },
      { YMC: 25, YM: '201801' },
      { YMC: 26, YM: '201802' },
      { YMC: 27, YM: '201803' },
      { YMC: 28, YM: '201804' },
      { YMC: 29, YM: '201805' },
      { YMC: 30, YM: '201806' },
      { YMC: 31, YM: '201807' },
      { YMC: 32, YM: '201808' },
      { YMC: 33, YM: '201809' },
      { YMC: 34, YM: '201810' },
      { YMC: 35, YM: '201811' },
      { YMC: 36, YM: '201812' },
      { YMC: 37, YM: '201901' },
      { YMC: 38, YM: '201902' },
      { YMC: 39, YM: '201903' },
      { YMC: 40, YM: '201904' },
      { YMC: 41, YM: '201905' },
      { YMC: 42, YM: '201906' },
      { YMC: 43, YM: '201907' },
      { YMC: 44, YM: '201908' },
      { YMC: 45, YM: '201909' },
      { YMC: 46, YM: '201910' },
      { YMC: 47, YM: '201911' },
      { YMC: 48, YM: '201912' },
      { YMC: 49, YM: '202001' },
      { YMC: 50, YM: '202002' },
      { YMC: 51, YM: '202003' },
      { YMC: 52, YM: '202004' },
      { YMC: 53, YM: '202005' },
      { YMC: 54, YM: '202006' },
      { YMC: 55, YM: '202007' },
      { YMC: 56, YM: '202008' },
      { YMC: 57, YM: '202009' },
      { YMC: 58, YM: '202010' },
      { YMC: 59, YM: '202011' },
      { YMC: 60, YM: '202012' }
    ]
  },

  DRPOBC: {
    SEEDR: [
      {
        name: 'DATA-SELECTION',
        code: '1',
        ctype: 'DTYPE',
        prefix: 'D',
        drpdwnSelected: [],
        drpdwn: [     
        ]
      },

      {
        name: 'LINE-SELECTION',
        code: '2',
        ctype: 'LTYPE',
        prefix: 'L',
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Thin', code: '0' },
          { name: 'Meduim', code: '1' },
          { name: 'Thick', code: '2' }
        ]
      }
    ]
  },
  
  DRPOB: {
    SEEDR: [
      {
        name: 'COMPLAINT-TYPE',
        code: '2',
        ctype: 'CMTYPE',
        prefix: 'T',
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Access', code: '01' },
          { name: 'Advisor-Issues', code: '02' },
          { name: 'Business-Decision', code: '03' },
          { name: 'Comms-Information-Advice', code: '04' },
          { name: 'Credit-Decision', code: '05' },
          { name: 'Introducer', code: '06' },
          { name: 'Investment-Issues', code: '07' },
          { name: 'Letter-of-Notification', code: '08' },
          { name: 'Other-Bank-ATM', code: '09' },
          { name: 'Process', code: '10' },
          { name: 'Product-Features', code: '11' },
          { name: 'Rates-Fees-Charges', code: '12' },
          { name: 'Security', code: '13' },
          { name: 'Service-Failure', code: '14' },
          { name: 'Service-Quality', code: '15' },
          { name: 'St-George-Bank-SA-ATM', code: '16' },
          { name: 'Westpac-ATM	', code: '17' }
        ]
      },

      {
        name: 'RESOLVE-TIME',
        code: '1',
        ctype: 'CMRESTIME',
        prefix: 'CR',
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Immediately', code: '0' },
          { name: 'Within-7-days', code: '1' },
          { name: 'More-than-7-days', code: '2' },
          { name: 'Unknown', code: '3' }
        ]
      },

      {
        name: 'CUSTOMER-TENURE',
        code: '3',
        ctype: 'CMRELYEARS',
        prefix: 'RL',
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Less-than-1-year', code: '1' },
          { name: '1-3-years', code: '2' },
          { name: '3-5-years', code: '3' },
          { name: '5-10-years', code: '4' },
          { name: '10-20-years', code: '5' },
          { name: 'More-than-20-years', code: '6' },
          { name: 'Unknown', code: '7' }
        ]
      }
    ]
  }
};