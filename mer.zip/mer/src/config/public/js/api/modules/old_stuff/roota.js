/* eslint-disable */

//login functionality

Cookies.remove('tokendata');

const logsub = async e => {
  //delete existing cookies
  console.log('logsub works.....', e);

  //delete existing cookies
  //remove exsiting html
  //const warntext = document.querySelector(`#l1`);

 // console.log('warntext.....', warntext  );

  // if (warntext !== null) {
  //   warntext.remove();
  // }

  Cookies.remove('tokendata');

  let transport = axios.create({
    withCredentials: true
  });

  await transport.interceptors.response.use(


    function(response) {
      console.log('intercepted.....');
      return response;
    },
    function(error) {
      const errorResponse = error.response;
      console.log('err.....', errorResponse.status);
      console.log('errmessage.....', errorResponse.data.message);
      console.log('errobj.....', errorResponse);
      let badpass = errorResponse.data.message;

      //put message in the login screen here
      document
        .querySelector(`#passin`)
        .insertAdjacentHTML('afterEnd', `<div id='l1' class ='badattemp'>${badpass}</div>`);
      return Promise.reject(error);
    }
  );

  //get imput fields from login

  let userin = document.getElementById('userin').value;
  let passin = document.getElementById('passin').value;
  console.log('userin... ', userin);
  console.log('passin... ', passin);
  const lgin = {
    email: userin, //create a form for the user and password
    password: passin
  };
  console.log('lgin  ... ', lgin);

  //const da = { email: 'dave@prolitiks.com', password: 'thewinner' };

  try {
    const response = await transport({
      url: `v1/auth/login`,
      method: 'post',
      data: lgin,
      onDownloadProgress: function(progressEvent) {}
    });


    await response.data;
    console.log('axios data ', response.data);
    await Cookies.set('tokendata', response.data);

    //change the dom here if sucess
     //window.location.replace('/v1/users/5d49340e1af22213a415f0e7/profile');
    
    // //remove dropdown
    // document.querySelector(`#DROPLOG`).remove();
    // //change lognin button to signout + actually signout
   // document.querySelector(`#LG`).textContent = 'SIGNOFF';
    // //function to signoff and reset login
    return response.data;
  } catch (e) {
    console.log(e.message);
  }
};


function putLoggedInInfoInBar(info) {
  console.log('ive put the logged into inf in nav bar ', info);

  //create elemt with email here :
  const startSel =    document.querySelector(`#LG`)
  startSel.insertAdjacentHTML(
    'beforebegin',
    `<span id ='lg-email'  class="uk-badge"  > ${info}</span> `
  );

}


//signout fuction

function signOut() {
  //clear token data

  //CHANGE BUTTION

  //go back to hme page
  console.log('we signed out ');

  Cookies.remove('tokendata');
  const lgButt = document.querySelector(`#LG`);
  //change id and add event listener to button
  lgButt.textContent = 'LOGIN';
 // lgButt.id = 'LG';
  lgButt.addEventListener('click', LgIn);

  let d = document.getElementById('nav-top-m');
  let d_nested = document.getElementById('lg-email');

  console.log( ' d_nested '  , d_nested   )
  if ( d_nested    )  {
   d.removeChild(d_nested); 
  }


}


let logCookieFind = async cbyes => {
  let cookie = Cookies.get('tokendata');

  if (cookie) {
    const CK = JSON.parse(cookie);
    cbyes(CK.data.user.email);
  
  } else {
    console.log('need to login ', cookie);
  }
};


let log = s => {
  console.log(s);
};




let T1 = function() {

  let cookie = Cookies.get('tokendata');

  if (cookie) {
    const CK = JSON.parse(cookie);
    console.log('you got cookies fag ', CK);
  
  } else {
    console.log('need to login ');
  }



};

let LgIn = function() {
  log('T1');
  let dom = `<div class="uk-margin">
<H3>Login</H3>
<input id ='userin' class="uk-input uk-form-width-small uk-form-small" type="text" placeholder="User" required>
</div>
<div class="uk-margin">
<input id ='passin'  class="uk-input uk-form-width-small uk-form-small" type="password" placeholder="Password" required>
</div>   <br>
Keep me logged in:  <input class="uk-checkbox" type="checkbox">
`;
  UIkit.modal.confirmx(dom, logsub).then(
    function() {
      console.log('Confirmed. ');
      logCookieFind(putLoggedInInfoInBar);
      const lgButt = document.querySelector(`#LG`)
      //change id and add event listener to button
      lgButt.textContent = 'SIGNOFF';
    //  lgButt.id= 'SOUT';
      lgButt.removeEventListener('click', LgIn);
      lgButt.addEventListener('click',  signOut );
      //need a signoff event listener here

    },
    function() {
      console.log('Rejected.');
    }
  );
};




function CreateStartGrid(GridId, selmain) {
  const startSel = document.querySelector(`#${selmain}`);
  startSel.insertAdjacentHTML(
    'beforeend',
    `<div id ='GridStart-${GridId}' uk-grid  >
    </div>`
  );
}




let T2 = function() {
  // logsub().then( ( cd ) =>  console.log  ('val ' , cd )      )

  let cookie = Cookies.get('tokendata');

  if (cookie) {
    const CK = JSON.parse(cookie);

    console.log('you got cookies fag ', `/v1/users/${CK.data.user.id}/profile`);
  } else {
    console.log('need to login ');
  }

  // window.location.replace('/v1/users/5d49340e1af22213a415f0e7/profile');
};

let T3 = function() {
//  Cookies.remove('tokendata');

//console.log('cooks   ' ,  Cookies.get() );

};

//global vars
//Select serioes var


// let dataSegID = 99; //box for the data seg   CreateBoxCard
// let BoxCardID = 99; //box for the data seg   CreateBoxCard
// let selID = 99; //smallest level for data seg  let xnewsel = function(id  ,  obj ,  sel )
// let BoxCardContID  = 99; //smallest level for data seg  let xnewsel = function(id  ,  obj ,  sel )
// let gridID = 99; //main-box-sel  the highest level id everything goes in here
// let projID = 99; // the id for the project only one for each page
// let mObj = [];


let BoxCardID = 99; //box for the data seg   CreateBoxCard
let BoxCardContID  = 99; //smallest level for data seg  let xnewsel = function(id  ,  obj ,  sel )
let BoxMainID = 99; //main-box-sel  the highest level id everything goes in here


//BoxMainID 
//example CreateMain(99, 'main-box-sel');      <div id = "main-box-sel" ></div>
function CreateMain(BoxMainID, selmain) {
  const startSel = document.querySelector(`#${selmain}`);
  startSel.insertAdjacentHTML(
    'beforeend',
    `<div id ='GridStart-${BoxMainID}' uk-grid  >
    </div>`
  );
}

//CreateBoxCard (BoxCardID , 3  , `GridStart-${BoxMainID}` , 'xxxxx' );   
function CreateBoxCard (BoxCardID, gridSize, BoxMainID, selTitle) {
  const startSel = document.querySelector(`#${BoxMainID}`);
  startSel.insertAdjacentHTML(
    'beforeend',
    ` <div class="uk-width-1-${gridSize}@m">
       <div id="SelCard-${BoxCardID}" class="uk-card uk-card-default uk-card-body">  
       <div class="uk-clearfix">
      ${selTitle}  <div class="uk-float-right">
      <a id='seg-show-add-${BoxCardID}' ><span  id='seg-show-add-${BoxCardID}'  uk-icon="icon: plus; ratio: .75"></span> </a> 
      </div> </div> <br>
      <section  id ='seg-card-add-${BoxCardID}'  >
      </section> </div> </div> `
  );
}


let CreateBoxCardContent = function(BoxCardContID,  BoxCardID , htmlContent  ) {
 
  const startgrid = document.querySelector(`#SelCard-${BoxCardID}`);
  startgrid.insertAdjacentHTML(
    'beforeend',
    `<div id='S${BoxCardContID}' class="uk-lbcont Sel">        <br>    
    ${htmlContent} 
     </div>
     </div>
    </div>   `
  );
  }  






let T4 = function() {

  //function CreateBoxCard (CardId, gridSize, selmain, selTitle)

};




let T5 = function() {


};



let T6 = function() {

  BoxMainID  = BoxMainID  + 1
  BoxCardID  = BoxCardID + 1

  BoxCardContID  = BoxCardContID+ 1


  CreateMain(BoxMainID, 'main-box-sel')
  CreateBoxCard (BoxCardID , 3  , `GridStart-${BoxMainID}` , 'xxxxx' );
  CreateBoxCardContent (BoxCardContID,  BoxCardID , 'winner'  )
  CreateBoxCardContent (BoxCardContID,  BoxCardID , 'winner'  )
  CreateBoxCardContent (BoxCardContID,  BoxCardID , 'winner'  )
  


};
let T7 = function() {};
let T8 = function() {};
let T9 = function() {};
let T10 = function() {};

document.querySelector('#T1').addEventListener('click', T1);
document.querySelector('#T2').addEventListener('click', T2);
document.querySelector('#T3').addEventListener('click', T3);
document.querySelector('#T4').addEventListener('click', T4);
document.querySelector('#T5').addEventListener('click', T5);
document.querySelector('#T6').addEventListener('click', T6);
document.querySelector('#T7').addEventListener('click', T7);
document.querySelector('#T8').addEventListener('click', T8);
document.querySelector('#T9').addEventListener('click', T9);
document.querySelector('#T10').addEventListener('click', T10);

document.querySelector(`#LG`).addEventListener('click', LgIn);
