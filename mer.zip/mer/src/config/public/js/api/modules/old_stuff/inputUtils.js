/* eslint-disable */


 function square(x) {
    return x * x;
}


export {square}



function keyserc (e)
{
//console.log('keys :' , e.code  )
 let curval =document.getElementById("in1").value
  if ( curval.length >  2  )
 {
  let fuzcode =`&FUZ=${encodeURIComponent(curval)}`
getAllStuff2 (`limit=10&perPage=10${fuzcode}`, 1, `card/fuzz`  ,`&sort=MerText:desc` )
  console.log('curval  :' , fuzcode )
 }
}

