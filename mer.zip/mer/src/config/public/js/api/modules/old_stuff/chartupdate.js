/* eslint-disable */


async function getEx() {
   
  //get the codes from each of the objects
  
    let CMTYPE = await getSelCodes(CMTYPE_A);
    let CMRESTIME = await getSelCodes(CMRESTIME_A );
    let CMRELYEARS = await getSelCodes(CMRELYEARS_A);
    let selected_fields = await selectPopD( CMTYPE,  CMRESTIME , CMRELYEARS);
    
    let sldr =startSlider.noUiSlider.get()
    let mindte =Math.trunc(sldr[0]/10) +8;
    let maxdte =Math.trunc(sldr[1]/10) +8;
    let jsonObj = await getDataComp(mindte ,maxdte );  //put date parms in here 
    let coll = await jsonObj.data;
  
      await console.log( 'selected_fields  ', selected_fields )
      await console.log( 'coll ', coll  )
     
      await console.log( 'SLIDE------------------ ', mindte  , maxdte  )
  
     //create the object for the chart here :
     //need to include the date range here 
     //need to create a key value   array of objects
  
       let arr=[]
       let xcat =[]
  
       //coll is the name of the collection od data we need to reduce this data  ;
  
         await coll.map(function(prps, x) {
   
       // let date= new Date( parseInt (prps.CYM.substring(2, 6))  + '-' +  parseInt (prps.CYM.substring(7, 2)) +'-01' )
       // let date= new Date( prps.CYM.substring(2, 6)  + '-' +  prps.CYM.substring(6)  +  '-01'  )

       let  date=  prps.CYM.substring(2, 6)  +  prps.CYM.substring(6)  
           let yr =   parseInt   ( prps.CYM.substring(2, 6)   )
           let mth  = parseInt   (  prps.CYM.substring(6)  )
           let dy =1;
  
  //get the props from th YM field  
          console.log  ('prps.YM  ' , prps.YM  )
          console.log  ('x------------  ' , x  )
          console.log  ('prps.CYM  ' , prps.CYM   )
          console.log  ('yr ' , yr   )
          console.log  ('mth ' , mth   )
  
         let dateUTC  = Date.UTC(yr, mth,  dy)  ;
         
         let datatwo  = new Date (  dateUTC  )
   
         console.log  ('DateUTC ' , dateUTC   )
         console.log  ('date  ' ,date     )
  
        let obj=    {  name:  parseInt (prps.CYM.substring(2, 8))   ,    y:   pickReduce(prps, selected_fields)  }
  
        arr.push( obj  )
        xcat.push( date  )
    });
  
    await console.log( 'xcat  ', xcat)
    await console.log( 'arr    ', arr  )
  
    await HC (arr ,   xcat)
  
  }
  