/* eslint-disable */


const object =   { name: 'COMPLAINT-TYPE' , code : '1'  ,   drpdwn : 'CMTYPE' }
const picked = (({ name, code  }) => ({  name, code }))(object);

console.log(picked); // { a: 5, c: 7 }


//create function that pushes object into in to a



let SEEDR = [
  {
    name: "COMPLAINT-TYPE",
    code: "2",
    drpdwn: [
      { name: "Access", code: "01" },
      { name: "Advisor-Issues", code: "02" },
      { name: "Business-Decision", code: "03" },
      { name: "Comms-Information-Advice", code: "04" },
      { name: "Credit-Decision", code: "05" },
      { name: "Introducer", code: "06" },
      { name: "Investment-Issues", code: "07" },
      { name: "Letter-of-Notification", code: "08" },
      { name: "Other-Bank-ATM", code: "09" },
      { name: "Process", code: "10" },
      { name: "Product-Features", code: "11" },
      { name: "Rates-Fees-Charges", code: "12" },
      { name: "Security", code: "13" },
      { name: "Service-Failure", code: "14" },
      { name: "Service-Quality", code: "15" },
      { name: "St-George-Bank-SA-ATM	", code: "16" },
      { name: "Westpac-ATM	", code: "17" }
    ]
  },

  {
    name: "RESOLVE-TIME",
    code: "1",
    drpdwn: [
      { name: "Immediately", code: "0" },
      { name: "Within-7-days", code: "1" },
      { name: "More-than-7-days", code: "2" },
      { name: "Unknown", code: "3" }
    ]
  },

  {
    name: "CUSTOMER-TENURE",
    code: "3",
    drpdwn: [
      { name: "Less-than-1-year", code: "1" },
      { name: "1-3-years", code: "2" },
      { name: "3-5-years", code: "3" },
      { name: "5-10-years", code: "4" },
      { name: "10-20-years", code: "5" },
      { name: "More-than-20-years", code: "6" },
      { name: "Unknown", code: "7" }
    ]
  }
];



function getstuff ( arr  , charr)  {

for(let i = 0; i < arr.length; i++){

   let childArray = arr[i][charr];

   for(let j = 0; j < childArray.length; j++){

  console.log(childArray[j]);

   }

}


}


//getstuff(myArray ,"child" )



getstuff(SEEDR ,'drpdwn')



export function selectPopD( CMTYPE,  CMRESTIME , CMRELYEARS) {
 
  let final = [];
  const T ='T'
  const CR ='CR'
  const RL ='RL'

  //set defaults
  if (CMTYPE.length < 1)    {  CMTYPE=  [ '01','02','03','04','05','06','07','08','09','10','11','12','13','15','16','17' ] } 
  if (CMRESTIME.length < 1)  {  CMRESTIME=  [ '0','1','2','3' ]} 
  if (CMRELYEARS.length < 1)  { CMRELYEARS =[ '1','2','3','4','5','6','7']} 

  for (let i = 0; i < CMTYPE.length; i++) {
    let c1 = `${T}${CMTYPE[i]}`;
      for (let k = 0; k < CMRESTIME.length; k++) {
        let c2 = `${c1}${CR}${CMRESTIME[k]}`;
        for (let m = 0; m < CMRELYEARS.length; m++) {
          let c3 = `${c2}${RL}${CMRELYEARS[m]}`;
          final.push(c3);
        }
      }
  }
  return final;
 }

 


 const arrayOfObject = [
  {
    name: "Paul",
    country: "Canada"
  },
  {
    name: "Lea",
    country: "Italy"
  },
  {
    name: "John",
    country: "Italy"
  }
];

let lea = arrayOfObject.filter(function(obj) {
  //loop through each object
  for (key in obj) {
    //check if object value contains value you are looking for
    if (obj[key].includes("Lea")) {
      //add this object to the filtered array

      console.log(obj);


      return obj;
    }
  }
});
  


function reee (  ob , name , value)  {


 ob.filter(function(obj) {
  //loop through each object
 
    //check if object value contains value you are looking for
    if (obj[name ].includes(value)) {
      //add this object to the filtered array

      console.log(obj);

      
      return obj;
    }
  
});


}


 
 reee(SEEDR,'name' , "COMPLAINT-TYPE" )



 
//this unction takes the elemt object from the array and pushes it back into 
function addPillx(atype ,tobj ,ttype ,code ) {

 

  //const actiontype = e.target.innerHTML; 
 // const actiontype = '1-3-years' 
   const actiontype = atype

 // let targObj = eval(e.target.classList[0]);
  //let targObj = CMRELYEARS  ;
  let targObj = tobj  ;
  

 //let tartype = e.target.classList[0];
  let tartype = ttype;

 // let tartcode = e.target.classList[1];
  let tartcode = 1 //need to make this the index

  const node = document.createElement('SPAN');
  const node2 = document.createElement('SPAN');
  const textnode2 = document.createTextNode('x');
  const textnode = document.createTextNode(actiontype);
  node.appendChild(textnode);
  node.appendChild(node2);
  node2.appendChild(textnode2);
  node2.classList.add('close');
  node.classList.add('closea');
  node.classList.add(tartype, tartcode);
  //document.getElementById('selmulti').appendChild(node);
  let boxel =  document.getElementById(`${tartype}-B`)
    boxel.appendChild(node);
   console.log('boxel ',  boxel)

  let arrtype = eval(`${tartype}_A`);
 

  console.log('tartype '  ,   tartype)
  console.log('targObj'  ,   targObj)
  console.log('tartcode '  ,   tartcode)
  console.log('tactiontype ' ,   actiontype)
  console.log('arrtype '  ,   arrtype)


  //take out the selected from the dropdown for next time  document.querySelector("#MERCAT-DROP")
  for (let m = 0; m < targObj.length; m++) {
    if (targObj[m].name === actiontype) {
        console.log('targObj[m].name  ', targObj[m]);
      arrtype.push(targObj[m]);
      targObj.splice(m, 1);
        console.log('targObj x2  ', targObj);
        console.log('targObj M  ', m , tartype);
      let filldropx = document.querySelector(`#${tartype}-DROP > li:nth-child(${m+1}) > a`);
        console.log('filldrop xx  M  ', filldropx);
     filldropx.parentNode.remove();

    }
  }



  // node.addEventListener('click', function() {
  //   let ps = this.classList[2];
  //   let name = this.firstChild.nodeValue;
  //   console.log('ps ', this.classList);
  //   this.remove();
  //   targObj.splice(0, 0, { name: name, code: ps, action: addPill });
  //   //need to remove here get index first
  //   let removeIndex = arrtype
  //     .map(function(item) {
  //       return item.name;
  //     })
  //     .indexOf(actiontype);
  //      arrtype.splice(removeIndex, 1);

  //   console.log('targObj remove ', targObj);
  //   console.log('arrtype remove ', arrtype);

  //   let dropob = targObj;
  //   let filldrop = document.getElementById(`${tartype}-DROP`);

  //   //remove siblinings first
  //   while (filldrop.hasChildNodes()) {
  //     filldrop.removeChild(filldrop.firstChild);
  //   }
  //   for (var k = 0; k < dropob.length; k++) {
  //     filldrop.insertAdjacentHTML(
  //       'beforeEnd',
  //       `<li><a class ="${tartype} ${ps}"  href="#" >${dropob[k].name}</a></li>`
  //     );
  //     filldrop.addEventListener('click', dropob[k].action);
  //   }
  // });
}
