

/* eslint-disable */

console.log('hi from chart  !!!!!');

//example of array of objects for charting
let testob = [
  {
    key: "G1",
    value: {
      GRLOC: ["Adelaide"],
      GRLOCODE: ["401011001"],
      GSTARTD: 20789,
      GENDD: 20794,
      GYEAR: "Y1",
      GMEAS: "TMRM1D",
      GAMT: 15486829
    }
  },
  {
    key: "G2",
    value: {
      GRLOC: [
        "Richmond (SA)",
        "Hindmarsh - Brompton",
        "North Adelaide",
        "Walkerville",
        "St Peters - Marden",
        "Burnside - Wattle Park"
      ],
      GRLOCODE: [
        "404031108",
        "404011093",
        "401011002",
        "401061022",
        "401051019",
        "401031011"
      ],
      GSTARTD: 20789,
      GENDD: 20794,
      GYEAR: "Y1",
      GMEAS: "TMRM1D",
      GAMT: 7762682
    }
  }
  ,
  {
    key: "G3",
    value: {
      GRLOC: [
        "Richmond (SA)",
        "Hindmarsh - Brompton",
        "North Adelaide",
        "Walkerville",
        "St Peters - Marden",
        "Burnside - Wattle Park"
      ],
      GRLOCODE: [
        "404031108",
        "404011093",
        "401011002",
        "401061022",
        "401051019",
        "401031011"
      ],
      GSTARTD: 20789,
      GENDD: 20794,
      GYEAR: "Y1",
      GMEAS: "TMRM1D",
      GAMT: 7762682
    }
  }
  ,
  {
    key: "G4",
    value: {
      GRLOC: [
        "Richmond (SA)",
        "Hindmarsh - Brompton",
        "North Adelaide",
        "Walkerville",
        "St Peters - Marden",
        "Burnside - Wattle Park"
      ],
      GRLOCODE: [
        "404031108",
        "404011093",
        "401011002",
        "401061022",
        "401051019",
        "401031011"
      ],
      GSTARTD: 20789,
      GENDD: 20794,
      GYEAR: "Y1",
      GMEAS: "TMRM1D",
      GAMT: 7762682
    }
  }


];


function dtSAStoJS(dtSAS, dtType = "DATE") {
  if (dtSAS === null) {
    return null;
  } else if (dtType === "DATE") {
    return new Date(-315619200000 + dtSAS * 86400000);
  } else if (dtType === "DATETIME") {
    return new Date(-315619200000 + dtSAS * 1000);
  } else {
    return null;
  }
}

let cc = testob;
var fillclr;

const handlem = (d, i, n) => {

  console.log(d.value.GAMT )
  d3.select(n[i])
    .transition()
    .duration(10)
    .attr("fill", "#737373")
   
   
//this puts the value of the d3 data into the html elemt 
//div id = "btmdiv" >b>Location: </b> <ul id = "GRLOCLIST"  style=" margin:5px ;padding-left: 10px ;font: 10px Arial, Helvetica, sans-serif;"></ul><br></div > 
  var u = d3
    .select("#GRLOCLIST")
    .selectAll("li")
    .data(d.value.GRLOC);  
  
    
  u.enter()
    .append("li")
    .merge(u)
    .text(function(d) {
      return d;
    });
  u.exit().remove();

};
const handlemout = (d, i, n) => {
  d3.select(n[i])
    .transition()
    .duration(10)
    .attr("fill", "#d9d9d9");
};


function barChart() {
  
  let cc = testob;
  // add width for no of groups
  let gwidth = 4 * (5 - 1);
  var margin = {
    top: 20,
    right: 10,
    bottom: 20,
    left: 40
  };
  var width = 110 + gwidth - margin.left - margin.right,
    height = 110 - margin.top - margin.bottom;

  var svg = d3
    .select("#chartid")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

  let x = d3
    .scaleBand()
    .paddingInner(0.1)
    .paddingOuter(0.1);
  let y = d3.scaleLinear().range([height, 0]);

  y.domain([0, d3.max(cc.map(a => a.value.GAMT))]);
  x.domain(cc.map(a => a.key)).range([0, width]);
  const rects = svg.selectAll("rect").data(cc);

   
  rects.exit().remove();
  rects
    .attr("width", x.bandwidth)
    .attr("height", d => height - y(d.value))
    .attr("fill", function(d) {
      return d.key == fillclr ? "#969696" : "#d9d9d9";
    })
    .attr("x", d => x(d.key))
    .attr("y", d => y(d.value.GAMT))
  

  rects
    .enter()
    .append("rect")
    .attr("width", x.bandwidth)
    .attr("height", d => height - y(d.value.GAMT))
    .attr("fill", function(d) {
      return d.key == fillclr ? "#969696" : "#d9d9d9";
    })
    .attr("x", d => x(d.key))
    .attr("y", d => y(d.value.GAMT))
    .attr(`uk-tooltip`,  d => d.value.GAMT )
    

    .on("mouseover", handlem )
    .on("mouseout", handlemout);
   
  const xAxisGroup = svg
    .append("g")
    .attr("transform", `translate(0, ${height} )`);
  const yAxisGroup = svg.append("g");
  const xAxis = d3.axisBottom(x).tickSize(2);
  const yAxis = d3
    .axisLeft(y)
    .ticks(2)
    .tickSize(2)
   // .tickFormat(formt);

  xAxisGroup.call(xAxis);
  yAxisGroup.call(yAxis);
}


//barChart() 
var data = [
  {
    name: "USA",
    values: [
      {date: "2000", price: "100"},
      {date: "2001", price: "110"},
      {date: "2002", price: "145"},
      {date: "2003", price: "241"},
      {date: "2004", price: "101"},
      {date: "2005", price: "90"},
      {date: "2006", price: "10"},
      {date: "2007", price: "35"},
      {date: "2008", price: "21"},
      {date: "2009", price: "201"}
    ]
  },
  {
    name: "Canada",
    values: [
      {date: "2000", price: "200"},
      {date: "2001", price: "120"},
      {date: "2002", price: "33"},
      {date: "2003", price: "21"},
      {date: "2004", price: "51"},
      {date: "2005", price: "190"},
      {date: "2006", price: "120"},
      {date: "2007", price: "85"},
      {date: "2008", price: "221"},
      {date: "2009", price: "101"}
    ]
  },
  {
    name: "Maxico",
    values: [
      {date: "2000", price: "50"},
      {date: "2001", price: "10"},
      {date: "2002", price: "5"},
      {date: "2003", price: "71"},
      {date: "2004", price: "20"},
      {date: "2005", price: "9"},
      {date: "2006", price: "220"},
      {date: "2007", price: "235"},
      {date: "2008", price: "61"},
      {date: "2009", price: "10"}
    ]
  }
];


 
/*



svg {
    font-family: Sans-Serif, Arial;
}
.line {
  stroke-width: 2;
  fill: none;
}

.axis path {
  stroke: black;
}

.text {
  font-size: 12px;
}

.title-text {
  font-size: 12px;
}
https://codepen.io/zakariachowdhury/pen/RKYEVV
*/


  function lineChart() {
  
    var width =150;
    var height = 100;
    var margin = 30;
    var duration = 300;
    
    var lineOpacity = "0.25";
    var lineOpacityHover = "0.85";
    var otherLinesOpacityHover = "0.1";
    var lineStroke = "1.5px";
    var lineStrokeHover = "2.5px";
    
    var circleOpacity = '0.85';
    var circleOpacityOnLineHover = "0.25"
    var circleRadius = 3;
    var circleRadiusHover = 6;
    
    
    /* Format Data */
    var parseDate = d3.timeParse("%Y");
    data.forEach(function(d) { 
      d.values.forEach(function(d) {
        d.date = parseDate(d.date);
        d.price = +d.price;    
      });
    });
    
    
    /* Scale */
    var xScale = d3.scaleTime()
      .domain(d3.extent(data[0].values, d => d.date))
      .range([0, width-margin]);
    
    var yScale = d3.scaleLinear()
      .domain([0, d3.max(data[0].values, d => d.price)])
      .range([height-margin, 0]);
    
    var color = d3.scaleOrdinal(d3.schemeCategory10);
    
    /* Add SVG */
    var svg = d3
    .select("#chartid")
    .append("svg")
      .attr("width", (width+margin)+"px")
      .attr("height", (height+margin)+"px")
      .append('g')
      .attr("transform", `translate(${margin}, ${margin})`);
    
    
    /* Add line into SVG */
    var line = d3.line()
      .x(d => xScale(d.date))
      .y(d => yScale(d.price));
    
    let lines = svg.append('g')
      .attr('class', 'lines');
    
    lines.selectAll('.line-group')
      .data(data).enter()
      .append('g')
      .attr('class', 'line-group')  
      .on("mouseover", function(d, i) {
          svg.append("text")
            .attr("class", "title-text")
            .style("fill", color(i))        
            .text(d.name)
            .attr("text-anchor", "middle")
            .attr("x", (width-margin)/2)
            .attr("y", 5);
        })
      .on("mouseout", function(d) {
          svg.select(".title-text").remove();
        })
      .append('path')
      .attr('class', 'line')  
      .attr('d', d => line(d.values))
      .style('stroke', (d, i) => color(i))
      .style('opacity', lineOpacity)
      .on("mouseover", function(d) {
          d3.selectAll('.line')
              .style('opacity', otherLinesOpacityHover);
          d3.selectAll('.circle')
              .style('opacity', circleOpacityOnLineHover);
          d3.select(this)
            .style('opacity', lineOpacityHover)
            .style("stroke-width", lineStrokeHover)
            .style("cursor", "pointer");
        })
      .on("mouseout", function(d) {
          d3.selectAll(".line")
              .style('opacity', lineOpacity);
          d3.selectAll('.circle')
              .style('opacity', circleOpacity);
          d3.select(this)
            .style("stroke-width", lineStroke)
            .style("cursor", "none");
        });
    
    
    /* Add circles in the line */
    lines.selectAll("circle-group")
      .data(data).enter()
      .append("g")
      .style("fill", (d, i) => color(i))
      .selectAll("circle")
      .data(d => d.values).enter()
      .append("g")
      .attr("class", "circle")  
      .on("mouseover", function(d) {
          d3.select(this)     
            .style("cursor", "pointer")
            .append("text")
            .attr("class", "text")
            .text(`${d.price}`)
            .attr("x", d => xScale(d.date) + 5)
            .attr("y", d => yScale(d.price) - 10);
        })
      .on("mouseout", function(d) {
          d3.select(this)
            .style("cursor", "none")  
            .transition()
            .duration(duration)
            .selectAll(".text").remove();
        })
      .append("circle")
      .attr("cx", d => xScale(d.date))
      .attr("cy", d => yScale(d.price))
      .attr("r", circleRadius)
      .style('opacity', circleOpacity)
      .on("mouseover", function(d) {
            d3.select(this)
              .transition()
              .duration(duration)
              .attr("r", circleRadiusHover);
          })
        .on("mouseout", function(d) {
            d3.select(this) 
              .transition()
              .duration(duration)
              .attr("r", circleRadius);  
          });
  
    /* Add Axis into SVG */
    var xAxis = d3.axisBottom(xScale).ticks(5);
    var yAxis = d3.axisLeft(yScale).ticks(5);
    
    svg.append("g")
      .attr("class", "x axis")
      .attr("transform", `translate(0, ${height-margin})`)
      .call(xAxis);
    
    svg.append("g")
      .attr("class", "y axis")
      .call(yAxis)
      .append('text')
      .attr("y", 15)
      .attr("transform", "rotate(-90)")
      .attr("fill", "#000")
      .text("Total values");

};


  document.querySelector('#SUMB').addEventListener('click', lineChart);
  document.querySelector('#SUMC').addEventListener('click', barChart);
























