

/* eslint-disable */



//import constants  https://devdocs.io/dom-cryptography/


 export const red8 = [
  "#ffffcc",
  "#ffeda0",
  "#fed976",
  "#feb24c",
  "#fd8d3c",
  "#fc4e2a",
  "#e31a1c",
  "#b10026"
];


//C201912CAT11AF11

//need to do multiple loops

/* eslint-disable */

document.querySelector('#MERCAT').addEventListener('click', hov);
document.querySelector('#AGE').addEventListener('click', hov);
document.querySelector('#YM').addEventListener('click', hov);
document.querySelector('#SEX').addEventListener('click', hov);
document.querySelector('#SUMA').addEventListener('click', tryChartBar);
document.querySelector('#TOT').addEventListener('click', barCh);
document.querySelector('#EXT').addEventListener('click',  getEx);


document.querySelector('#MT').addEventListener('click',  transMute);


  let viewpop=  'M' //merchant or customer
  let dates =[ '201908','201908' ]
  let mers =[ '01','02','03' ]
  let dob =[ '11','12','13','15','16' ]
  let sex =[ 'A' ]

  let YM_A=[]
  let AGE_A = []
  let MERCAT_A = []
  let SEX_A = []


  let YM= [{ name: '201907'  , code : '201907'  , action: addPill}, 
                { name: '201908'    , code : '201908' , action: addPill }  ,

   
];


let MERCAT = [{ name: 'Apparel' , code : '01'  ,     action: addPill}
  , { name: 'Automotive'  , code : '02'   , action: addPill }  
,  { name: 'Child-Care' , code : '03'   , action: addPill}    
 , { name: 'Day-Out-Entertainment'  , code : '04'  , action: addPill }      
 , { name: 'Education'  , code : '05'  , action: addPill }      
 , { name: 'Entertainment'  , code : '06'  , action: addPill }      
 , { name: 'Food-Liquor'  , code : '07'  , action: addPill }      
 , { name: 'Food-Catering'  , code : '08'  , action: addPill }      
 , { name: 'Gambling'  , code : '09'  , action: addPill }      
 , { name: 'General-Retail'  , code : '10'  , action: addPill }      
 , { name: 'Healthcare'  , code : '11'  , action: addPill }      
 , { name: 'Home-Maintenance'  , code : '12'  , action: addPill }      
 , { name: 'Household-Goods'  , code : '13'  , action: addPill }      
 , { name: 'Insurance'  , code : '14'  , action: addPill }      
 , { name: 'Leisure'  , code : '15'  , action: addPill }      
 , { name: 'Non-food-Major'  , code : '16'  , action: addPill }      
 , { name: 'Property-Rentals'  , code : '17'  , action: addPill }      
 , { name: 'Retail-Services'  , code : '18'  , action: addPill }     
 , { name: 'Supermarkets'  , code : '19'  , action: addPill }     
 , { name: 'Transport'  , code : '20'  , action: addPill }     
 , { name: 'Travel-Accommodation'  , code : '21'  , action: addPill }     


];  

  let AGE = [
     { name: '18-24'  , code : '01'  , action: addPill}
   , { name: '25-34'   , code : '02'  , action: addPill }  
   , { name: '35-44'   , code : '03'  , action: addPill}    
   , { name: '45-54'   , code : '04' , action: addPill }      
   , { name: '55-54'   , code : '05' , action: addPill }      
   , { name: '65-74'   , code : '06' , action: addPill }      
   , { name: '75-84'   , code : '07' , action: addPill }      
   , { name: '85 + '   , code : '08' , action: addPill }      

];



     let SEX = [{ name: 'ALL' , code : 'A'  ,    action: addPill}     
  
   
];

   function addPill(e) {
     const actiontype = e.target.innerHTML; //send the class name to the close button
     // name of the object

     let targObj = eval(e.target.classList[0]);
     let tartype = e.target.classList[0];
     let tartcode = e.target.classList[1];
   

     const node = document.createElement('SPAN');
     const node2 = document.createElement('SPAN');
     const textnode2 = document.createTextNode('x');
     const textnode = document.createTextNode(actiontype);
     node.appendChild(textnode);
     node.appendChild(node2);
     node2.appendChild(textnode2);
     node2.classList.add('close');
     node.classList.add('closea');
     node.classList.add(tartype, tartcode);
     document.getElementById('selmulti').appendChild(node);

     //  add to the array version of the select object
     // select the value of the array
     let arrtype = eval(`${tartype}_A`);
     // arrtype.push(actiontype)
     //console.log('arrtype :', arrtype);

     //take out the selected from the dropdown for next time  document.querySelector("#MERCAT-DROP")
     for (let m = 0; m < targObj.length; m++) {
       if (targObj[m].name === actiontype) {
         console.log('targObj[m].name  ', targObj[m]);
         arrtype.push(targObj[m]);
         targObj.splice(m, 1);
         e.target.parentNode.remove();
      
       }
     }

     node.addEventListener('click', function() {
       let ps = this.classList[2];
       let name = this.firstChild.nodeValue;
       console.log('ps ', this.classList);
       this.remove();
       targObj.splice(0, 0, { name: name, code: ps, action: addPill });
       //need to remove here get index first
       let removeIndex = arrtype
         .map(function(item) {
           return item.name;
         })
         .indexOf(actiontype);
       arrtype.splice(removeIndex, 1);

       console.log('targObj remove ', targObj);
       console.log('arrtype remove ', arrtype);

       let targ = e.target.classList[0];
       let dropob = targObj;
       let filldrop = document.getElementById(`${targ}-DROP`);
       console.log('filldrop ', filldrop);
      // console.log('targ ', targ);

       //remove siblinings first
       while (filldrop.hasChildNodes()) {
         filldrop.removeChild(filldrop.firstChild);
       }
       for (var k = 0; k < dropob.length; k++) {
         filldrop.insertAdjacentHTML(
           'beforeEnd',
           `<li><a class ="${e.target.classList[0]} ${ps}"  href="#" >${dropob[k].name}</a></li>`
         );
         filldrop.addEventListener('click', dropob[k].action);
       }
     });
   }



/*
uk-overflow-auto uk-height-medium uk-dropdown uk-dropdown-top-left" uk-dropdown=
*/

   function hov(e) {
     let targ = e.target.id;
     const drpdwnIn = `<div uk-overflow-auto uk-height-small uk-dropdown > <ul id ="${targ}-DROP" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
     let dropob = eval(targ);
     this.insertAdjacentHTML('afterEnd', drpdwnIn);
     console.log('this', this  )  
     let filldrop = document.getElementById(`${targ}-DROP`);
     for (var k = 0; k < dropob.length; k++) {
       filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ="${e.target.id} ${dropob[k].code}"  href="#" >${dropob[k].name}</a></li>`);
       filldrop.addEventListener('click', dropob[k].action); //the action will be to add the pill and reduce the dropdown list
     }
   }


// this will part of a call to axios  

let buildQuery = function (data) {
  if (typeof (data) === 'string') return data;
  let query = [];
  for (let key in data) {
    if (data.hasOwnProperty(key)) {
      query.push(`${encodeURIComponent(key)  }=${  encodeURIComponent(data[key])}`);
    }
  }
  return query.join('&');
};
//http://localhost:3009/v1/abr?limit=100&skip=50&TRADNF=MAJESTIC%20NURSERIES
//need to make generic   ALLOWED

const getDataCed = async ( ) => {
 
  const response = await axios({
    url: `/v1/polygonced/ced`,
    method: 'get',
    onDownloadProgress: function(progressEvent) {}
  });
   await response.data;
  // console.log(data)
  return response.data;
};



function dtSAStoJS_(dtSAS, dtType = "DATE") {
  if (dtSAS === null) {
    return null;
  } else if (dtType === "DATE") {

return new Date(-315619200000 + (dtSAS-36000) * 86400000);
  } else if (dtType === "DATETIME") {
    return new Date(-315619200000 + (dtSAS-36000) * 1000);
  } else {
    return null;
  }
}


/**************************************** */

function selectPop(viewpop = 'M', dates, mers , sex , dob) {
  
  let final = [];
  const CAT = 'CAT';
  const A = 'A';

  //set defaults
  if (dates.length < 1)    {  dates=  [ '201907','201908' ]} 
  if (mers.length < 1)  {  mers=[ '01','02','03','05','06','07','08','09','10','11','12','13','15','16','17','18','19','20','21' ]} 
  if (dob.length < 1)  { dob =[ '01','02','03','05','06','07','08']} 
  if (sex.length < 1)  {  sex=  [ 'A'] } 

  for (let i = 0; i < dates.length; i++) {
    let dt = `${viewpop}${dates[i]}`;
    for (let j = 0; j < mers.length; j++) {
      let mdt = `${dt}${CAT}${mers[j]}`;
      for (let k = 0; k < sex.length; k++) {
        let sx = `${mdt}${A}${sex[k]}`;
        for (let m = 0; m < dob.length; m++) {
          let db = `${sx}${dob[m]}`;
          final.push(db);
        }
      }
    }
  }
  return final;
}

// takes an array of objects spits out codes
function getSelCodes  ( arrObj )   {
   let scrape =[]
  arrObj.forEach(el => {
    scrape.push(el.code)
  });

  return scrape
}

//picks selected vales and aggreagtes them

function pickReduce (object, [...userSelect ] ) {
  //selected object  
  const kval= userSelect.reduce((o, e) => {return o[e] = object[e], o}, {});
   //get values from selected key value and create array
   const jval= Object.values(kval) 
   const jv= jval.filter( Number );
   let sum = jv.reduce(function (accumulator, currentValue) {
    return accumulator + currentValue;
    
  }, 0);
  
  return sum
}
 

// need this in a loop  

const LeafBR =
  "#mapid > div.leaflet-control-container > div.leaflet-bottom.leaflet-right > div.info.legend.leaflet-control";
const mapboxAccessToken =
"pk.eyJ1IjoibW9nYXMiLCJhIjoiY2ppaWsxeXV3MWtuZzNxcG4zNTVmN3RteSJ9.2OsUOp70d2VPpc-51-fmcg";

const grayscale = L.tileLayer(
"https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=" +
  mapboxAccessToken,
{
  id: "mapbox.light",
  attribution: "Westpac"
}
);

let map = L.map("mapid", {
center: [-33.53434354312, 147.061051828579],
zoom: 6,
layers: [grayscale]
});

let chartData;

async function getEx() {
  let dates = await getSelCodes(YM_A);
  let mers = await getSelCodes(MERCAT_A);
  let sex = await getSelCodes(SEX_A);
  let dob = await getSelCodes(AGE_A);
  console.log( 'MERCAT_A' ,  MERCAT_A  )

  console.log( ' mers ' ,   mers )


  let selected_fields = await selectPop('M', dates, mers, sex, dob);
  let jsonObj = await getDataCed();
  let mapcoll = await jsonObj.features;
    chartData=mapcoll
  let extx = await mapcoll.map(function(prps, x) {
    prps.tran[0].Total = pickReduce(prps.tran[0], selected_fields);
    return pickReduce(prps.tran[0], selected_fields);
  });
  let Colr = d3
    .scaleQuantile()
    .domain(d3.extent(extx))
    .range(red8);

  function highlightFeature(e) {
    let layer = e.target;
    layer.setStyle({
      weight: 3,
      color: '#666',
      dashArray: '',
      fillOpacity: 0.7
    });


     //this updates the main info in mouse hover

  info.update( layer.feature.tran[0]);

    if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
      layer.bringToFront();
    }
  }

  function resetHighlight(e) {
    geoj.resetStyle(e.target);
  }

  function onEachFeature(feature, layer) {
    layer.on({
      mouseover: highlightFeature,
      mouseout: resetHighlight
    });
  }

  let geoj = await L.geoJson(jsonObj, {
    onEachFeature: onEachFeature,
    style: style
  }).addTo(map);

  function style(mapcoll) {

    //so when creating this object we can shape it and create a generic object for the charts with all needed variations
     let [win] =  mapcoll.tran
    //console.log ( win )

    return {
      fillColor: Colr(mapcoll.tran[0].Total),
      weight: 2,
      opacity: 1,
      color: 'white',
      dashArray: '3',
      fillOpacity: 0.7
    };

  }

  let sclock
  let createchartf=1
  let svg

  //for the bottom right legend
  let legend = L.control({
    position: "bottomright"
  });

  legend.onAdd = function(map) {
    let div = L.DomUtil.create("div", "info legend");
    return div;
  };
  legend.addTo(map);

 //for the top right hover panel
  let info = L.control({
    position: "topright"
  });

  info.onAdd = function(map) {
   let div = L.DomUtil.create("div", "info"); // create a div with a class "info"
    div.innerHTML= `<h7>MEASURE: </h7>`
    return div;
  }

  info.addTo(map);

  info.update = function(prp) {
  // mainSel is the main selection
  let fmt=d3.format( "$.3s") 
  let prpf=fmt(prp.Total)
  let locname =prp.LOCNAME
  this._container.innerHTML = `
  <b>ELECTORATE: ${locname}  </b> <br>
  <h7>MEASURE: ${prpf} </h7>`
 // console.log ('prp ', prp )
    
};

  if (createchartf == 1) {
    const canvas = d3.select(LeafBR).attr("height", 150);
    canvas.select("svg").remove();
    svg = canvas
      .append("svg")
      .attr("width", 85)
      .attr("height", 105);
    svg
      .append("g")
      .attr("class", "legendQuant")
      .attr("transform", "scale(0.60)");
     legend = d3
      .legendColor()
      .labelFormat(d3.format( "$.3s"))
      .useClass(false)
      .shapeWidth(20)
      .shapeHeight(20)
      .scale(Colr);
    svg.select(".legendQuant").call(legend);
  }


}


  
//control tracking
 
//test chart function

let te =[

  {key: "1", value: 399545.13},
  {key: "2", value: 616498.06},
  {key: "3", value: 589454.03},
  {key: "4", value: 474550.48},
  {key: "5", value: 197552.3},
  {key: "6", value: 74503.43},
  {key: "7", value: 154504.3},
  {key: "8", value: 119548.83}

]

let te2 =[
  {key: "1", value: {  proc:  399545.13 ,poo: 119548.83 , wee: 'some teext '}},
  {key: "2", value: {proc:  616498.06   ,poo:  74503.43 , wee: 'some html' }},
  {key: "3", value:{ proc:  589454.03   ,poo: 474550.48  , wee: 'some wee '  }}
]

//need function to shape data for chart
// in:any data , array etc,
//out key value pait for the chart
// needs 3 components key, value , tooltip value
// coud do something like this : value[x][y]  etc

const handlem = (d, i, n) => {

  d3.select(n[i])
    .transition()
    .duration(10)
    .attr("fill", "#737373")
   

};
const handlemout = (d, i, n) => {
  d3.select(n[i])
    .transition()
    .duration(10)
    .attr("fill", "#d9d9d9");
};

async function tryChartBar () {
  function execute(code) {
    // this is the recommended way of executing code with Function
    return Function('"use strict";return ' + code)();
  }
  
//let   [win ] = chartData[0].tran    , code:  prps.properties[0].CED_NAME16 
 // console.log('bar it', win)
 let arr=[]
 let cat ='<br>'
 let ppp= 'prps.properties.CED_NAME16' 
 await chartData.map(function(prps, x) {
  let obj=    {  key: x ,    value:  { tot:  prps.tran[0].Total , 'code':   eval(ppp)  +cat }    }
  arr.push( obj  )

 
});
arr=arr.slice(1, 10);
//await console.log('bar it', arr)
await console.log('chart data', arr)
;
  //create varios shapes that can go into the chart data
  // console.log( d3.entries(win)  )     
  let fmt=d3.format( "$.3s") 

  var fillclr;
  let cc = arr;
  // add width for no of groups
  let gwidth = 4 * (5 - 1);
  var margin = {
    top: 20,
    right: 10,
    bottom: 20,
    left: 40
  };
  var width = 150 + gwidth - margin.left - margin.right,
    height = 110 - margin.top - margin.bottom;

  var svg = d3
    .select("#chartid")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

  let x = d3
    .scaleBand()
    .paddingInner(0.1)
    .paddingOuter(0.1);
  let y = d3.scaleLinear().range([height, 0]);

  y.domain([0, d3.max(cc.map(a => a.value['tot']))]);
  x.domain(cc.map(a => a.key)).range([0, width]);
  const rects = svg.selectAll("rect").data(cc);
   
  console.log( 'rects'  , rects)
   
  rects.exit().remove();
  rects
    .attr("width", x.bandwidth)
    .attr("height", d => height - y(d.value['tot']))
    .attr("fill", function(d) {
      return d.key == fillclr ? "#969696" : "#d9d9d9";
    })
    .attr("x", d => x(d.key))
    .attr("y", d => y( d.value['tot']    ))
  
  rects
    .enter()
    .append("rect")
    .attr("width", x.bandwidth)
    .attr("height", d => height - y(d.value['tot']  ))
    .attr("fill", function(d) {
      return d.key == fillclr ? "#969696" : "#d9d9d9";
    })
    .attr("x", d => x(d.key))
    .attr("y", d => y(d.value['tot']  ))
    .attr(`uk-tooltip`,  (d =>   d.value['code'] +    fmt(d.value['tot'])  ) )  
    .on("mouseover", handlem )
    .on("mouseout", handlemout);
   
  const xAxisGroup = svg
    .append("g")
    .attr("transform", `translate(0, ${height} )`);
  const yAxisGroup = svg.append("g");
  const xAxis = d3.axisBottom(x).tickSize(2);
  const yAxis = d3
    .axisLeft(y)
    .ticks(1)
    .tickSize(2)
    .tickFormat(fmt);

  xAxisGroup.call(xAxis);
  yAxisGroup.call(yAxis);

}

async function barCh () { 
     
  var data = [
    {date: "201901", value: "100"},
    {date: "201902", value: "110"},
    {date: "201903", value: "45"},
    {date: "201904", value: "241"},
    {date: "201905", value: "101"},
    {date: "201906", value: "90"},
    {date: "201907", value: "10"},
    {date: "201908", value: "35"},
    {date: "201909", value: "21"},
    {date: "201910", value: "201"},
  ];
  
  
  
  
  
  var width = 300;
  var height = 150;
  var margin = 30;
  

  /* Format Data */
  
  // data.forEach(function(d) { 
    
  //   d.date = new Date (d.date);
  //   console.log( 'dfy', d  ,  d.date.getFullYear())
   
  //   d.value = +d.value;
  // });
 

  data.map  ( 
    function(d, i) { 

  
     console.log(i)
     d.date=  new Date(  +  d.date.substr(0, 4) + '-' + d.date.substr(4, 6) +'-01' )
   
      d.value = +d.value;

  console.log(d.date)

    }
    )


   let  bisectDate = d3.bisector(function(d) { return d.date; }).left

  /* Scale   */  
  var xScale = d3.scaleTime()
    .domain(d3.extent(data, d => d.date))
    .range([0, width-margin]);
  
  var yScale = d3.scaleLinear()
    .domain([0, d3.max(data, d => d.value)])
    .range([height-margin, 0]);
  

  /* Add SVG */
  var svg = d3.select("#chartid").append("svg")
    .attr("width", (width+margin)+"px")
    .attr("height", (height+margin)+"px")
    .append('g')
    .attr("transform", `translate(${margin}, ${margin})`);
  
    var xAxis = d3.axisBottom(xScale).ticks(5).tickFormat( d3.timeFormat("%Y%m")  );

    var yAxis = d3.axisLeft(yScale).ticks(5);
   
    svg.append("g")
        .attr("class", "x axis")
       .attr("transform", `translate(0, ${height-margin})`)
        .call(xAxis);
     
      svg.append("g")
        .attr("class", "y axis")
        .call(yAxis)
        .append('text')
        .attr("y", 15)
        .attr("transform", "rotate(-90)")
        .attr("fill", "#000")
     

  /* Add line into SVG */
  var line = d3.line()
    .x(d => xScale(d.date))
    .y(d => yScale(d.value));
  
  svg.append('path')
    .attr('class', 'line')
    .attr('d', line(data));
     
  
        var focus = svg.append("g")
            .attr("class", "focus")
            .style("display", "none");

        focus.append("circle")
            .attr("r", 5)
       
            //add other html

  //       focus.append("rect")
  //           .attr("class", "tooltip")
  //           .attr("width", 50)
  //           .attr("height", 40)
  //           .attr("x", 10)
  //           .attr("y", -15)
  //           .attr("rx", 2)
  //           .attr("ry", 2)
  //           .style("fill" ,"#666"   )
           

  //       focus.append("text")
  //           .attr("class", "tooltip-date")
  //           .attr("x", 18)
  //           .attr("y", 5);

  //       focus.append("text")
  //           .attr("x", 18)
  //           .attr("y", 18)
            

  //       focus.append("text")
  //           .attr("class", "tooltip-likes")
  //           .attr("x", 18)
  //           .attr("y", 18);

        svg.append("rect")
            .attr("class", "overlay")
            .attr("width", width)
            .attr("height", height)
        //   .on("mouseover", function() { focus.style("display", null); })
        //    .on("mouseout", function() { focus.style("display", "none"); })
            .on("mousemove", mousemove);
  
    function mousemove() {
       let x0 = xScale.invert(d3.mouse(this)[0])
       let fmt =d3.timeFormat("%Y%m")
       let i = bisectDate(data, x0, 1)   
     //  console.log( i  ,  x0  )   
      // let  bisectDate = d3.bisector(function(d) { return d.date; }).left
      // let  d0 = data[i - 1]
     //  let d1=0;
        // d1 = data[i]
  
         let el =  document.querySelector(`#chartid > svg > g > g:nth-child(6) > g:nth-child(${i})`)
         UIkit.tooltip(el).show();
    //   if (d1 !== undefined) {
      //  let d = x0 - d0.date > d1.date - x0 ? d1 : d0;
         ///  focus.attr("transform", "translate(" + xScale(d.date) + "," + yScale(d.value) + ")");
         //  focus.select(".tooltip-date").text(  fmt( d.date )  );
         //  focus.select(".tooltip-likes").text(d.value);
       //need to trigger tooltip
      
     //    let el =  document.querySelector(`#chartid > svg > g > g:nth-child(6) > g:nth-child(${i})`)
       //  console.log( el )
     //    UIkit.tooltip(el).show();
     //  }
 
 }
  let fmt=d3.format( "$.3s") 
  // /* Add circles in the line + tooltips */ 
  svg.append("g")
    .selectAll("circle")
    .data(data).enter()
    .append("g")
    .attr("class", "circle")
  
    .attr(`uk-tooltip`,    d => (d.value)    )  
    .on("mouseover", function(d) {
        d3.select(this)     
          .style("cursor", "pointer")
          .style("fill", "#666")
          .append("text")
          .attr("class", "text")
       
        //  .text(d.value)
        //  .attr("x", d => xScale(d.date) + 5)
        //  .attr("y", d => yScale(d.value) - 5);
      })
    .on("mouseout", function(d) {
        d3.select(this)
        //  .style("cursor", "none")  
         // .style("fill", "none")
         // .select("text").remove();
      })
  
    .append("circle")
    .attr("cx", d => xScale(d.date))
    .attr("cy", d => yScale(d.value))
    .attr("r", 4);
  
  
  // /* Add Axis into SVG */

};


function transMute () {



 // const targetNode = document.querySelector("#MERCAT-DROP")
 const targetNode =document.querySelector("#chartid > svg > g > g.focus > text.tooltip-date")

  // Options for the observer (which mutations to observe)
 // const config = { attributes: true, childList: true, subtree: true };
  const config = {
  attributes: true,
  characterData: true,
  childList: true,
  subtree: true,
  attributeOldValue: true,
  characterDataOldValue: true };
  
  // Callback function to execute when mutations are observed    ["0"].target.attributes
  const callback = function(mutationsList, observer) {
    console.log( mutationsList )
      for(let mutation of mutationsList) {
          if (mutation.type === 'characterData') {
              console.log('characterData chng');
          }
          else if (mutation.type === 'attributes') {
              console.log('The ' + mutation.attributeName + ' attribute was modified.');
              console.log('mut ob = ' + mutation)
          }
      }
  };
  
  // Create an observer instance linked to the callback function
  const observer = new MutationObserver(callback);
  
  // Start observing the target node for configured mutations
  observer.observe(targetNode, config);
  
  // Later, you can stop observing
//observer.disconnect();

}

document.querySelector('#HC').addEventListener('click',  HC);

// let myChart
// function HC () {
//  myChart  = Highcharts.chart('container', {
//   title: {
//          text: 'My chart'
//   },

//   plotOptions: {
//     series: {
//         cursor: 'pointer',
//         point: {
//             events: {
//                 click: function (e) {
//                     console.log('Category: ' + e.target  + this);
//                 }
//             }
//         }
//     }
// }


// //can be an object 

//   }
  



// console.log(myChart.userOptions,  myChart.series["0"].data   )

// })



//need to create a function that shapes the data 


async function HC () {

let arr=[]

//function to shape the chart type
 await chartData.map(function(prps, x) {
  let obj=    {  name: x+1 ,    y:   prps.tran[0].Total    }
  arr.push( obj  )
 })
    
  await Highcharts.chart('container', {
  chart: {
      type: 'line'  
      , styledMode: true
  }
,

legend: {
  enabled: false
},
 
  title : {
    text: 'Monthly Stuff'   
 },  

 tooltip: {
  pointFormat: "Value: {point.y:.2f}"
},

  series: [{
    name :'mogas',
      data: arr
  }]
})

console.log(arr)
}



var v = [ [ 'M201907','M201908' ],[ 'A01','A02'] ,[ 'XX01','XX02']     ]     ;
var combos = createCombinations(v);
let xc =[]
for(var i = 0; i < combos.length; i++) {
 xc.push( combos[i] )
 console.log('combos'  , xc)

}


//function for the defaults;

function comboRun ()  {


     let v = [ [ 'M201907','M201908' ],[ 'A01','A02'] ,[ 'XX01','XX02']     ]     ;
     let combos = createCombinations(v);
     let xc =[]
  for(var i = 0; i < combos.length; i++) {
   xc.push( combos[i] )
   console.log('combos'  , xc)

        }
    }





function createCombinations(fields, currentCombinations) {
  //prevent side-effects
  var tempFields = fields.slice();

  //recursively build a list combinations
  
  if (!tempFields || tempFields.length == 0) {
    return currentCombinations;
  }
  else {
    var combinations = [];
    var field = tempFields.pop();

    for (var valueIndex = 0; valueIndex < field.length; valueIndex++) {
      var valueName = field[valueIndex];

      if (!currentCombinations || currentCombinations.length == 0) {
        var combinationName = valueName;
        combinations.push(combinationName);
      }
      else {
        for (var combinationIndex = 0; combinationIndex < currentCombinations.length; combinationIndex++) {
          var currentCombination = currentCombinations[combinationIndex];
          var combinationName = valueName +  currentCombination;
          combinations.push(combinationName);
        }
      }
    }
    return createCombinations(tempFields, combinations);
  }
}


