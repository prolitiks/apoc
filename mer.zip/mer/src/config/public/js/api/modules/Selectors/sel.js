/* eslint-disable */


//export let wee ='xxxxxxx'F

let CMTYPE_A=[ ]

let CMRESTIME_A  =   []

let CMRELYEARS_A  =   []

let CMTYPE = [
   { name: 'Access' , code : '01'  ,     action: addPill}
  ,{ name: 'Advisor-Issues'  , code : '02'   , action: addPill }  
,  { name: 'Business-Decision' , code : '03'   , action: addPill}    
 , { name: 'Comms-Information-Advice'  , code : '04'  , action: addPill }    
 , { name: 'Credit-Decision'  , code : '05'  , action: addPill }    
 , { name: 'Introducer'  , code : '06'  , action: addPill }     
 , { name: 'Investment-Issues'  , code : '07'  , action: addPill }     
 , { name: 'Letter-of-Notification'  , code : '08'  , action: addPill }     
 , { name: 'Other-Bank-ATM'  , code : '09'  , action: addPill }    
 , { name: 'Process'  , code : '10'  , action: addPill }    
 , { name: 'Product-Features'  , code : '11'  , action: addPill }    
 , { name: 'Rates-Fees-Charges'  , code : '12'  , action: addPill } 
 , { name: 'Security'  , code : '13'  , action: addPill } 
 , { name: 'Service-Failure'  , code : '14'  , action: addPill } 
 , { name: 'Service-Quality'  , code : '15'  , action: addPill } 
 , { name: 'St-George-Bank-SA-ATM	'  , code : '16'  , action: addPill } 
 , { name: 'Westpac-ATM	'  , code : '17'  , action: addPill } 
]


let CMRESTIME  =   [
  { name: 'Immediately' , code : '0'  ,     action: addPill}
 ,{ name: 'Within-7-days'  , code : '1'   , action: addPill }  
 ,{ name: 'More-than-7-days'  , code : '2'   , action: addPill }  
 ,{ name: 'Unknown'  , code : '3'   , action: addPill }  
]


let CMRELYEARS  =   [
  { name: 'Less-than-1-year' , code : '1'  ,     action: addPill}
 ,{ name: '1-3-years'  , code : '2'   , action: addPill }  
 ,{ name: '3-5-years'  , code : '3'   , action: addPill }  
 ,{ name: '5-10-years'  , code : '4'   , action: addPill }  
 ,{ name: '10-20-years'  , code : '5'   , action: addPill }  
 ,{ name: 'More-than-20-years'  , code : '6'   , action: addPill }  
,{ name: 'Unknown'  , code : '7'   , action: addPill }  
]

let SEEDROOT  =   [
  { name: 'COMPLAINT-TYPE' , code : '1'  ,   drpdwn : 'CMTYPE' }
 ,{ name: 'RESOLVE-TIME'  , code : '2'   ,  drpdwn : 'CMRESTIME' }  
 ,{ name: 'CUSTOMER-TENURE'  , code : '3' , drpdwn : 'CMRELYEARS' }  
]

// let SEEDROOT_A  =   []

//need to create and insert buttons  
//document.querySelector('#CMTYPE').addEventListener('mouseover', hov);

const returnedTarget = Object.assign(window['SEEDROOT']);

console.log(returnedTarget)

class Rectangle {
  constructor(seedr) {
    this.seedroot = seedr;
  //  console.log(this.seedroot)
    this.createSeeds = this.createSeeds.bind(this);
  }  

  createSeeds () {
    console.log(this.seedroot)
    function parse(str) {
      return Function(`'use strict'; return (${str})`)()
    }
    parse('4.12345 * 3.2344 - 9') // 4.336886679999999
  }
}


class CreateSeed {
  constructor(seedr , ...CY) {
    
    // for (let c= 0; c < CY.length; c++) {  need to add a sel mul
    //   this.CY   =CY[c]
    //   }

    
    this.CY=CY
    this.seedroot = seedr;
    this.createSeeds = this.createSeeds.bind(this);
  }

  createSeeds() {
    //under start button
    let startn = document.querySelector('#seed');
    console.log(startn);
    let seedm = this.seedroot;
    for (var k = 0; k < seedm.length; k++) {
  // this cretes the buttons in the begining
      startn.insertAdjacentHTML(
        'afterEnd',
        `<button   uk-icon="icon: chevron-down ; ratio: 0.6" id='${seedm[k].drpdwn}' 
          class="${seedm[k].drpdwn} ${seedm[k].code} 
           uk-button uk-button-default uk-button-small" >${seedm[k].name} 
           </button>           
        <span class = "flex-container"  id ="${seedm[k].drpdwn}-B"> </span>
        `
      );


      //  document.querySelector(`#${seedm[k].drpdwn}`).addEventListener('mouseover', hov);

      let dropob = eval(seedm[k].drpdwn);
      let cname = String(seedm[k].drpdwn);

       //let poo = this.CY[0]21 q

       let poo = this.CY
      console.log('this.CY[0]  '  ,poo[0])

      const drpdwnIn = `<div  uk-dropdown > <ul id ="${seedm[k].drpdwn}-DROP" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
     
      document.querySelector(`#${seedm[k].drpdwn}`).insertAdjacentHTML('afterEnd', drpdwnIn);
       
      let filldrop = document.getElementById(`${seedm[k].drpdwn}-DROP`);

      for (var j = 0; j < dropob.length; j++) {
        filldrop.insertAdjacentHTML(
          'beforeEnd',
          `<li><a class ="${cname} ${dropob[j].code}"  href="#" >${dropob[j].name}</a></li>`
        );
        filldrop.addEventListener('click', dropob[j].action); //the action will be to add the pill and reduce the dropdown list
      }
    }
    //need to add a save button

    //////////////////////////////////////
    const node = document.createElement('BUTTON');
    const textn = document.createTextNode('SAVE SELECTION');
    node.appendChild(textn);
    node.setAttribute('class', 'uk-button uk-button-default uk-button-small');
    let node2 = node.cloneNode(true);
    const nd = document.getElementById('seedxx');
    nd.appendChild(node);

    const inpt = document.createElement('input');
    inpt.setAttribute('class', 'uk-input uk-form-width-small uk-form-small');
    inpt.setAttribute('placeholder', 'User');
    nd.appendChild(inpt);
    //save button trggers event handler
    //chart name
    //group name
    // need a back button
    //tooltip info
    // input     <input id ='userin' class="uk-input uk-form-width-small uk-form-small" type="text" placeholder="User">
  }
}
const seed = new CreateSeed(SEEDROOT , CMRELYEARS ,CMRESTIME  ,CMTYPE  );
document.querySelector('#SEEDROOT').addEventListener('click', seed.createSeeds);

function  saveSel ()   {
//potentially save the selection 


}

//add events to the pills
// this event function can wrap around the addpilly generic function

function addPill(e) {
  const actiontype = e.target.innerHTML; //send the class name to the close button
  let targObj = eval(e.target.classList[0]);
  //let cname = String(e.target.classList[0]);
  let tartype = e.target.classList[0];
  let tartcode = e.target.classList[1];
  const node = document.createElement('SPAN');
  const node2 = document.createElement('SPAN');

  const textnode2 = document.createTextNode('x');

  const textnode = document.createTextNode(actiontype);
  node.appendChild(textnode);
  node.appendChild(node2);
  node2.appendChild(textnode2);
  node2.classList.add('close');
  node.classList.add('closea');
  node.classList.add(tartype, tartcode);

  //element.parentNode.insertBefore(newElement, element.nextSibling);  document.querySelector("#CMRELYEARS-DROP > li:nth-child(1) > a")

  let boxel =  document.getElementById(`${tartype}-B`)
  

  boxel.appendChild(node);

  console.log('boxel ',  boxel)

 //boxel.parentNode.insertBefore(node, node.nextSibling); 


  let arrtype = eval(`${tartype}_A`);
 
  console.log('tartype '  ,   tartype)
  console.log('targObj'  ,   targObj)
  console.log('tartcode '  ,   tartcode)
  console.log('actiontype '  ,   actiontype)
  console.log('arrtype '  ,   arrtype)
  
  //need to add a document fragment to the woking list  get parent element  
  // from the parenet node  
  const pn = e.target.parentNode.firstChild.classList[0];
  console.log('pn ' , pn)

  

  //take out the selected from the dropdown for next time  document.querySelector("#MERCAT-DROP")
  for (let m = 0; m < targObj.length; m++) {
    if (targObj[m].name === actiontype) {
      console.log('targObj[m].name  ', targObj[m]);
      arrtype.push(targObj[m]);
      targObj.splice(m, 1);
      const par= e.target.parentNode
      const gran = par.parentNode
     // e.target.parentNode.remove();
      
      console.log('par  ' ,  par);

      // if (  targObj.length ==0   )  
      // {
        
      //   gran.parentNode.remove();
      // }
      
      par.remove();

    }
  }

  node.addEventListener('click', function() {
    let ps = this.classList[2];
    let name = this.firstChild.nodeValue;
    console.log('ps ', this.classList);
    this.remove();
    targObj.splice(0, 0, { name: name, code: ps, action: addPill });
    //need to remove here get index first
    let removeIndex = arrtype
      .map(function(item) {
        return item.name;
      })
      .indexOf(actiontype);
    arrtype.splice(removeIndex, 1);

    console.log('targObj remove ', targObj);
    console.log('arrtype remove ', arrtype);

    let targ = e.target.classList[0];
    let dropob = targObj;
    let filldrop = document.getElementById(`${targ}-DROP`);


    //remove siblinings first
    while (filldrop.hasChildNodes()) {
      filldrop.removeChild(filldrop.firstChild);
    }
    for (var k = 0; k < dropob.length; k++) {
      filldrop.insertAdjacentHTML(
        'beforeEnd',
        `<li><a class ="${e.target.classList[0]} ${ps}"  href="#" >${dropob[k].name}</a></li>`
      );
      filldrop.addEventListener('click', dropob[k].action);
    }
  });
}


const getDataComp = async (frmdate,tdate ) => {
 
  const response = await axios({
    url: `/v1/complaint?limit=50&sort=CYM&YM>=${frmdate}&YM<=${tdate}`,
    method: 'get',
    onDownloadProgress: function(progressEvent) {}
  });
   await response.data;
   console.log('axios data '  , response.data)
  return response.data;
};

//document.querySelector('#DT').addEventListener('click',  getDataComp);
document.querySelector('#DTB').addEventListener('click',  getEx);

  //inserts dropdown after the selected button or element

function dtSAStoJS_(dtSAS, dtType = "DATE") {
 if (dtSAS === null) {
   return null;
 } else if (dtType === "DATE") {

return new Date(-315619200000 + (dtSAS-36000) * 86400000);
 } else if (dtType === "DATETIME") {
   return new Date(-315619200000 + (dtSAS-36000) * 1000);
 } else {
   return null;
 }
}



//login functionality

const  logsub = async (e ) => {
  //delete existing cookies 
 // console.log('logsub works.....'  , e  )   document.querySelector("#l1")
  
  //delete existing cookies 
  //remove exsiting html
 const warntext= document.querySelector(`#l1`)
 if ( warntext !== null )
 {
   warntext.remove()
 }

 

  Cookies.remove('tokendata')
  let transport = axios.create({
    withCredentials: true  
  })


  await transport.interceptors.response.use(
    function(response) {
      console.log('intercepted.....')
      return response
    },
    function(error) {
      const errorResponse = error.response
    console.log('err.....'  ,errorResponse.status )
    console.log('errmessage.....'  ,errorResponse.data.message )
    console.log('errobj.....'  ,errorResponse )
    let  badpass =errorResponse.data.message
  
  //put message in the login screen here
  document.querySelector(`#passin`).insertAdjacentHTML('afterEnd', `<div id='l1' class ='badattemp'>${badpass}</div>` );
      return Promise.reject(error)

    }
  )

  //get imput fields from login  

  let userin= document.getElementById("userin").value
  let passin= document.getElementById("passin").value
  console.log('userin... '  , userin  )
  console.log('passin... '  , passin)
  const lgin = {  email: userin ,  //create a form for the user and password
  password: passin }
  console.log('lgin  ... '  , lgin  )

 const da = {  email:'dave@prolitiks.com' ,   password: 'thewinner'}
 
try {

  const response = await transport({
    url: `v1/auth/login`,
    method: 'post',
    data : da  ,
    onDownloadProgress: function(progressEvent) {}

  });
   await response.data;
   console.log('axios data '  , response.data)
   await  Cookies.set('tokendata', response.data);

   //change the dom here if sucess
   window.location.replace("/v1/users/5d49340e1af22213a415f0e7");
    //remove dropdown
    document.querySelector(`#DROPLOG`).remove()
     //change lognin button to signout + actually signout
     document.querySelector(`#LG`).textContent ='SIGNOFF'
    //function to signoff and reset login
}
catch(e) {
  console.log(e.message)
}
}

document.querySelector('#LOGSUB').addEventListener('click',  logsub);

  /* Format Data */
  
  // data.forEach(function(d) { 
    
  //   d.date = new Date (d.date);
  //   console.log( 'dfy', d  ,  d.date.getFullYear())
   
  //   d.value = +d.value;
  // });
 

  // data.map  ( 
  //   function(d, i) { 

  
  //    console.log(i)
  //    d.date=  new Date(  +  d.date.substr(0, 4) + '-' + d.date.substr(4, 6) +'-01' )
   
  //     d.value = +d.value;

  // console.log(d.date)

  //   }
  //   )


// // takes an array of objects spits out codes e.g. let wee=getSelCodesObj (CMTYPE , 'code')
export function getSelCodesObj  ( arrObj   , keycode )   {
   let scrape =[]
        arrObj.forEach(el => {
        scrape.push(el[keycode])
 });

 return scrape
}

// takes an array of objects spits out codes
function getSelCodes  ( arrObj )   {
  let scrape =[]
 arrObj.forEach(el => {
   scrape.push(el.code)
 });

 return scrape
}


//picks selected vales and aggreagtes them

export function pickReduce (object, [...userSelect ] ) {
 //selected object  
 const kval= userSelect.reduce((o, e) => {return o[e] = object[e], o}, {});
  //get values from selected key value and create array
  const jval= Object.values(kval) 
  const jv= jval.filter( Number );
  let sum = jv.reduce(function (accumulator, currentValue) {
   return accumulator + currentValue;
   
 }, 0);
 
 return sum
}

 export function selectPopD( CMTYPE,  CMRESTIME , CMRELYEARS) {
 
  let final = [];
  const T ='T'
  const CR ='CR'
  const RL ='RL'

  //set defaults
  if (CMTYPE.length < 1)    {  CMTYPE=  [ '01','02','03','04','05','06','07','08','09','10','11','12','13','15','16','17' ] } 
  if (CMRESTIME.length < 1)  {  CMRESTIME=  [ '0','1','2','3' ]} 
  if (CMRELYEARS.length < 1)  { CMRELYEARS =[ '1','2','3','4','5','6','7']} 

  for (let i = 0; i < CMTYPE.length; i++) {
    let c1 = `${T}${CMTYPE[i]}`;
      for (let k = 0; k < CMRESTIME.length; k++) {
        let c2 = `${c1}${CR}${CMRESTIME[k]}`;
        for (let m = 0; m < CMRELYEARS.length; m++) {
          let c3 = `${c2}${RL}${CMRELYEARS[m]}`;
          final.push(c3);
        }
      }
  }
  return final;
 }

//  console.log(  ALLOWED  )
//  console.log( 'getsel ', getSelCodes(CMTYPE_A) )  http://www.objectplayground.com/



let dt_arr = [
  { YMC: 1, YM: '201601' },
  { YMC: 2, YM: '201602' },
  { YMC: 3, YM: '201603' },
  { YMC: 4, YM: '201604' },
  { YMC: 5, YM: '201605' },
  { YMC: 6, YM: '201606' },
  { YMC: 7, YM: '201607' },
  { YMC: 8, YM: '201608' },
  { YMC: 9, YM: '201609' },
  { YMC: 10, YM: '201610' }, //start
  { YMC: 11, YM: '201611' },
  { YMC: 12, YM: '201612' },
  { YMC: 13, YM: '201701' },
  { YMC: 14, YM: '201702' },
  { YMC: 15, YM: '201703' },
  { YMC: 16, YM: '201704' },
  { YMC: 17, YM: '201705' },
  { YMC: 18, YM: '201706' },
  { YMC: 19, YM: '201707' },
  { YMC: 20, YM: '201708' },
  { YMC: 21, YM: '201709' },
  { YMC: 22, YM: '201710' },
  { YMC: 23, YM: '201711' },
  { YMC: 24, YM: '201712' },
  { YMC: 25, YM: '201801' },
  { YMC: 26, YM: '201802' },
  { YMC: 27, YM: '201803' },
  { YMC: 28, YM: '201804' },
  { YMC: 29, YM: '201805' },
  { YMC: 30, YM: '201806' },
  { YMC: 31, YM: '201807' },
  { YMC: 32, YM: '201808' },
  { YMC: 33, YM: '201809' },
  { YMC: 34, YM: '201810' },
  { YMC: 35, YM: '201811' },
  { YMC: 36, YM: '201812' },
  { YMC: 37, YM: '201901' },
  { YMC: 38, YM: '201902' },
  { YMC: 39, YM: '201903' },
  { YMC: 40, YM: '201904' },
  { YMC: 41, YM: '201905' },
  { YMC: 42, YM: '201906' },
  { YMC: 43, YM: '201907' },
  { YMC: 44, YM: '201908' },
  { YMC: 45, YM: '201909' },
  { YMC: 46, YM: '201910' }, //end
  { YMC: 47, YM: '201911' },
  { YMC: 48, YM: '201912' },
  { YMC: 49, YM: '202001' },
  { YMC: 50, YM: '202002' },
  { YMC: 51, YM: '202003' },
  { YMC: 52, YM: '202004' },
  { YMC: 53, YM: '202005' },
  { YMC: 54, YM: '202006' },
  { YMC: 55, YM: '202007' },
  { YMC: 56, YM: '202008' },
  { YMC: 57, YM: '202009' },
  { YMC: 58, YM: '202010' },
  { YMC: 59, YM: '202011' },
  { YMC: 60, YM: '202012' }
];

  
let ConfigObj = {
  SELDATA: { RAR_DATA: [] },

  CHFIG: {},

  DTR: {
    DTARR: [
      { YMC: 1, YM: "201601" },
      { YMC: 2, YM: "201602" },
      { YMC: 3, YM: "201603" },
      { YMC: 4, YM: "201604" },
      { YMC: 5, YM: "201605" },
      { YMC: 6, YM: "201606" },
      { YMC: 7, YM: "201607" },
      { YMC: 8, YM: "201608" },
      { YMC: 9, YM: "201609" },
      { YMC: 10, YM: "201610" },
      { YMC: 11, YM: "201611" },
      { YMC: 12, YM: "201612" },
      { YMC: 13, YM: "201701" },
      { YMC: 14, YM: "201702" },
      { YMC: 15, YM: "201703" },
      { YMC: 16, YM: "201704" },
      { YMC: 17, YM: "201705" },
      { YMC: 18, YM: "201706" },
      { YMC: 19, YM: "201707" },
      { YMC: 20, YM: "201708" },
      { YMC: 21, YM: "201709" },
      { YMC: 22, YM: "201710" },
      { YMC: 23, YM: "201711" },
      { YMC: 24, YM: "201712" },
      { YMC: 25, YM: "201801" },
      { YMC: 26, YM: "201802" },
      { YMC: 27, YM: "201803" },
      { YMC: 28, YM: "201804" },
      { YMC: 29, YM: "201805" },
      { YMC: 30, YM: "201806" },
      { YMC: 31, YM: "201807" },
      { YMC: 32, YM: "201808" },
      { YMC: 33, YM: "201809" },
      { YMC: 34, YM: "201810" },
      { YMC: 35, YM: "201811" },
      { YMC: 36, YM: "201812" },
      { YMC: 37, YM: "201901" },
      { YMC: 38, YM: "201902" },
      { YMC: 39, YM: "201903" },
      { YMC: 40, YM: "201904" },
      { YMC: 41, YM: "201905" },
      { YMC: 42, YM: "201906" },
      { YMC: 43, YM: "201907" },
      { YMC: 44, YM: "201908" },
      { YMC: 45, YM: "201909" },
      { YMC: 46, YM: "201910" },
      { YMC: 47, YM: "201911" },
      { YMC: 48, YM: "201912" },
      { YMC: 49, YM: "202001" },
      { YMC: 50, YM: "202002" },
      { YMC: 51, YM: "202003" },
      { YMC: 52, YM: "202004" },
      { YMC: 53, YM: "202005" },
      { YMC: 54, YM: "202006" },
      { YMC: 55, YM: "202007" },
      { YMC: 56, YM: "202008" },
      { YMC: 57, YM: "202009" },
      { YMC: 58, YM: "202010" },
      { YMC: 59, YM: "202011" },
      { YMC: 60, YM: "202012" }
    ]
  },

  DRPOB: {
    SEEDR: [
      {
        name: "COMPLAINT-TYPE",
        code: "2",
        ctype: "CMTYPE",
        drpdwnSelected: [],
        drpdwn: [
          { name: "Access", code: "01" },
          { name: "Advisor-Issues", code: "02" },
          { name: "Business-Decision", code: "03" },
          { name: "Comms-Information-Advice", code: "04" },
          { name: "Credit-Decision", code: "05" },
          { name: "Introducer", code: "06" },
          { name: "Investment-Issues", code: "07" },
          { name: "Letter-of-Notification", code: "08" },
          { name: "Other-Bank-ATM", code: "09" },
          { name: "Process", code: "10" },
          { name: "Product-Features", code: "11" },
          { name: "Rates-Fees-Charges", code: "12" },
          { name: "Security", code: "13" },
          { name: "Service-Failure", code: "14" },
          { name: "Service-Quality", code: "15" },
          { name: "St-George-Bank-SA-ATM", code: "16" },
          { name: "Westpac-ATM	", code: "17" }
        ]
      },

      {
        name: "RESOLVE-TIME",
        code: "1",
        ctype: "CMRESTIME",
        drpdwnSelected: [],
        drpdwn: [
          { name: "Immediately", code: "0" },
          { name: "Within-7-days", code: "1" },
          { name: "More-than-7-days", code: "2" },
          { name: "Unknown", code: "3" }
        ]
      },

      {
        name: "CUSTOMER-TENURE",
        code: "3",
        ctype: "CMRELYEARS",
        drpdwnSelected: [],
        drpdwn: [
          { name: "Less-than-1-year", code: "1" },
          { name: "1-3-years", code: "2" },
          { name: "3-5-years", code: "3" },
          { name: "5-10-years", code: "4" },
          { name: "10-20-years", code: "5" },
          { name: "More-than-20-years", code: "6" },
          { name: "Unknown", code: "7" }
        ]
      }
    ]
  }
};


 async function getEx() {
   //get the codes from each of the objects
   let CMTYPE = await getSelCodes(CMTYPE_A);
   let CMRESTIME = await getSelCodes(CMRESTIME_A);
   let CMRELYEARS = await getSelCodes(CMRELYEARS_A);
   let selected_fields = await selectPopD(CMTYPE, CMRESTIME, CMRELYEARS);

   //let sldr =startSlider.noUiSlider.get()
   let sldr = sld.noUiSlider.get();

   let mindte = Math.trunc(sldr[0] / 10) + 9;

   let maxdte = Math.trunc(sldr[1] / 10) + 9;

   let jsonObj = await getDataComp(mindte, maxdte); //put date parms in here
   let coll = await jsonObj.data;

   await console.log('selected_fields  ', selected_fields);
   await console.log('coll ', coll);

   await console.log('SLIDE------------------ ', mindte, maxdte);

   //create the object for the chart here :
   //need to include the date range here
   //need to create a key value   array of objects

   let arr = [];
   let xcat = [];

   //coll is the name of the collection od data we need to reduce this data  ;

   await coll.map(function(prps, x) {
     //let  date=  new Date(    parseInt (prps.CYM.substring(2, 6))  + '-' +  parseInt (prps.CYM.substring(7, 2)) +'-01' )
     // let  date= new Date(   prps.CYM.substring(2, 6)  + '-' +  prps.CYM.substring(6)  +  '-01'  )
     let date = prps.CYM.substring(2, 6) + prps.CYM.substring(6);
     let yr = parseInt(prps.CYM.substring(2, 6));
     let mth = parseInt(prps.CYM.substring(6));
     let dy = 1;

     //get the props from th YM field
     console.log('prps.YM  ', prps.YM);
     console.log('x------------  ', x);
     console.log('prps.CYM  ', prps.CYM);
     console.log('yr ', yr);
     console.log('mth ', mth);

     let dateUTC = Date.UTC(yr, mth, dy);

     let datatwo = new Date(dateUTC);

     console.log('DateUTC ', dateUTC);
     console.log('date  ', date);

     let obj = { name: parseInt(prps.CYM.substring(2, 8)), y: pickReduce(prps, selected_fields) };

     arr.push(obj);
     xcat.push(date);
   });

   await console.log('xcat  ', xcat);
   await console.log('arr    ', arr);
   await HC(arr, xcat);
 }


//need to create a config object  ????

let configOj =  {

    title:  'hi frm obj'  ,
    type : 'line'

}


//need to add the HC  get the substring of the month year  
async function HC (arr , xcat  ) {
 await Highcharts.chart('chartcontainer', {
    chart: {
        type: 'line'
        , styledMode: true
    }  ,

    legend: {
    enabled: true
  },
       title : {
      text: 'Monthly Stuff'   
   },  
  
   tooltip: {
    pointFormat: "Am: {point.y:.2f}"
  },
  xAxis: {
    categories: xcat ,
  //   ,
 //   labels: {
  //    formatter: function () {
          
    //        console.log  (  this.value )
    //  }
//  }
    tickInterval: 2
},
    series: [{
      name :'mogas',
       data: arr 
        
    }
  ]


})


console.log(arr)

}


//need to add the HC  get the substring of the month year  
async function HCx (arr , xcat  ) {
  await Highcharts.chart('chartcontainer', {
     chart: {
         type: 'line'
         , styledMode: true
     }  ,
 
     legend: {
     enabled: true
   },
        title : {
       text: 'Monthly Stuff'   
    },  
   
    tooltip: {
     pointFormat: "Am: {point.y:.2f}"
   },
   xAxis: {
     categories: xcat ,
    //   ,
     //   labels: {
     //    formatter: function () {
           
     //        console.log  (  this.value )
     //  }
     //  }


     tickInterval: 2
 },
     series: [{
       name :'mogas',
        data: arr 
         
     }
   ]
 
 
 })
 
 console.log(arr)
 }


//todo
/*     chartInfo.xAxis.tickInterval
control for chart type
name the chart and groups insert editable text
Sliders for start end date
sort by sortable class- recreate the dom listing once done
save group and chart
add story text
create publish link
need an admin page   https://www.manning.com/books/node-js-in-action-second-edition#toc
*/


function T2(e) {
 
  //need a set with just the ones included 
  //creATE one big object, the object also can be made to recreate the selected and can bew stored on the mopngo db
  // plus also an upload csv.
  //need a list of meta data  to store the state

    console.log ('CMTYPE   ' ,  CMTYPE ) 
    console.log ('CMRESTIME   ' , CMRESTIME  ) 
    console.log ('CMRELYEARS  ' , CMRELYEARS  ) 
        
  const node = document.createElement("BUTTON");
  const textn = document.createTextNode('x');
    node.appendChild(textn);
    node.setAttribute("class", "uk-button uk-button-default uk-button-small");
      document.getElementById('seedxx').appendChild(node);
      let allobj = {}
        //need to save this somewhere 
        console.log ('node ' ,  node   ) 
  }
  
//https://dev.to/basilcea/remaining-stateless-jwt-cookies-in-node-js-3lle

//function to set the cookes one you have a refresh token ;
//inputs
//need a login function 
//this is the first function and last resort if the token does not work
//need a sign up page
//then need to change that to a login finance


const T1= async ( ) => {
  //delete existing cookies 

  Cookies.remove('tokendata')
  let transport = axios.create({
    withCredentials: true  
  })


  await transport.interceptors.response.use(
    function(response) {
      console.log('intercepted.....')
      return response
    },
    function(error) {
      const errorResponse = error.response
    console.log('err.....'  ,errorResponse.status )
    console.log('errobj.....'  ,errorResponse.data.message )
      return Promise.reject(error)
    }
  )

  //get imput fields from login  

  let userin= document.getElementById("userin").value
  let passin= document.getElementById("passin").value
  console.log('userin... '  , userin  )
  console.log('passin... '  , passin)

  const lgin = {  email: userin ,  //create a form for the user and password
  password: passin }

  console.log('lgin  ... '  , lgin  )


 const da = {  email:'dave@prolitiks.com',  //create a form for the user and password
             password: 'thewinner'}

try {

  const response = await transport({
    url: `v1/auth/login`,
    method: 'post',
    data : da  ,
    onDownloadProgress: function(progressEvent) {}

  });
   await response.data;
   console.log('axios data '  , response.data)
   await  Cookies.set('tokendata', response.data);
}
catch(e) {
  console.log(e.message)
}

// when logged out need to change buttons  each need tp be tagged  

};



const T5= async ( e) => {

 let tokendata= Cookies.getJSON('tokendata')
 console.log('tokendata.....',tokendata )
 console.log('accessToken....',tokendata.data.token['accessToken'] )
 console.log('refreshToken.....',tokendata.data.token['refreshToken'] )
 console.log('email....',tokendata.data.user['email'] )

  }

  //make this generic returning the 
  //put the chart object here 

const T3= async ( ) => {

     let {data}= await Cookies.getJSON('tokendata')
     let user =data.user['id'] 
    //get token from cookie

    const config = {
      method: 'get',
      url: `v1/users/${user}/notes`
  }

    await axios.interceptors.request.use(function(config) {
      if ( data != null ) {
     config.headers.Authorization = 'bearer '+ data.token['accessToken'];
      }
      return config;
    }, function(err) {
      return Promise.reject(err);
    });
    
    
   //need to do something here 

   await axios.interceptors.response.use(
      function(response) {
        console.log('intercepted.....')
        return response
      },
      function(error) {
        const errorResponse = error.response
      console.log('err.....'  ,errorResponse.status )
        return Promise.reject(error)
      }
    )


    let res = await axios(config)

    console.log('user' , user);
    console.log('data token ', data);
    console.log('res  ' , res);

  };

let sld;
  const T4= async ( ) => {

// this is to create data 
// Save data to the current local store
// localStorage.setItem("username", "John");
// Access some stored data      https://putlockerslinks.com/episode/the-mandalorian-season-1-episode-1/#mv-info

    //https://123movies-putlocker.com/
    // function parse(str) {
    //   return Function(`'use strict'; return (${str})`)()   b7c999e511de
    // }  
    // parse('4.12345 * 3.2344 - 9') // 4.336886679999999

   
//let chartName =document.getElementById("myText").value 



 sld =CreateSlideDate ('slide',  '001',  10, 47, dt_arr) 
console.log(sld.noUiSlider.get())

//add 1 times by 10  and starts at position 10 in the db
sld.noUiSlider.set([100, 200]);


}


let dt ='ddsdsdsdsd'
     let noo = {
      chart: {
          type: 'line'  
          , styledMode: true
      }  ,
  
      legend: {
      enabled: true
    },
         title : {
        text: 'Monthly Stuff'   
     },  
    
     tooltip: {
      pointFormat: "Value: {point.y:.2f}"
    },
    xAxis: {
      categories: 'arr',

      tickInterval: 2
  },
      series: [{
        name :'mogas',
         data: dt
      }
    ]
  }



//this is for the new chart info need to refresh before the token is authorised

   const T6= async ( ) => {

    const da = {  email:'dave@prolitiks.com',  //create a form for the user and password
                  password: 'thewinner'}
 
    let {data}= await Cookies.getJSON('tokendata')
    let user =data.user['id'] 
   //get token from cookie

   const config = {
     method: 'post',
     url: `v1/users/${user}/notes/create`,
     data : noo     
 }

   await axios.interceptors.request.use(function(config) {
     if ( data != null ) {
    config.headers.Authorization = 'bearer '+ data.token['accessToken'];
     }
     return config;
   }, function(err) {
     return Promise.reject(err);
   });
   
   
  //need to do something here 

  await axios.interceptors.response.use(
     function(response) {
       console.log('intercepted.....')
       return response
     },
     function(error) {
       const errorResponse = error.response
     console.log('err.....'  ,errorResponse.status )
       return Promise.reject(error)
     }
   )

   let res = await axios(config)

   console.log('user' , user);
   console.log('data token ', data);
   console.log('res  ' , res);
    
 }


//this will get all the data for the chart and store it
//add the pills in order
const T7= async ( ) => {
//get the data from all the sources and return it to a single object
//   export function getSelCodesObj  ( arrObj   , keycode )   {
//     let scrape =[]
//          arrObj.forEach(el => {
//          scrape.push(el[keycode])
//   });
//   return scrape
//  }
 
console.log('T7 fired')

//Get the dropdown controls
 console.log('CMTYPE_A ' ,CMTYPE_A)    
 console.log('CMRESTIME_A  ' ,CMRESTIME_A )    
 console.log('CMRELYEARS_A  ' ,CMRELYEARS_A  )    

 let wee=getSelCodesObj (CMTYPE , 'name')

 console.log('wee  cmtype ' ,wee )    

//vreate simple list for each dont need the pills

//let make a element and then attach it 

//use this as main hook
var element  = document.getElementById('ul'); // assuming ul exists
var fragment = document.createDocumentFragment();
var browsers = wee


CMRELYEARS_A.forEach(function(browser) {
  var li = document.createElement('li');
  li.textContent = browser.name;
  fragment.appendChild(li);
});

element.appendChild(fragment);
}


//insert string https://webplatform.github.io/
function createFragment(htmlStr) {

  var frag = document.createDocumentFragment(),
    temp = document.createElement('div');
  
   temp.innerHTML = htmlStr;
  
  while(temp.firstChild) {
    frag.appendChild(temp.firstChild);
   }
  
  return  frag;
  }




//this needs to take an object and push it into the ithe input of the funtion
//this needs to be a list of object form the db config file.
//like this one 
 



let SEEDR = [
  {
    name: 'COMPLAINT-TYPE',
    code: '2',
    ctype: 'CMTYPE',
    drpdwnSelected: [],
    drpdwn: [
      { name: 'Access', code: '01' },
      { name: 'Advisor-Issues', code: '02' },
      { name: 'Business-Decision', code: '03' },
      { name: 'Comms-Information-Advice', code: '04' },
      { name: 'Credit-Decision', code: '05' },
      { name: 'Introducer', code: '06' },
      { name: 'Investment-Issues', code: '07' },
      { name: 'Letter-of-Notification', code: '08' },
      { name: 'Other-Bank-ATM', code: '09' },
      { name: 'Process', code: '10' },
      { name: 'Product-Features', code: '11' },
      { name: 'Rates-Fees-Charges', code: '12' },
      { name: 'Security', code: '13' },
      { name: 'Service-Failure', code: '14' },
      { name: 'Service-Quality', code: '15' },
      { name: 'St-George-Bank-SA-ATM', code: '16' },
      { name: 'Westpac-ATM	', code: '17' }
    ]
  },

  {
    name: 'RESOLVE-TIME',
    code: '1',
    ctype: 'CMRESTIME',
    drpdwnSelected: [],
    drpdwn: [
      { name: 'Immediately', code: '0' },
      { name: 'Within-7-days', code: '1' },
      { name: 'More-than-7-days', code: '2' },
      { name: 'Unknown', code: '3' }
    ]
  },

  {
    name: 'CUSTOMER-TENURE',
    code: '3',
    ctype: 'CMRELYEARS',
    drpdwnSelected: [],
    drpdwn: [
      { name: 'Less-than-1-year', code: '1' },
      { name: '1-3-years', code: '2' },
      { name: '3-5-years', code: '3' },
      { name: '5-10-years', code: '4' },
      { name: '10-20-years', code: '5' },
      { name: 'More-than-20-years', code: '6' },
      { name: 'Unknown', code: '7' }
    ]
  }
];


  



//version 2
//need to add another object for dropdowns

function createSeeds(ob, key, value, selector) {
  //under start button
  const startn = document.querySelector(selector);
  ob.filter(function(obj) {
    if (obj[key].includes(value)) {
      const { name, drpdwn, ctype, code } = obj;
      startn.insertAdjacentHTML(
        'afterEnd',
        `<button   uk-icon="icon: chevron-down ; ratio: 0.6" id='${ctype}' 
         class="${ctype} ${code} 
         uk-button uk-button-default uk-button-small" >${name} 
         </button>           
         <span class = "flex-container"  id ="${ctype}-B"> </span>`
      );
      const drpdwnIn = `<div  uk-dropdown > <ul id ="${ctype}-DROP" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
      document.querySelector(`#${ctype}`).insertAdjacentHTML('afterEnd', drpdwnIn);
      let filldrop = document.getElementById(`${ctype}-DROP`);
      for (let i = 0; i < drpdwn.length; i++) {
        filldrop.insertAdjacentHTML(
          'beforeEnd',
          `<li><a class ="${ctype} ${drpdwn[i].code}"  href="#" >${drpdwn[i].name}</a></li>`
        );
        filldrop.addEventListener('click', addPillz); //this adds the old pill
      }
    }
  });
}

//this addpill  one at a time  !!!!!!!!!!!!!!!

function addPilly(pillgroup, pillname, pillcode) {
  const pillgp = pillgroup;
  const pilln = pillname;
  const pillc = pillcode;
  const node = document.createElement('SPAN');
  const node2 = node.cloneNode(true);
  const clx = document.createTextNode('x');
  const textnode = document.createTextNode(pilln);
  node.appendChild(textnode);
  node.appendChild(node2);
  node2.appendChild(clx);
  node2.classList.add('close');
  node.classList.add('closea');
  node.classList.add(pillgp, pillc);
  const boxel = document.getElementById(`${pillgp}-B`);
  boxel.appendChild(node);

  let ro = document.querySelectorAll(`#${pillgp}-DROP > li > a.${pillgp}`);
  for (let i = 0; i < ro.length; i++) {
    if (ro[i].className === `${pillgp} ${pillc}`) {
      ro[i].parentNode.remove(); //remove from DOM

      //take away from onject  https://love2dev.com/blog/javascript-remove-from-array/
      //and put into the
    }
  }

  node.addEventListener('click', function() {
    this.remove();
    let filldrop = document.getElementById(`${pillgroup}-DROP`);

    filldrop.insertAdjacentHTML(
      'beforeEnd',
      `<li><a class ="${pillgroup} ${pillcode}"  href="#" >${pillname}</a></li>`
    );
  });


}


//document.querySelector("#CMTYPE-B > span")


function addPillz(e) {
  const pillgroup = e.target.classList[0];
  const pillname = e.target.innerHTML;
  const pillcode = e.target.classList[1];
  addPilly(pillgroup, pillname, pillcode);
        
}


let T8 = function() {

  function pillfill(ob, key, value) {
    ob.filter(function(obj) {
      if (obj[key].includes(value)) {
        const { name, drpdwn, drpdwnSelected, ctype } = obj;
        for (let i = 0; i < drpdwn.length; i++) {
          addPilly(ctype, drpdwn[i].name, drpdwn[i].code);
        }
      }
    });
  }


  function puoba(SEEDR) {
    for (let j = 0; j < SEEDR.length; j++) {
    

      createSeeds(SEEDR, 'ctype', SEEDR[j].ctype, '#seed');
      pillfill(SEEDR, 'ctype', SEEDR[j].ctype);

    }
  }

  puoba(SEEDR)
  // createSeeds(SEEDR, 'ctype', 'CMRESTIME', '#seed');
  // pillfill(SEEDR, 'ctype', 'CMTYPE');
  // pillfill(SEEDR, 'ctype', 'CMRELYEARS');
  // pillfill(SEEDR, 'ctype', 'CMRESTIME');

  //    console.log('SEEDR ' ,SEEDR   )


};



//get the list of objects to put in here  , you will need a loop for this ;
//1. need the filter to be selected first 
//2. then get the list of objects from the       
//3. create one large object with everything????????
//this unction takes the elemt object from the array and pushes it back into 


let T9 = function() {
  //this function reads the node piulls and saves them to the object, this can be then saved back to the database.xx
  //create super object thenndestructure this and put back together
  function pushObj(ob, key, value) {
    ob.filter(function(obj) {
      if (obj[key].includes(value)) {
        const { name, drpdwn, drpdwnSelected, ctype } = obj;
        let dp = document.querySelector(`#${value}-B`).childNodes;
        for (let i = 1; i < dp.length; i++) {
          let pilln = dp[i].textContent; //need to get rid of x at end
          let pillname = pilln.substring(0, pilln.length - 1);
          let pillgroup = dp[i].classList[1]; //this is the name of the group
          let pillcode = dp[i].classList[2]; //this is the name of the group
          drpdwnSelected.push({ name: pillname, code: pillcode });
        }
      }
    });
  }

  function puob(SEEDR) {
    for (let j = 0; j < SEEDR.length; j++) {
      SEEDR[j].drpdwnSelected = [];
      pushObj(SEEDR, 'ctype', SEEDR[j].ctype);
    }
  }

  puob(SEEDR);
  console.log('SEEDR  ', SEEDR);
};




function CreateSlideDate(sliderEl, id ,min, max, arrobj) {
  const YMARR = [];
  for (let i = 0; i < arrobj.length; i++) {
    if (min <= arrobj[i].YMC && max >= arrobj[i].YMC) {
      YMARR.push(arrobj[i].YM);
    }
  }


const startSlider = document.getElementById(sliderEl);
  noUiSlider.create(startSlider, {
    start: [10,370],
    connect: true,
    step: 10,
    range: {
      min: [10],
      max: [370]
    }
  });

 // let datesrg = dateSliderData; 
  let datesrg = YMARR; 
  
  startSlider.insertAdjacentHTML(
    'afterEnd',
    `<button id='slider-margin-value-min-${id}' class="uk-button  uk-button-default uk-button-small" >/button>   
     <button id='slider-margin-value-max-${id}' class="uk-button  uk-button-default uk-button-small" ></button>`
  );

 const marginMin = document.getElementById(`slider-margin-value-min-${id}`),
    marginMax = document.getElementById(`slider-margin-value-max-${id}`);

  startSlider.noUiSlider.on('update', function(values, handle) {
    if (handle) {
      marginMax.innerHTML = datesrg[Math.trunc(values[handle]) / 10 -1];
      console.log('handle  ', values, handle ,'arr ' ,  (Math.trunc(values[handle])  / 10)-1 );
    } else {
      marginMin.innerHTML = datesrg[Math.trunc(values[handle]) / 10 -1];
      console.log('handle  ', values, handle  ,'arr ' ,(Math.trunc(values[handle]) / 10)-1);
    }
  });

  return startSlider
}


//save and add object to the notes
const T10= async ( ) => {
  
  //this designates the user
  //const da = {  email:'dave@prolitiks.com',  password: 'thewinner'}

  let {data}= await Cookies.getJSON('tokendata')
  let user =data.user['id'] 
 //get token from cookie
console.log('data ',  data.token['accessToken'])
 const config = {
   method: 'post',
   url: `v1/users/${user}/notes/5e54c1704fa8443190c31860`,
   data : noo     
}

 await axios.interceptors.request.use(function(config) {
   if ( data != null ) {
  config.headers.Authorization = 'bearer '+ data.token['accessToken'];
   }
   return config;
 }, function(err) {
   return Promise.reject(err);
 });
 
 
//need to do something here 

await axios.interceptors.response.use(
   function(response) {
     console.log('intercepted.....')
  //   window.location.replace("http://localhost:3009/v1/mer");
     return response
   },
   function(error) {
     const errorResponse = error.response
   console.log('err.....'  ,errorResponse.status )
     return Promise.reject(error)
   }
 )


 let res = await axios(config)

 console.log('user' , user);
 console.log('data token ', data);
 console.log('res  ' , res);
  
  
  }



//need a retreval step also need to make one single config object

document.querySelector('#T1').addEventListener('click',  T1);
document.querySelector('#T2').addEventListener('click',  T2);
document.querySelector('#T3').addEventListener('click',  T3);
document.querySelector('#T4').addEventListener('click',  T4);
document.querySelector('#T5').addEventListener('click',  T5);
document.querySelector('#T6').addEventListener('click',  T6);
document.querySelector('#T7').addEventListener('click',  T7);
document.querySelector('#T8').addEventListener('click',  T8);
document.querySelector('#T9').addEventListener('click',  T9);   
document.querySelector('#T10').addEventListener('click', T10);   //save button and load to serv


// https://github.com/beyondtracks/nsw-rfs-majorincidents-archive

