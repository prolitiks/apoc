
/* eslint-disable */
 
    //<li><a href="#">More Details</a></li>
    //tabCell.insertAdjacentHTML('beforeend', drpdwn);
   //need array of objects 
    let dropob = [{ name: 'More Details', action: elget }, { name: 'Variation ', action: elget }];
function dropdown ( dropObj , selector )  {
    for (var k = 0; k < dropob.length; k++) {
      tabCell
        .querySelector('div > ul ')
        .insertAdjacentHTML('beforeend', `<li><a href="#"   > ${dropob[k].name}  </a></li>`);
      tabCell.querySelector(`div > ul > li:nth-child(${k + 1}) > a`).addEventListener('click', dropob[k].action);
    }

  }

