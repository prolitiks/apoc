/* eslint-disable */


export 
let selectControl= [
  {
    crtl: ['div'],
    name: ['PARRA'],
    statcnt: [],
    evfuct: [],
    cls: ['uk-card', 'uk-card-default', 'uk-card-body'],
    freeattr: [],
    dattr: [{ datattr: 'data-id', val: 'card' }],
    after: [],
    cnt: [
      {
        crtl: ['span'],
        name: ['CONE'],
        statcnt: ['TRYNAME'],
        evfuct: ['DROP'],
        evtype: ['click'],
        cntfuct: [],
        statefuct: ['ADDPLST'],
        cls: ['uk-label'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'TRYNAME' },
          { datattr: 'uk-icon', val: 'icon: chevron-down ; ratio: 0.6' },
          { datattr: 'uk-byee' }
        ],
        after: ['<br>'],
        cnt: [],

        //extra ones go here
        drpconfig: [{ type: 'single' , dcnt : 'name' , trigger: 'click'  , divattr : 'uk-dropdown="mode: click' , ulclass : 'uk-nav uk-dropdown-nav' } ]    , 
        drpdwnSelected: [ { name: 'More-than-20-years' }],
        drpdwn: [
          { name: 'Less-than-1-year' },
          { name: '_1-3-years' },
          { name: '_3-5-years' },
          { name: '_5-10-years' },
          { name: '_10-20-years' },
          { name: 'More-than-20-years' },
          { name: 'Unknown' }
        ]
      },
      {
        crtl: ['div'],
        name: ['PILLBOX'],
        statcnt: [],
        evfuct: ['CONE'],
        cls: ['flex-container'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'PILLBOX' },
          { datattr: 'data-rel', val: 'TRYNAME' }
        ],
        after: [],
        cnt: []
      },

      {
        crtl: ['span'],
        name: ['CONE'],
        statcnt: ['TOO BASIC'],
        cls: ['uk-label'],
        evfuct: ['CONE'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'dark' },
          { datattr: 'uk-icon', val: 'icon: chevron-down ; ratio: 0.6' },
          { datattr: 'uk-byee' }
        ],
        after: ['<br><br>'],
        cnt: []
      },

      {
        crtl: ['input'],
        name: ['CONEZZZZ'],
        statcnt: [],

        cls: ['uk-input', 'uk-form-width-small', 'uk-form-small'],
        evfuct: ['DROP'],
        evtype: ['input'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'TRYNAMEX' },
          { datattr: 'type', val: 'text' },
          { datattr: 'placeholder', val: 'BASIC' }
        ],
        after: ['<br>'],
        cnt: [],

        drpconfig: [{ type: 'single' , dcnt : 'name'  , trigger: 'input'} ]    , 
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Lessthanyear' },
          { name: 'xyears' },
          { name: 'syears' },
          { name: 'eeeyears' },
          { name: 'yttttyears' },
          { name: 'Morethan20years' },
          { name: 'Unknown' }
        ]
      },


    
      {
        crtl: ['div'],
        name: ['PILLBOXY'],
        statcnt: [],
        evfuct: ['CONE'],
        cls: ['flex-container'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'PILLBOXY' },
          { datattr: 'data-rel', val: 'TRYNAMEX' }
        ],
        after: [],
        cnt: []
      },


      {
        crtl: ['span'],
        name: ['RANG'],
        statcnt: ['TIME HORIZON'],
        evfuct: [],
        evtype: ['click'],
        cls: ['uk-label'],
        freeattr: [],
        dattr: [{ datattr: 'data-id', val: 'DATESEL' }],
        after: ['<br>'],
        cnt: []
      },
      {
        crtl: ['span'],
        name: ['FRDTE'],
        statcnt: [],
        evfuct: [],
        evtype: [],
        cls: ['closeb'],
        freeattr: [],
        dattr: [{ datattr: 'data-id', val: 'FROMDATE' }],
        after: [],
        cnt: []
      },
      {
        crtl: ['span'],
        name: ['TODTE'],
        statcnt: [],
        evfuct: [],
        evtype: [],
        cls: ['closeb'],
        freeattr: [],
        dattr: [{ datattr: 'data-id', val: 'TODATE' }],
        after: [],
        cnt: []
      },
      {
        crtl: ['div'],
        name: ['slider'],
        statcnt: [],
        cntfuct: ['SLIDE'],
        evfuct: [],
        evtype: [],
        cls: ['sc'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'SLIDER' },
          { datattr: 'data-frm', val: 'FROMDATE' },
          { datattr: 'data-to', val: 'TODATE' }
        ],

        

        after: [],
        cnt: [],
        sldarr: [
          '201710',
          '201711',
          '201712',
          '201801',
          '201802',
          '201803',
          '201804',
          '201805',
          '201806',
          '201807',
          '201808',
          '201809',
          '201810',
          '201811',
          '201812'
        ],
        sldint: {
          start: [2, 6],
          connect: true,
          step: 1,
          range: {
            min: [1],
            max: [7]
          }
        }
      }
    ]
  }
];




export let selectControlv2 = [
  {
    crtl: ['div'],
    name: ['LISTER'],
    statcnt: [],
    evfuct: [],
    cls: ['uk-card', 'uk-card-default', 'uk-card-body'],
    freeattr: [],
    dattr: [{ datattr: 'data-id', val: 'card' }],
    after: [],
    cnt: [
      {
        crtl: ['span'],
        name: ['CONE'],
        statcnt: ['TABLE HIT'],
        cls: ['uk-label'],
        evfuct: ['STABLE'],
        evtype: ['click'],
        freeattr: [],
        dattr: [
          { datattr: 'data-id', val: 'dark' },
          { datattr: 'data-rel', val: 'BOX_A' }
        ],
        after: ['<br><br>'],
        cnt: []
      },

      {
        crtl: ['div'],
        name: ['TABLEBOX'],
        statcnt: [],
        evfuct: [],
        cls: ['flex-container'],
        freeattr: [],
        dattr: [{ datattr: 'data-id', val: 'BOX_A' }],
        after: [],
        cnt: []
      }
    ]
  }
];

