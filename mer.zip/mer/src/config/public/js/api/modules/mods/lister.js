/* eslint-disable */

/*
1. list with table
2. pagiation
3. continus

USAGE example
  let qury =  {    perPage :10  ,sort : 'MerText:desc'   ,   FUZ:'mcd'       }
  getData( `card/fuzz`  , qury    ,`main-box-sel`, 1 );
*/

export function pagination(apiadd, dataObj, afterElemtId, page = '0', pages = 0) {
  const afterEl = document.querySelector(`#${afterElemtId}`);
  const curpg = parseInt(page);
  const nxtpg = curpg + 1;
  const prvpg = curpg - 1;

  console.log(' pag, data obj  ', dataObj);

  let fist = document.querySelector('#pagea > ul');
  if (fist !== null) {
    fist.remove();
  }

  afterEl.insertAdjacentHTML(
    'afterend',
    `<div id ="pagea" class="uk-flex-center"><ul class="uk-pagination" ></ul></div>`
  );

  console.log('apiadd pgation ', apiadd, 'page ', page, 'pages ', pages);

  let li = afterEl.nextElementSibling.lastElementChild;

  // previous <
  // of current page not 1 you can go back
  if (curpg !== 1) {
    li.insertAdjacentHTML('beforeend', `<li><a  href="#"><span uk-pagination-previous></span></a></li>`);

    li.lastChild.addEventListener(
      'click',
      function() {
        getData(`card/fuzz`, dataObj, `main-box-sel`, prvpg);
      },
      false
    );
  } else {
    li.insertAdjacentHTML('beforeend', `<li><a href="#"><span uk-pagination-previous></span></a></li>`);
  }

  console.log('afterEl ', li);
  
  let outpgarr = generatePagination(curpg, pages);
  console.log('outpgarr ', outpgarr);

  // [1, 2, 3, "...", 46]

  for (let i = 0; i < outpgarr.length; i++) {
    li.insertAdjacentHTML('beforeend', `<li><a href="#">${outpgarr[i]}</a></li>`);

    li.lastChild.addEventListener(
      'click',
      function() {
        getData(`card/fuzz`, dataObj, `main-box-sel`, outpgarr[i]);
      },
      false
    );

    if (outpgarr[i] == '...') {
      li.lastChild.classList.add('uk-disabled');
    }
    if (outpgarr[i] == page) {
      li.lastChild.classList.add('uk-active');
    }
  }

  if (curpg < pages) {
    li.insertAdjacentHTML('beforeend', `<li> <a  href="#"><span uk-pagination-next></span></a>  </li>`);
    li.lastChild.addEventListener(
      'click',
      function() {
        getData(`card/fuzz`, dataObj, `main-box-sel`, nxtpg);
      },
      false
    );
  } else {
    li.insertAdjacentHTML('beforeend', `<li><a   href="#"><span uk-pagination-next>.</span></a></li>`);
  }

  function generatePagination(current, last) {
    const offset = 2;
    const leftOffset = current - offset;
    const rightOffset = current + offset + 1;

    /**
     * Reduces a list into the page numbers desired in the pagination
     * @param {array} accumulator - Growing list of desired page numbers
     * @param {*} _ - Throwaway variable to ignore the current value in iteration
     * @param {*} idx - The index of the current iteration
     * @returns {array} The accumulating list of desired page numbers
     */
    function reduceToDesiredPageNumbers(accumulator, _, idx) {
      const currIdx = idx + 1;

      if (
        // Always include first page
        currIdx === 1 ||
        // Always include last page
        currIdx === last ||
        // Include if index is between the above defined offsets
        (currIdx >= leftOffset && currIdx < rightOffset)
      ) {
        return [...accumulator, currIdx];
      }

      return accumulator;
    }

    /**
     * Transforms a list of desired pages and puts ellipsis in any gaps
     * @param {array} accumulator - The growing list of page numbers with ellipsis included
     * @param {number} currentPage - The current page in iteration
     * @param {number} currIdx - The current index
     * @param {array} src - The source array the function was called on
     */
    function transformToPagesWithEllipsis(accumulator, currentPage, currIdx, src) {
      const prev = src[currIdx - 1];

      if (prev != null && currentPage - prev !== 1) {
        return [...accumulator, '...', currentPage];
      }

      // If page does not meet above requirement, just add it to the list
      return [...accumulator, currentPage];
    }
    const pageNumbers = Array(last)
      .fill()
      .reduce(reduceToDesiredPageNumbers, []);
    const pageNumbersWithEllipsis = pageNumbers.reduce(transformToPagesWithEllipsis, []);
    return pageNumbersWithEllipsis;
  }
}


//table
export const ListFromJSON = function(apiadd, dataObj, afterElemtId ,inJson, tableID = 100) {

  //delete existing table  #table-101
  const containEl = document.querySelector(`#${afterElemtId}`);

    let tbl =   containEl.querySelector("table")
    if (tbl !== null) {
      tbl.remove();
    }

   console.log('dataOBj'   ,  apiadd, dataObj);

  let tableHTML = `
   <table id ="table-${tableID}" class="uk-table uk-table-divider uk-table-hover uk-table-small">
   <thead id ="thead-${tableID}"><tr id="thr-${tableID}"></tr></thead>
   <tbody id ="tbody-${tableID}"></tbody>
   </table>`;
  
  containEl.insertAdjacentHTML('beforeEnd', tableHTML);
  const hdr = document.querySelector(`#thead-${tableID}`).firstChild;
  const bdr = document.querySelector(`#tbody-${tableID}`);

    var col = [];
    let rowdata = '';
    //header
    for (var i = 0; i < inJson.length; i++) {
      for (var key in inJson[0]) {
        if (col.indexOf(key) === -1) {
          col.push(key);
          hdr.insertAdjacentHTML('beforeEnd', `<td>${key}</td>`);
        }
      }
      for (var property in inJson[i]) {
        rowdata += `<td>${inJson[i][property]}</td>`;
      }
      bdr.insertAdjacentHTML('beforeEnd', `<tr class ="thr-${tableID}">${rowdata}</tr>`);
     // console.log(bdr.lastChild); event listener addition



      rowdata = '';
    }
 


  }

  
  export const getData = async ( apiadd, dataObj  ,  afterElemtId ,pg ) => {

  let query = [];
  for (let key in dataObj) {
    if (dataObj.hasOwnProperty(key)) {
      query.push(`${encodeURIComponent(key)}=${encodeURIComponent(dataObj[key])}`);
    }
  }
  let srchterm = query.join('&');

  console.log(`/v1/${apiadd}?${srchterm}&page=${pg}`);
  const response = await axios({
    url: `/v1/${apiadd}?${srchterm}&page=${pg}`,
    method: 'get',
    onDownloadProgress: function(progressEvent) {console.log( 'downloaded.......' , progressEvent);  }
  });

  console.log('url ', `/v1/${apiadd}?${srchterm}&page=${pg}`);
  let { data, meta } = await response.data;
  let { perPage, limit, sort, totalCount, pageCount, count, page } = meta;
  let page_ = page.toString();
  await console.log('pagedata: ', perPage, limit, sort, totalCount, pageCount, count, page_);

  await pagination(apiadd, dataObj, afterElemtId , page_, pageCount );
  
  let inJson = await data;
  await console.log('getall: ', inJson);
  await   ListFromJSON(apiadd, dataObj, afterElemtId , inJson, 101);
  return { data, meta };
};




/* eslint-disable */
/*
1. single dropdown single selection
2. multi selection , takes away from dropdown
3. fuzz select local
4. add to state
5. ad chevron button
6. type of array , single or multi object 
7. where to put the selected 
8. scroll 
9. pagiation
*/

