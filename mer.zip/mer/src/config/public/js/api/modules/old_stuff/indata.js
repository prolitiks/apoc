
/* eslint-disable */
export const dta=
{ "M201907CAT13AA08":3038.86,"M201907CAT15AA01":161980.03,"M201907CAT15AA02":298142.71,"M201907CAT15AA03":340151.63,"M201907CAT15AA04":311787.16,"M201907CAT15AA05":134037.02,"M201907CAT15AA06":50958.19,"M201907CAT15AA07":10174.59,"M201907CAT15AA08":1337.03,"M201907CAT16AA01":132005.44,"M201907CAT16AA02":258616.54,"M201907CAT16AA03":328973.49,"M201907CAT16AA04":244834.84,"M201907CAT16AA05":163734.55,"M201907CAT17AA01":4436.88,"M201907CAT17AA02":1470.6,"M201907CAT17AA03":131,"M201907CAT17AA04":1810,"M201907CAT17AA05":286,"M201907CAT17AA06":null,"M201907CAT18AA01":136833.75,"M201907CAT18AA02":198856.64,"M201907CAT18AA03":209102.61,"M201907CAT18AA04":171163.2,"M201907CAT18AA05":78567.09,"M201907CAT18AA06":28791.98,"M201907CAT18AA07":5442.82,"M201907CAT18AA08":1285.4,"M201907CAT19AA01":521923.47,"M201907CAT19AA02":1521979.99,"M201907CAT19AA03":2092265.75,"M201907CAT19AA04":1943440.81,"M201907CAT19AA05":1118449.85,"M201907CAT19AA06":545638.16,"M201907CAT19AA07":170465.18,"M201907CAT19AA08":32294.3,"M201907CAT20AA01":426667.76,"M201907CAT20AA02":728197.42,"M201907CAT20AA03":847700.46,"M201907CAT20AA04":736510.3,"M201907CAT20AA05":336846.78,"M201907CAT20AA06":106208.61,"M201907CAT20AA07":21725.45,"M201907CAT20AA08":1330.18,"M201907CAT21AA01":90574.11,"M201907CAT21AA02":169861.24,"M201907CAT21AA03":254620.48,"M201907CAT21AA04":220700.3,"M201907CAT21AA05":125576.51,"M201907CAT21AA06":94221.94,"M201907CAT21AA07":16590.65,"M201907CAT03AA04":1909.76,"M201907CAT06AA08":129.5,"M201907CAT14AA01":1963.9,"M201907CAT14AA02":19135.76,"M201907CAT14AA03":20050.56,"M201907CAT14AA04":28114.67,"M201907CAT14AA05":37166.63,"M201907CAT14AA06":32661.31,"M201907CAT14AA07":8371.48,"M201907CAT14AA08":330.87,"M201907CAT16AA06":70389.55 }


//need to decide if the config obj is good or not



let CONFIGOBARR = [
  {
    CHFIG: {
      chartconfig: {
        chart: {
          type: "line",
          styledMode: true
        },

        legend: {
          enabled: true
        },
        title: {
          text: "Monthly Stuff"
        },

        tooltip: {
          pointFormat: "Am: {point.y:.2f}"
        }
      }
    }
  },
  {
    SEEDR: [
      {
        name: "COMPLAINT-TYPE",
        code: "2",
        ctype: "CMTYPE",
        drpdwnSelected: [],
        drpdwn: [
          { name: "Access", code: "01" },
          { name: "Advisor-Issues", code: "02" },
          { name: "Business-Decision", code: "03" },
          { name: "Comms-Information-Advice", code: "04" },
          { name: "Credit-Decision", code: "05" },
          { name: "Introducer", code: "06" },
          { name: "Investment-Issues", code: "07" },
          { name: "Letter-of-Notification", code: "08" },
          { name: "Other-Bank-ATM", code: "09" },
          { name: "Process", code: "10" },
          { name: "Product-Features", code: "11" },
          { name: "Rates-Fees-Charges", code: "12" },
          { name: "Security", code: "13" },
          { name: "Service-Failure", code: "14" },
          { name: "Service-Quality", code: "15" },
          { name: "St-George-Bank-SA-ATM", code: "16" },
          { name: "Westpac-ATM	", code: "17" }
        ]
      },

      {
        name: "RESOLVE-TIME",
        code: "1",
        ctype: "CMRESTIME",
        drpdwnSelected: [],
        drpdwn: [
          { name: "Immediately", code: "0" },
          { name: "Within-7-days", code: "1" },
          { name: "More-than-7-days", code: "2" },
          { name: "Unknown", code: "3" }
        ]
      },

      {
        name: "CUSTOMER-TENURE",
        code: "3",
        ctype: "CMRELYEARS",
        drpdwnSelected: [],
        drpdwn: [
          { name: "Less-than-1-year", code: "1" },
          { name: "1-3-years", code: "2" },
          { name: "3-5-years", code: "3" },
          { name: "5-10-years", code: "4" },
          { name: "10-20-years", code: "5" },
          { name: "More-than-20-years", code: "6" },
          { name: "Unknown", code: "7" }
        ]
      }
    ]
  },

  {
    TIMEHZ: [
      { YMC: 10, YM: "201610" },
      { YMC: 46, YM: "201910" }
    ]
  }
];



