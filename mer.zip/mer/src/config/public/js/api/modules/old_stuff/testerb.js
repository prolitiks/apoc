

/* eslint-disable */

export function wili () {

  console.log('hi from map')
  
  }

 export const red8 = [
  "#ffffcc",
  "#ffeda0",
  "#fed976",
  "#feb24c",
  "#fd8d3c",
  "#fc4e2a",
  "#e31a1c",
  "#b10026"
];


var mapboxAccessToken =
  "pk.eyJ1IjoibW9nYXMiLCJhIjoiY2ppaWsxeXV3MWtuZzNxcG4zNTVmN3RteSJ9.2OsUOp70d2VPpc-51-fmcg";

var grayscale = L.tileLayer(
  "https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=" +
    mapboxAccessToken,
  {
    id: "mapbox.light",
    attribution: "MAPS INC."
  }
);

var map = L.map("mapid", {
  center: [-33.53434354312, 147.061051828579],
  zoom: 6,
  layers: [grayscale]
});

//C201912CAT11AF11

//need to do multiple loops

/* eslint-disable */



  let viewpop=  'M' //merchant or customer
  let dates =[ '201912','201911' ]
  let mers =[ '01','02','03' ]
  let dob =[ '11','12','13','15','16' ]
  let sex =[ 'M','F']

  let BUTT_YM_A=[]
  let BUTT_AGE_A = []
  let BUTT_MERCAT_A = []
  let BUTT_SEX_A = []


  let BUTT_YM= [{ name: '201912'  , code : '201912'  , action: addPill}, 
                { name: '201911'    , code : '201911' , action: addPill }  
 ,              { name: '201910'  , code : '201910' , action: addPill}    
   
];


  let BUTT_AGE = [{ name: '18-25'  , code : '01'  , action: addPill}, 
  { name: '35-55'   , code : '02'    , action: addPill }  
 , { name: '45-55'   , code : '03'  , action: addPill}    
   , { name: '65-95'   , code : '04' , action: addPill }      
];



     let BUTT_MERCAT = [{ name: 'Supermarket' , code : '01'  ,     action: addPill}, 
                  { name: 'Resturant'  , code : '02'   , action: addPill }  
                 , { name: 'ServiceStation' , code : '03'   , action: addPill}    
                   , { name: 'DepartmentStore'  , code : '04'  , action: addPill }      
     ];

     let BUTT_SEX = [{ name: 'F' , code : 'M'  ,    action: addPill}, 
     { name: 'M'  , code : 'M'   , action: addPill }  
   
];

   function addPill(e) {

     const actiontype = e.target.innerHTML;  //send the class name to the close button
     // name of the object 

     let targObj =eval(e.target.classList[0])
     let tartype =e.target.classList[0]
     let tartcode =e.target.classList[1]
    console.log( 'tartype :', tartype    )
    console.log( 'tarcode :', tartcode    )
   
     const node = document.createElement('SPAN');
     const node2 = document.createElement('SPAN');
     const textnode2 = document.createTextNode('x');
     const textnode = document.createTextNode(actiontype);
     node.appendChild(textnode);
     node.appendChild(node2);
     node2.appendChild(textnode2);
     node2.classList.add('close');
     node.classList.add('closea');
     node.classList.add(tartype ,tartcode );
     document.getElementById('selmulti').appendChild(node);


       //  add to the array version of the select object  
       // select the value of the array  
       let arrtype = eval(`${tartype}_A`)
      // arrtype.push(actiontype)
        console.log ('arrtype :' ,arrtype   )
    


     //take out the selected from the dropdown for next time  document.querySelector("#BUTT_MERCAT-DROP")
     for (let m = 0; m < targObj.length; m++) {
       if (targObj[m].name === actiontype) {

        console.log( 'targObj[m].name  ', targObj[m]   )
        arrtype.push(targObj[m])
        targObj.splice(m, 1);

         e.target.parentNode.remove();
        
         console.log( ' arrtype ',  arrtype   )
      
       }
     }
     let closebtns = document.getElementsByClassName(`closea ${tartype}`)[0];
    
     closebtns.addEventListener('click', function() {
       let ps = this.classList[2];
       let name=  this.firstChild.nodeValue;
       console.log( 'ps ', this.classList   )
       this.remove();
       targObj.splice(0, 0, { name: name,   code: ps , action: addPill });

       //need to remove here get index first  
       let removeIndex =  arrtype.map(function(item) { return item.name; }).indexOf(actiontype);
       arrtype.splice(removeIndex, 1);

       console.log( 'targObj remove ', targObj   )
       console.log( 'arrtype remove ', arrtype  )


       let targ = e.target.classList[0]
       let dropob = targObj
       let filldrop = document.getElementById(`${targ}-DROP`);




       //remove siblinings first
       while (filldrop.hasChildNodes()) {
         filldrop.removeChild(filldrop.firstChild);
       }
       for (var k = 0; k < dropob.length; k++) {
         filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ="${e.target.classList[0]} ${ps}"  href="#" >${dropob[k].name}</a></li>`);
         filldrop.addEventListener('click', dropob[k].action); 
       }   
     });
   }


   function hov(e) {
     let targ = e.target.id;
     const drpdwnIn = `</span> <div  uk-dropdown ="pos: middle-top"> <ul id ="${targ}-DROP" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
     let dropob = eval(targ);
     this.insertAdjacentHTML('afterEnd', drpdwnIn);
     let filldrop = document.getElementById(`${targ}-DROP`);

     for (var k = 0; k < dropob.length; k++) {
       filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ="${e.target.id} ${dropob[k].code}"  href="#" >${dropob[k].name}</a></li>`);
       filldrop.addEventListener('click', dropob[k].action); //the action will be to add the pill and reduce the dropdown list
     }
     console.log('fill ', filldrop);
   }

   document.querySelector('#BUTT_MERCAT').addEventListener('click', hov);
   document.querySelector('#BUTT_AGE').addEventListener('click', hov);
   document.querySelector('#BUTT_YM').addEventListener('click', hov);
 

function selectPop(viewpop = 'M', dates, mers, sex, dob) {
  let final = [];
  const CAT = 'CAT';
  const A = 'A';
  for (let i = 0; i < dates.length; i++) {
    let dt = `${viewpop}${dates[i]}`;
    for (let j = 0; j < mers.length; j++) {
      let mdt = `${dt}${CAT}${mers[j]}`;
      for (let k = 0; k < sex.length; k++) {
        let sx = `${mdt}${A}${sex[k]}`;
        for (let m = 0; m < dob.length; m++) {
          let db = `${sx}${dob[m]}`;
          final.push(db);
        }
      }
    }
  }
  return final;
}

// takes an array of objects spits out codes
function getSelCodes  ( arrObj )   {
   let scrape =[]
  arrObj.forEach(el => {
    scrape.push(el.code)
  });
  return scrape
}

//getSelCodes 

let win =getSelCodes (BUTT_MERCAT)
console.log(win)

console.log( 'select pop'  , selectPop ('M',dates, win,sex ,dob))

let newone={"ABSCODE":401011002,"ARAN":"North Adelaide","ATYPE":"SA2","STATE":4,"GCCSA":"4GADE","C201912CAT11AF11":112718,"C201912CAT12AF12":103950,"C201912CAT13AF13":100988,"C201912CAT14AF14":26815,"C201912CAT15AF15":80395,"C201912CAT16AF16":69172,"C201912CAT17AF17":200204,"C201912CAT18AF18":102117,"C201912CAT19AF19":144855,"C201912CAT20AF20":119204,"C201912CAT21AF21":29083,"C201912CAT22AF11":66695,"C201912CAT23AF12":90982,"C201912CAT24AF13":102645,"C201912CAT25AF14":115094,"C201912CAT26AF15":103000,"C201912CAT27AF16":135476,"C201912CAT28AF17":30985,"C201912CAT29AF18":90464,"C201912CAT30AF19":138322,"C201912CAT31AF20":124227,"C201912CAT32AF21":138422,"C201912CAT12AM12":158100,"C201912CAT13AM13":124030,"C201912CAT14AM14":null,"C201912CAT15AM15":3782,"C201912CAT16AM16":11568,"C201912CAT17AM17":41759,"C201912CAT18AM18":74664,"C201912CAT19AM19":116185,"C201912CAT20AM20":49462,"C201912CAT21AM21":92786,"C201912CAT22AM11":104547,"C201912CAT23AM12":26773,"C201912CAT24AM13":71791,"C201912CAT25AM14":68133,"C201912CAT26AM15":83810,"C201912CAT27AM16":99809,"C201912CAT28AM17":103302,"C201912CAT29AM18":102467,"C201912CAT30AM19":29317,"C201912CAT31AM20":66599,"C201912CAT32AM21":93685,"C201912CAT11AM11":111832,"M201912CAT11AF11":147751,"M201912CAT12AF12":114435,"M201912CAT13AF13":128356,"M201912CAT14AF14":38868,"M201912CAT15AF15":92279,"M201912CAT16AF16":111518,"M201912CAT17AF17":167670,"M201912CAT18AF18":185927,"M201912CAT19AF19":138822,"M201912CAT20AF20":176081,"M201912CAT21AF21":112718,"M201912CAT22AF11":103950,"M201912CAT23AF12":100988,"M201912CAT24AF13":26815,"M201912CAT25AF14":80395,"M201912CAT26AF15":69172,"M201912CAT27AF16":200204,"M201912CAT28AF17":102117,"M201912CAT29AF18":144855,"M201912CAT30AF19":119204,"M201912CAT31AF20":29083,"M201912CAT32AF21":66695,"M201912CAT12AM12":90982,"M201912CAT13AM13":102645,"M201912CAT14AM14":115094,"M201912CAT15AM15":103000,"M201912CAT16AM16":135476,"M201912CAT17AM17":30985,"M201912CAT18AM18":90464,"M201912CAT19AM19":138322,"M201912CAT20AM20":124227,"M201912CAT21AM21":138422,"M201912CAT22AM11":158100,"M201912CAT23AM12":124030,"M201912CAT24AM13":null,"M201912CAT25AM14":3782,"M201912CAT26AM15":11568,"M201912CAT27AM16":41759,"M201912CAT28AM17":74664,"M201912CAT29AM18":116185,"M201912CAT30AM19":49462,"M201912CAT31AM20":92786,"M201912CAT32AM21":104547,"M201912CAT11AM11":26773,"C201911CAT11AF11":71791,"C201911CAT12AF12":68133,"C201911CAT13AF13":83810,"C201911CAT14AF14":99809,"C201911CAT15AF15":103302,"C201911CAT16AF16":102467,"C201911CAT17AF17":29317,"C201911CAT18AF18":112718,"C201911CAT19AF19":103950,"C201911CAT20AF20":100988,"C201911CAT21AF21":26815,"C201911CAT22AF11":80395,"C201911CAT23AF12":69172,"C201911CAT24AF13":200204,"C201911CAT25AF14":102117,"C201911CAT26AF15":144855,"C201911CAT27AF16":119204,"C201911CAT28AF17":29083,"C201911CAT29AF18":66695,"C201911CAT30AF19":90982,"C201911CAT31AF20":102645,"C201911CAT32AF21":115094,"C201911CAT12AM12":103000,"C201911CAT13AM13":135476,"C201911CAT14AM14":30985,"C201911CAT15AM15":90464,"C201911CAT16AM16":138322,"C201911CAT17AM17":124227,"C201911CAT18AM18":138422,"C201911CAT19AM19":158100,"C201911CAT20AM20":124030,"C201911CAT21AM21":null,"C201911CAT22AM11":3782,"C201911CAT23AM12":11568,"C201911CAT24AM13":41759,"C201911CAT25AM14":74664,"C201911CAT26AM15":116185,"C201911CAT27AM16":49462,"C201911CAT28AM17":92786,"C201911CAT29AM18":104547,"C201911CAT30AM19":26773,"C201911CAT31AM20":71791,"C201911CAT32AM21":68133,"C201911CAT11AM11":83810,"M201911CAT11AF11":99809,"M201911CAT12AF12":103302,"M201911CAT13AF13":102467,"M201911CAT14AF14":29317,"M201911CAT15AF15":112718,"M201911CAT16AF16":103950,"M201911CAT17AF17":100988,"M201911CAT18AF18":26815,"M201911CAT19AF19":80395,"M201911CAT20AF20":69172,"M201911CAT21AF21":200204,"M201911CAT22AF11":102117,"M201911CAT23AF12":144855,"M201911CAT24AF13":119204,"M201911CAT25AF14":29083,"M201911CAT26AF15":66695,"M201911CAT27AF16":90982,"M201911CAT28AF17":102645,"M201911CAT29AF18":115094,"M201911CAT30AF19":103000,"M201911CAT31AF20":135476,"M201911CAT32AF21":30985,"M201911CAT12AM12":90464,"M201911CAT13AM13":138322,"M201911CAT14AM14":124227,"M201911CAT15AM15":138422,"M201911CAT16AM16":158100,"M201911CAT17AM17":124030,"M201911CAT18AM18":null,"M201911CAT19AM19":3782,"M201911CAT20AM20":11568,"M201911CAT21AM21":41759,"M201911CAT22AM11":74664,"M201911CAT23AM12":116185,"M201911CAT24AM13":49462,"M201911CAT25AM14":92786,"M201911CAT26AM15":104547,"M201911CAT27AM16":26773,"M201911CAT28AM17":71791,"M201911CAT29AM18":68133,"M201911CAT30AM19":83810,"M201911CAT31AM20":99809,"M201911CAT32AM21":103302,"M201911CAT11AM11":102467}



let ge= {"geometry":{"coordinates":[[[149.23147998800005,-35.34225700299993]]],"type":"Polygon"},"properties":{"SA2_MAIN16":"101021009","SA2_5DIG16":"11009","SA2_NAME16":"Queanbeyan","SA3_CODE16":"10102","SA3_NAME16":"Queanbeyan","SA4_CODE16":"101","SA4_NAME16":"Capital Region","GCC_CODE16":"1RNSW","GCC_NAME16":"Rest of NSW","STE_CODE16":"1","STE_NAME16":"New South Wales","AREASQKM16":"4.7634"},"type":"Feature","_id":"5d98173f32d188820316d0ce",
 "tran":[{"MER_SA2":"101021009","CTRAN1":44330.5999527   ,"CTRAN2":44330.5999527  ,"CTRAN3":44330.5999527  ,"CTRAN4":44330.5999527   }],"id":"5d98173f32d188820316d0ce"}




 let rfnw  =[ { "CTRAN1":44330.5999527   ,"CTRAN2":44330.5999527  ,"CTRAN3":44330.5999527  ,"CTRAN4":44330.5999527  } ]   
 let wegot = [ "CTRAN1", "CTRAN2"  ,"CTRAN3"   ]
 let videa = [44330.5999527 ,44330.5999527 ,44330.5999527 ]
 

 // this is what the user selects
 const ALLOWED_FIELDS = [
 'C201912CAT11AF11',
 'C201912CAT12AF12',
 'C201912CAT13AF13',
 'M201911CAT11AF11',
 'M201911CAT12AF12',
 'M201911CAT13AF13',
 'M201911CAT14AF14',
 'M201911CAT15AF15',
 'M201911CAT16AF16',
 'M201911CAT17AF17',
 'M201911CAT18AF18',
 'M201911CAT19AF19',
 'M201911CAT20AF20',
 'M201911CAT21AF21',
 'M201911CAT22AF11',
 'M201911CAT23AF12',
 'M201911CAT24AF13',
 'M201911CAT25AF14',
 'M201911CAT26AF15',
 'M201911CAT27AF16',
 'M201911CAT24AM13',
 'M201911CAT25AM14',
 'M201911CAT26AM15',
 'M201911CAT27AM16',
 'M201911CAT28AM17',
 'M201911CAT29AM18',
 'M201911CAT30AM19',
 'M201911CAT31AM20',
 'M201911CAT32AM21',
 'M201911CAT11AM11'
 ];

//picks selected vales and aggreagtes them
 function pickReduce (object, [...userSelect ] ) {
   //selected object  
   const kval= userSelect.reduce((o, e) => {return o[e] = object[e], o}, {});
    //get values from selected key value and create array
    const jval= Object.values(kval) 
    let sum = jval.reduce(function (accumulator, currentValue) {
     return accumulator + currentValue;
   }, 0);
   return sum
 }
 
 let poo= pickReduce (newone, ALLOWED_FIELDS )
 console.log(poo)

