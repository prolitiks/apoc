/* eslint-disable */

//need to create the query string first
//http://localhost:3009/v1/card?limit=100&page=6&perPage=50&sort=MerText:desc
//https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=Museum%20of%20Contemporary%20Art%20Australia&inputtype=textquery&fields=photos,formatted_address,name,rating,opening_hours,geometry&key=YOUR_API_KEY

//localhost:3009/v1/users?fields=id,name&name=*john* (get id & name only in response)
//localhost:3009/v1/users?role=admin&page=1&perPage=20 (query & pagination)
//localhost:3009/v1/users?role=admin&limit=5&offset=0&sort=email:desc,createdAt
//need evir var for name of app, need to add the date
//start by buiiding the query

//https://codepen.io/imarkrige/pen/vgmij

//srchterm, pg, apiadd  ,sortby
// these are global variables just incase they are needed

// import { square } from './modules/inputUtils.js';

// console.log('sq: ' ,square(10))



let Bmertype = "M1SXSDWD";

var appla  =  function  () 
{

  const node = document.createElement("SPAN");
  const node2 = document.createElement("SPAN");
  const textnode2 = document.createTextNode('x');
  const textnode = document.createTextNode(Bmertype);  
  node.appendChild(textnode);
  node.appendChild(node2);
  node2.appendChild(textnode2);
  node2.classList.add("close");
  node.classList.add("closea");
  document.getElementById("selmulti").appendChild(node);
  closebtns = document.getElementsByClassName("close");

  let i;
  for (i = 0; i < closebtns.length; i++) {
    closebtns[i].addEventListener("click", function() {
  
      this.parentElement.remove()
    });
  }
}

var applabel = document.getElementById("APP1");
applabel.addEventListener("click", appla);





let crSrchterm;
let crPg;
let crApiadd;
let crSortby;
//let crsortdir = crSortby.split(':').pop();

function sorted(sortvar) {
  //clear direction arrow code here delete all arrows
  let sortdir = crSortby.split(':').pop();
  sortdir = `:${sortdir}`;

  if (sortdir === `:desc`) {
    sortdir = '';
    //put direction arrow code here - up
  } else {
    sortdir = `:desc`;
    //put direction arrow code here - down
  }
  crSortby = `&sort=${sortvar}${sortdir}`;
  getAllStuff2(crSrchterm, crPg, crApiadd, crSortby);
}

let circ = document.querySelector('#spina');
let tabshow = document.querySelector('#showData');
circ.style.display = 'none';

//document.querySelector("#spina")
//common function to remoove dom
//document.querySelector("#pagea > ul > li > a > span > svg") need to handle no results
let removestuff = () => {
  let tabshow = document.querySelector('#showData > table');
  if (tabshow !== null) {
    tabshow.remove();
  }
  let fist = document.querySelector('#pagea > ul');
  if (fist !== null) {
    fist.remove();
  }
};

let buildQuery = function(data) {
  if (typeof data === 'string') return data;
  let query = [];
  for (let key in data) {
    if (data.hasOwnProperty(key)) {
      query.push(`${encodeURIComponent(key)}=${encodeURIComponent(data[key])}`);
    }
  }
  return query.join('&');
};

//default query
let cardData = {
  limit: 10,
  perPage: 10
};

//default query
let abrData = {
  limit: 10,
  perPage: 10
};

let querya = buildQuery(cardData);
let queryabr = buildQuery(abrData);
let srchterm = buildQuery(cardData);

var params = {};
var inJson;
var instory;
//ge

//http://localhost:3009/v1/abr?limit=100&skip=50&TRADNF=MAJESTIC%20NURSERIES
//need to make generic
const getData = async (srchterm = srchterm, pg = 1, apiadd, sortby = `&sort=MerText:desc`) => {
  console.log(`/v1/${apiadd}?${srchterm}&page=${pg}${sortby}`);

  crSrchterm = srchterm;
  crPg = pg;
  crApiadd = apiadd;
  crSortby = sortby;

  const response = await axios({
    url: `/v1/${apiadd}?${srchterm}&page=${pg}${sortby}`,
    method: 'get',
    onDownloadProgress: function(progressEvent) {}
  });
  let { data, meta } = await response.data;
  let { perPage, limit, sort, totalCount, pageCount, count, page } = meta;
  let page_ = page.toString();
  await console.log('pagedata: ', perPage, limit, sort, totalCount, pageCount, count, page_);
  //await pagination(apiadd, page_ , pageCount   )
  await pagination(srchterm, apiadd, page_, pageCount);
  inJson = await data;
  await console.log('getall: ', inJson);
  return data;
};

const getDataGoogle = async (srchterm = srchterm, pg = 1, apiadd) => {
  console.log(`/v1/${apiadd}?${srchterm}`);
  const response = await axios({
    url: `/v1/${apiadd}?${srchterm}`,
    method: 'get',
    onDownloadProgress: function(progressEvent) {}
  });
  let { candidates } = await response.data;
  // console.log(data)
  return candidates;
};

//this is for multiple search paramters

function searchp(elname) {
  const allins = document.getElementsByClassName(`${elname}`);
  for (i = 0; i < allins.length; i++) {
    params[allins[i].id] = allins[i].value;
  }
  return (queryString = Object.keys(params)
    .map(key => key + '=' + params[key])
    .join('&'));
}

let querys = '';

// const kydown =   document.getElementById("in1").addEventListener('keyup', keyserc)
document.getElementById('in1').addEventListener('keyup', keyserc);
document.getElementById('in2').addEventListener('keyup', keyserc2);
document.getElementById('in3').addEventListener('keyup', keyserc3);
document.getElementById('but3').addEventListener('click', keyserc4);
document.getElementById('but5').addEventListener('click', googleser);

//document.querySelector("#showData > table > tbody > tr:nth-child(6) > td:nth-child(6)")

function keyserc(e) {
  //console.log('keys :' , e.code  )
  let curval = document.getElementById('in1').value;
  if (curval.length > 2) {
    let fuzcode = `&FUZ=${encodeURIComponent(curval)}`;
    getAllStuff2(`limit=10&perPage=10${fuzcode}`, 1, `card/fuzz`, `&sort=MerText:desc`);
    console.log('curval  :', fuzcode);
  }
}
function keyserc2(e) {
  //console.log('keys :' , e.code  )
  let curval = document.getElementById('in2').value;
  if (curval.length > 2) {
    let fuzcode = `&FUZ=${encodeURIComponent(curval)}`;
    getAllStuff2(`limit=10&perPage=10${fuzcode}`, 1, `abr/fuzz`, `&sort=MerText:desc`);
    console.log('curval  :', fuzcode);
  }
}
function keyserc3(e) {
  //console.log('keys :' , e.code  )
  let curval = document.getElementById('in3').value;
  if (curval.length > 2) {
    let fuzcode = `&FUZ=${encodeURIComponent(curval)}`;
    getAllStuff2(`limit=10&perPage=10${fuzcode}`, 1, `maven/fuzz`, `&sort=MerText:desc`);
    console.log('curval  :', fuzcode);
  }
}

function keyserc4(e) {
  let gog = [
    {
      formatted_address: '500 Oxford St, Bondi Junction NSW 2022, Australia',
      geometry: {},
      name: 'Coles Bondi Westfield',
      place_id: 'ChIJ4RVpf_GtEmsRUk0R9G51I4Q'
    },
    {
      formatted_address: 'Spring St &, Newland St, Bondi Junction NSW 2022, Australia',
      geometry: {},
      name: 'Coles Bondi Junction',
      place_id: 'ChIJ3aGL6PCtEmsRQLzJ01IhWco'
    }
  ];

  CreateTableFromJSON(gog, 1, 1, [1], [1]);

  //https://medium.com/@paigen11
  //https://developers.google.com/maps/documentation/javascript/places
}

async function googleser(e) {
  //console.log('keys :' , e.code  )  /mer/getexternal?place_id=ChIJm0LtxDWklWsRblaGGrzuZ9I
  let curval = document.getElementById('in4').value;
  if (curval.length > 4) {
    let fuzcode = `input=${encodeURIComponent(curval)}`;
    getAllStuff3(`${fuzcode}`, 1, `mer/getexternal`, ``);
    console.log('curval google :', fuzcode);
  }
}

// getAllStuff2 (`limit=10&perPage=10`, 1, `card`  ,`&sort=MerText:desc` )
//need to get current searh term

const getAllStuff2 = async (srchterm, pg, apiadd, sortby) => {
  removestuff();
  //step 1
  // const querys = await searchparms()

  circ.style.display = 'block';
  //querys = await  searchp (elname)
  await console.log('querya 1 : ', srchterm, pg, apiadd, sortby);

  //step 2
  let docs = await getData(srchterm, pg, apiadd, sortby);

  const drpdwn = `<span><a href="#">...</a>
</span> <div uk-dropdown ="pos: right-top">  
<ul class="uk-nav uk-dropdown-nav">

</ul>
</div>`;
  // //step 3   fill the table
  await console.log('returned docs: ', docs);
  await CreateTableFromJSON(docs, 1, 0, [0], [0], drpdwn);
  circ.style.display = 'none';
};


//document.getElementById("but1").addEventListener('click', getAllStuff)    document.querySelector("#showData > table > tbody > tr:nth-child(6) > td:nth-child(12) > div > ul > li > a") <li><a href="#">More Details</a></li>

//edit or delete actions based on getting the id from the click event
function elget(e) {
  //put a special id on the prod and user ids and add an event lister function to them
  //start off with https://github.com/ngduc/node-rem/blob/master/src_docs/features.md

  const actiontype = e.target.innerHTML;
  console.log('inner html ', actiontype);
}

//create special links for columns that are links , bold etc.
//need to add more event listeners
let nodata = [{ NO: 'DATA' }];
let tagopen1 = '';
let tagclose1 = '';
let tag1 = 'H4';
let attr1 = ' ';
let cls1 = ' ';
let lnk1 = ' ';
//these are the cols to change
// const hidecolhead =[0]
// const hidehcolrows =[0]

//how do we select the id from the button  pressed
//need to add the triggers
function CreateTableFromJSON(inJson = nodata, colid = 1, colidx = 0, hidecolhead = [0], hidehcolrows = [0], drpdwn) {
  console.log('arg   ', arguments.length);
  // EXTRACT VALUE FOR HTML HEADER.

  var col = [];
  for (var i = 0; i < inJson.length; i++) {
    for (var key in inJson[i]) {
      if (col.indexOf(key) === -1) {
        col.push(key);
      }
    }
  }
  console.log('cols ', col);
  // CREATE DYNAMIC TABLE.
  var table = document.createElement('table');
  table.classList.add('uk-table', 'uk-table-hover', 'uk-text-small');
  // CREATE HTML TABLE HEADER ROW USING THE EXTRACTED HEADERS ABOVE.
  var tr = table.insertRow(-1); // TAB    LE ROW.
  for (var i = 0; i < col.length; i++) {
    var th = document.createElement('th'); // TABLE HEADER no changes needed to the header.
    //   th.innerHTML =   `<a  class="sort-by" onclick="sorted  ( ${col[i]} )"   href="" >  ${col[i]}  </a>`  ;
    th.innerHTML = `<a  class="sort-by" onclick="sorted  ( '${col[i]}' )"    >  ${col[i]}  </a>`;
    tr.appendChild(th); // this is the normal condition  class="sort-by"

    if (hidecolhead.includes(i)) {
      th.hidden = true;
    }
  }
  // ADD JSON DATA TO THE TABLE AS ROWS.
  for (var i = 0; i < inJson.length; i++) {
    tr = table.insertRow(-1);

    for (var j = 0; j < col.length; j++) {
      var tabCell = tr.insertCell(-1);

      //    tabCell.innerHTML = inJson[i][col[j]];

      tabCell.addEventListener('click', elget);

      let w = inJson[i][col[j]];
      if (j === colid) {
        // j is the col, ive selected here for highlighting or whatever
        tabCell.innerHTML = `${tagopen1}${w}${tagclose1}`;
      }
      if (j === colidx) {
        // j is the col, ive selected here for highlighting or whatever
        tabCell.innerHTML = `${tagopen1}${w}${tagclose1}`;
        //    tabCell.addEventListener('click', testgetEl2);
      }
      //hidden values for ids etc
      if (hidehcolrows.includes(j)) {
        //do something else here
        tabCell.hidden = true;
      } else {
        tabCell.innerHTML = w; // this is the normal condition
      }
    }

    var tabCell = tr.insertCell(-1);
    //<li><a href="#">More Details</a></li>
    tabCell.insertAdjacentHTML('beforeend', drpdwn);

    let dropob = [{ name: 'More Details', action: elget }, { name: 'Variation ', action: elget }];

    for (var k = 0; k < dropob.length; k++) {
      tabCell
        .querySelector('div > ul ')
        .insertAdjacentHTML('beforeend', `<li><a href="#"   > ${dropob[k].name}  </a></li>`);
      tabCell.querySelector(`div > ul > li:nth-child(${k + 1}) > a`).addEventListener('click', dropob[k].action);
    }

    ///put this in a loop based on a dropdown object  ;
  }

  // FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
  var divContainer = document.getElementById('showData');
  divContainer.innerHTML = '';
  divContainer.appendChild(table);
}

//this is the query parms to pass to the post request, so get all the classses here as serch parms
//the name of the class or classes  will be the name of the input parms !!!!!!

function searchparms() {
  const allins = document.getElementsByClassName('inc');
  for (i = 0; i < allins.length; i++) {
    params[allins[i].id] = allins[i].value;
  }
  return (queryString = Object.keys(params)
    .map(key => key + '=' + params[key])
    .join('&'));
}

function pagination(srchterm, apiadd, page = '0', pages = 0) {
  console.log('apiadd pgation ', apiadd, 'page ', page, 'pages ', pages);

  let fist = document.querySelector('#pagea > ul');
  if (fist !== null) {
    fist.remove();
  }

  console.log('first ', fist);
  const curpg = parseInt(page);
  const nxtpg = curpg + 1;
  const prvpg = curpg - 1;

  let ul = document.createElement('ul');
  let pg = document.getElementById('pagea');
  pg.appendChild(ul);
  ul.classList.add('uk-pagination');
  let li = document.createElement('li');
  ul.appendChild(li);
  if (curpg !== 1) {
    li.insertAdjacentHTML(
      'beforeend',
      `<a  onclick="getAllStuff2 ( '${srchterm}' , ${prvpg},  '${apiadd}' )" href="#"><span uk-pagination-previous></span></a>`
    );
    // (srchterm ,pg, apiadd  ,sortby , fuzzy )
    console.log('curpage not 1  ', `${srchterm}`);
  } else {
    li.insertAdjacentHTML('beforeend', `<a   href="#"><span uk-pagination-previous></span></a>`);
  }

  let outpgarr = generatePagination(curpg, pages);
  console.log('outpgarr ', outpgarr);
  console.log('q srting in pagation function: ', querys);
  let lis = null;
  for (let i = 0; i < outpgarr.length; i++) {
    lis = document.createElement('li');
    //need to add event listener with 2 parms
    //  lis.innerHTML =  `<a  onclick="getFuzSerch( '${querys}'  , ${outpgarr[i]})"  href="#">${outpgarr[i]}</a>`
    lis.innerHTML = `<a   onclick="getAllStuff2 ( '${srchterm}' , ${outpgarr[i]} ,  '${apiadd}'      )"  href="#">${outpgarr[i]}</a>`;
    ul.appendChild(lis);
    if (outpgarr[i] == '...') {
      lis.classList.add('uk-disabled');
    }
    if (outpgarr[i] == page) {
      lis.classList.add('uk-active');
    }
  }

  console.log('lis: ', lis);

  if (lis !== null) {
    ul.appendChild(lis);

    if (curpg < pages) {
      lis.insertAdjacentHTML(
        'afterend',
        `<li> <a  onclick="getAllStuff2 ( '${srchterm}'  , ${nxtpg} ,  '${apiadd}' )"   href="#"><span uk-pagination-next></span></a>  </li>`
      );
    } else {
      lis.insertAdjacentHTML('afterend', `<li><a   href="#"><span uk-pagination-next>.</span></a></li>`);
    }
  }

  console.log(pg);

  function generatePagination(current, last) {
    const offset = 2;
    const leftOffset = current - offset;
    const rightOffset = current + offset + 1;

    /**
     * Reduces a list into the page numbers desired in the pagination
     * @param {array} accumulator - Growing list of desired page numbers
     * @param {*} _ - Throwaway variable to ignore the current value in iteration
     * @param {*} idx - The index of the current iteration
     * @returns {array} The accumulating list of desired page numbers
     */
    function reduceToDesiredPageNumbers(accumulator, _, idx) {
      const currIdx = idx + 1;

      if (
        // Always include first page
        currIdx === 1 ||
        // Always include last page
        currIdx === last ||
        // Include if index is between the above defined offsets
        (currIdx >= leftOffset && currIdx < rightOffset)
      ) {
        return [...accumulator, currIdx];
      }

      return accumulator;
    }

    /**
     * Transforms a list of desired pages and puts ellipsis in any gaps
     * @param {array} accumulator - The growing list of page numbers with ellipsis included
     * @param {number} currentPage - The current page in iteration
     * @param {number} currIdx - The current index
     * @param {array} src - The source array the function was called on
     */
    function transformToPagesWithEllipsis(accumulator, currentPage, currIdx, src) {
      const prev = src[currIdx - 1];

      if (prev != null && currentPage - prev !== 1) {
        return [...accumulator, '...', currentPage];
      }

      // If page does not meet above requirement, just add it to the list
      return [...accumulator, currentPage];
    }
    const pageNumbers = Array(last)
      .fill()
      .reduce(reduceToDesiredPageNumbers, []);
    const pageNumbersWithEllipsis = pageNumbers.reduce(transformToPagesWithEllipsis, []);
    return pageNumbersWithEllipsis;
  }
}
