/* eslint-disable */


export 
let functTable = {

  DROP: drp,

  SLIDE: sldx  ,

  ADDPLST : addpillstate  ,

  doit: function(clsparm) {
    return function() {
      console.log(`ran  doit  plus ${clsparm}`);
    };

  },

  doitagain: function(clsparm) {

    console.log('i ran here once ', clsparm);

    return function() {
      console.log(`ran  doitagain  plus ${clsparm}`);
    };
  },

  CONEx: function(elmt, e, obj) {
    //takes whatever here for the element and uses that for the functions
    //you can use e =event too :)
    console.log('event ', e.currentTarget);
    console.log('element ', elmt);

    return 'ran control one ok : ' + elmt.dataset.id + ' ' + obj.name;
  },

  CONE: function(elmt, e, obj) {
    function xx() {
      return 'ran control one ok : ' + elmt.dataset.id + ' ' + obj.name;
    }

    return xx;
  },

  DROPTEST: function(elmt, e, obj) {
    //takes whatever here for the element and uses that for the functions
    //you can use e =event too :)

    return 'ran control one ok : ' + elmt.dataset.id;
  }
};
