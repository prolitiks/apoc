/* eslint-disable */
//need to get this in list form save this in the mongo db for international
//save the data   https://developers.google.com/places/web-service/search

let add = {
  candidates: [
    {
      formatted_address: '140 George St, The Rocks NSW 2000, Australia',
      geometry: {
        location: {
          lat: -33.8599358,
          lng: 151.2090295
        },
        viewport: {
          northeast: {
            lat: -33.85821262010728,
            lng: 151.2102470798928
          },
          southwest: {
            lat: -33.86091227989272,
            lng: 151.2075474201073
          }
        }
      },
      name: 'Museum of Contemporary Art Australia',
      opening_hours: {
        open_now: true
      },
      photos: [
        {
          height: 3024,
          html_attributions: [
            '\u003ca href="https://maps.google.com/maps/contrib/109979728852854059507/photos"\u003eEric Tran\u003c/a\u003e'
          ],
          photo_reference: 'CmRaAAAAV1qOhGGKWfJBbHQ',
          width: 4032
        }
      ],
      rating: 4.4
    }
  ],
  status: 'OK'
};

var geojsonFeature = {
  type: 'Feature',
  properties: {
    name: 'Coors Field',
    amenity: 'Baseball Stadium',
    popupContent: 'This is where the Rockies play!'
  },
  geometry: {
    type: 'Point',
    coordinates: [-104.99404, 39.75621]
  }
};
