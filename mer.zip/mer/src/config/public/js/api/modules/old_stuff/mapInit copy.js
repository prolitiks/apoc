
/* eslint-disable */

//import constants

let ceddata={"type":"FeatureCollection","features":[{"geometry":{"coordinates":[[[151.16808253400006,-33.920118342999956],[151.17424019400005,-33.92496630499994],[151.1735937420001,-33.92654059999995],[151.16923440100004,-33.92732816299997],[151.1650990600001,-33.929719028999955],[151.1620689760001,-33.933736988999954],[151.16045626100004,-33.93400899399995],[151.16121900100006,-33.93733899399996],[151.15990299400005,-33.94342900899994],[151.159988988,-33.94480100599998],[151.16532700300002,-33.94737100799995],[151.16803300300012,-33.94977399099997],[151.165221007,-33.95063200299995],[151.16183099600005,-33.953642007999974],[151.1577709920001,-33.95932100899995],[151.15484201300012,-33.96666900499997],[151.15380796800002,-33.96674861099996],[151.13712706600006,-33.96430862699998],[151.13564403500004,-33.96947390099996],[151.12967113900004,-33.97363068499993],[151.12698554200006,-33.97146300299994],[151.12441835100003,-33.96825476999993],[151.11763741700008,-33.96961548199994],[151.11427609600003,-33.96965562699995],[151.11034884200012,-33.96848849899993],[151.1057660470001,-33.96847292199993],[151.100108986,-33.966104033999954],[151.09696367100003,-33.965227169999935],[151.0943842160001,-33.96542660099993],[151.0848779370001,-33.95419931999993],[151.07881466600008,-33.94725578999993],[151.07665671400002,-33.942590440999936],[151.0811222330001,-33.94155401599994],[151.08385436700007,-33.940314737999984],[151.08761299200012,-33.94093800299993],[151.09052919600003,-33.93912305999993],[151.09162175000006,-33.94103274099996],[151.09394767600008,-33.94117174999997],[151.0963810940001,-33.940187123999976],[151.10078292200012,-33.93925947899993],[151.0985575530001,-33.92930723699993],[151.0970801420001,-33.92583619399994],[151.09487820700008,-33.92220645699996],[151.1156051700001,-33.91364534099995],[151.11530641800005,-33.910008758999936],[151.1190542370001,-33.912199732999966],[151.12213199100006,-33.91315991999994],[151.1284219260001,-33.91217090999993],[151.13386440400006,-33.90944904199995],[151.13774125200007,-33.90950348699994],[151.14023099000008,-33.910780227999965],[151.1479411040001,-33.91148763099994],[151.1532439330001,-33.913782814999934],[151.1621960330001,-33.916147114999944],[151.164641898,-33.915715657999954],[151.16579712300006,-33.91779905399994],[151.16808253400006,-33.920118342999956]]],"type":"Polygon"},"properties":{"CED_CODE16":"102","CED_NAME16":"Barton","AREASQKM16":39.6466},"type":"Feature","_id":"5da8230c5e05fd84ee9b727d","tran":[{"M201908CAT01AA01":399545.13,"M201908CAT01AA02":616498.06,"M201908CAT01AA03":589454.03,"M201908CAT01AA04":474550.48,"M201908CAT01AA05":197552.3,"M201908CAT01AA06":74503.43,"M201908CAT01AA07":15504.3,"M201908CAT01AA08":1198.83,"M201908CAT02AA01":105146.6,"M201908CAT02AA02":317594.9,"M201908CAT02AA03":478354.33,"M201908CAT02AA04":461520.56,"M201908CAT02AA05":172513.98,"M201908CAT02AA06":97527.45,"M201908CAT02AA07":25668.72,"M201908CAT02AA08":888.18,"M201908CAT03AA01":1677.77,"M201908CAT03AA02":7740.77,"M201908CAT03AA03":11494.07,"M201908CAT03AA04":1050.11,"M201908CAT04AA01":15337.06,"M201908CAT04AA02":30929.16,"M201908CAT04AA03":34863.05,"M201908CAT04AA04":17086.67,"M201908CAT04AA05":20255.84,"M201908CAT04AA06":3454.57,"M201908CAT04AA07":1260.1,"M201908CAT04AA08":null,"M201908CAT05AA01":41810.05,"M201908CAT05AA02":36298.83,"M201908CAT05AA03":65784.28,"M201908CAT05AA04":43456.71,"M201908CAT05AA05":14113.42,"M201908CAT05AA06":2181.5,"M201908CAT05AA08":null,"M201908CAT06AA01":20241.46,"M201908CAT06AA02":23391.35,"M201908CAT06AA03":22009.05,"M201908CAT06AA04":10220.65,"M201908CAT06AA05":3283.05,"M201908CAT06AA06":1446.88,"M201908CAT07AA01":199248.56,"M201908CAT07AA02":452798.36,"M201908CAT07AA03":578599.35,"M201908CAT07AA04":491461.06,"M201908CAT07AA05":249397.49,"M201908CAT07AA06":93079.75,"M201908CAT07AA07":20729.29,"M201908CAT07AA08":2182.44,"M201908CAT08AA01":1059514.89,"M201908CAT08AA02":1484439.57,"M201908CAT08AA03":1416776.13,"M201908CAT08AA04":1016376.58,"M201908CAT08AA05":362005.57,"M201908CAT08AA06":101456.31,"M201908CAT08AA07":17817,"M201908CAT08AA08":4710.79,"M201908CAT09AA01":12785.55,"M201908CAT09AA02":9622.55,"M201908CAT09AA03":31188.97,"M201908CAT09AA04":11191.57,"M201908CAT09AA05":11341.7,"M201908CAT09AA06":7132.4,"M201908CAT09AA07":880,"M201908CAT09AA08":500,"M201908CAT10AA01":299075.62,"M201908CAT10AA02":683384.64,"M201908CAT10AA03":741638.92,"M201908CAT10AA04":654591.89,"M201908CAT10AA05":360210.27,"M201908CAT10AA06":135681.3,"M201908CAT10AA07":44149.32,"M201908CAT10AA08":7203.98,"M201908CAT11AA01":117903.78,"M201908CAT11AA02":376029.26,"M201908CAT11AA03":525743.05,"M201908CAT11AA04":478133.54,"M201908CAT11AA05":366187.02,"M201908CAT11AA06":220858.97,"M201908CAT11AA07":81938.58,"M201908CAT11AA08":31418.16,"M201908CAT12AA01":13497.8,"M201908CAT12AA02":56867.76,"M201908CAT12AA03":76653.81,"M201908CAT12AA04":78593.54,"M201908CAT12AA05":34639.87,"M201908CAT12AA06":10868.17,"M201908CAT12AA07":11439.1,"M201908CAT12AA08":1816,"M201908CAT13AA01":170004.74,"M201908CAT13AA02":620797.58,"M201908CAT13AA03":779133.23,"M201908CAT13AA04":786094.67,"M201908CAT13AA05":342238.76,"M201908CAT13AA06":170155.91,"M201908CAT13AA07":32448.87,"M201908CAT13AA08":5230.4,"M201908CAT15AA01":171852.62,"M201908CAT15AA02":263500.05,"M201908CAT15AA03":367968.47,"M201908CAT15AA04":306217.96,"M201908CAT15AA05":132845.54,"M201908CAT15AA06":51017.76,"M201908CAT15AA07":7037.89,"M201908CAT15AA08":1137.54,"M201908CAT16AA01":135507.05,"M201908CAT16AA02":298623.2,"M201908CAT16AA03":368256.79,"M201908CAT16AA04":266130.87,"M201908CAT16AA05":157078.74,"M201908CAT17AA01":1668,"M201908CAT17AA02":790,"M201908CAT17AA03":2500,"M201908CAT17AA04":3669,"M201908CAT17AA05":null,"M201908CAT17AA06":null,"M201908CAT18AA01":148999.02,"M201908CAT18AA02":193136.75,"M201908CAT18AA03":219866.5,"M201908CAT18AA04":174306.22,"M201908CAT18AA05":68482.01,"M201908CAT18AA06":22341.83,"M201908CAT18AA07":6174.55,"M201908CAT18AA08":946.5,"M201908CAT19AA01":530194.11,"M201908CAT19AA02":1499258.02,"M201908CAT19AA03":2256080.85,"M201908CAT19AA04":2028242.21,"M201908CAT19AA05":1113036.31,"M201908CAT19AA06":525403.35,"M201908CAT19AA07":168933.99,"M201908CAT19AA08":28419.88,"M201908CAT20AA01":441975.63,"M201908CAT20AA02":760874.6,"M201908CAT20AA03":897383,"M201908CAT20AA04":738937.24,"M201908CAT20AA05":346004.07,"M201908CAT20AA06":113628.01,"M201908CAT20AA07":19488.6,"M201908CAT20AA08":2795.9,"M201908CAT21AA01":70177.48,"M201908CAT21AA02":163463.94,"M201908CAT21AA03":178477.55,"M201908CAT21AA04":214401.13,"M201908CAT21AA05":117559.39,"M201908CAT21AA06":75226.11,"M201908CAT21AA07":6714.37,"M201908CAT21AA08":235,"M201908CAT03AA07":236.8,"M201908CAT06AA07":185.5,"M201908CAT14AA01":1260.85,"M201908CAT14AA02":9021.64,"M201908CAT14AA03":10963.25,"M201908CAT14AA04":24080.38,"M201908CAT14AA05":20280.56,"M201908CAT14AA06":10545.86,"M201908CAT14AA07":5305.19,"M201908CAT14AA08":460.35,"M201908CAT16AA06":75760.01,"M201908CAT16AA07":10084.99,"M201908CAT16AA08":4305.43,"M201908CAT03AA05":90.2,"M201908CAT03AA06":null,"M201908CAT05AA07":95,"M201908CAT06AA08":36,"M201908CAT03AA08":null,"M201908CAT17AA07":1310.12,"M201908CAT17AA08":null,"M201907CAT01AA01":347638.81,"M201907CAT01AA02":602056.64,"M201907CAT01AA03":578268.16,"M201907CAT01AA04":481068.06,"M201907CAT01AA05":228054.5,"M201907CAT01AA06":74775.52,"M201907CAT01AA07":25446.4,"M201907CAT01AA08":2169.32,"M201907CAT02AA01":102275.61,"M201907CAT02AA02":324270.42,"M201907CAT02AA03":388180.45,"M201907CAT02AA04":397575.21,"M201907CAT02AA05":193701.66,"M201907CAT02AA06":79566.32,"M201907CAT02AA07":17850.26,"M201907CAT02AA08":3231.34,"M201907CAT03AA01":1149.21,"M201907CAT03AA02":8285.35,"M201907CAT03AA03":10171.13,"M201907CAT03AA06":59.2,"M201907CAT04AA01":18385.61,"M201907CAT04AA02":35256.12,"M201907CAT04AA03":39632.47,"M201907CAT04AA04":22472.93,"M201907CAT04AA05":15532.9,"M201907CAT04AA06":3138.03,"M201907CAT04AA07":942,"M201907CAT05AA01":30211.73,"M201907CAT05AA02":44129.8,"M201907CAT05AA03":72739.47,"M201907CAT05AA04":37692.18,"M201907CAT05AA05":5217.31,"M201907CAT05AA06":1350.7,"M201907CAT05AA07":30,"M201907CAT06AA01":32602,"M201907CAT06AA02":32435.8,"M201907CAT06AA03":40944.65,"M201907CAT06AA04":16513.95,"M201907CAT06AA05":5631.62,"M201907CAT06AA06":2126.75,"M201907CAT06AA07":387.4,"M201907CAT07AA01":184782.38,"M201907CAT07AA02":426659.26,"M201907CAT07AA03":516302.8,"M201907CAT07AA04":454964.14,"M201907CAT07AA05":218210.07,"M201907CAT07AA06":86284.51,"M201907CAT07AA07":19641.22,"M201907CAT07AA08":1523.84,"M201907CAT08AA01":980622.74,"M201907CAT08AA02":1434476.85,"M201907CAT08AA03":1360373.14,"M201907CAT08AA04":970781.5,"M201907CAT08AA05":359235.47,"M201907CAT08AA06":105768.65,"M201907CAT08AA07":21131.09,"M201907CAT08AA08":4349.5,"M201907CAT09AA01":10240.6,"M201907CAT09AA02":4305.7,"M201907CAT09AA03":30297.28,"M201907CAT09AA04":10385.98,"M201907CAT09AA05":12174.28,"M201907CAT09AA06":4977.29,"M201907CAT09AA07":1844.2,"M201907CAT09AA08":500,"M201907CAT10AA01":264814.35,"M201907CAT10AA02":694501.16,"M201907CAT10AA03":760363.74,"M201907CAT10AA04":660177.59,"M201907CAT10AA05":362898.9,"M201907CAT10AA06":145672.75,"M201907CAT10AA07":41166.44,"M201907CAT10AA08":4597.44,"M201907CAT11AA01":120330.71,"M201907CAT11AA02":400290.25,"M201907CAT11AA03":486926.64,"M201907CAT11AA04":412796.65,"M201907CAT11AA05":347790.97,"M201907CAT11AA06":192575.58,"M201907CAT11AA07":93213.96,"M201907CAT11AA08":23622.26,"M201907CAT12AA01":11980.91,"M201907CAT12AA02":61218.89,"M201907CAT12AA03":66793.61,"M201907CAT12AA04":81419.09,"M201907CAT12AA05":40802.34,"M201907CAT12AA06":18281.01,"M201907CAT12AA07":3454.56,"M201907CAT13AA01":159276.36,"M201907CAT13AA02":520019.04,"M201907CAT13AA03":763815.8,"M201907CAT13AA04":776064.65,"M201907CAT13AA05":396598.01,"M201907CAT13AA06":181235.52,"M201907CAT13AA07":30976.71,"M201907CAT13AA08":3038.86,"M201907CAT15AA01":161980.03,"M201907CAT15AA02":298142.71,"M201907CAT15AA03":340151.63,"M201907CAT15AA04":311787.16,"M201907CAT15AA05":134037.02,"M201907CAT15AA06":50958.19,"M201907CAT15AA07":10174.59,"M201907CAT15AA08":1337.03,"M201907CAT16AA01":132005.44,"M201907CAT16AA02":258616.54,"M201907CAT16AA03":328973.49,"M201907CAT16AA04":244834.84,"M201907CAT16AA05":163734.55,"M201907CAT17AA01":4436.88,"M201907CAT17AA02":1470.6,"M201907CAT17AA03":131,"M201907CAT17AA04":1810,"M201907CAT17AA05":286,"M201907CAT17AA06":null,"M201907CAT18AA01":136833.75,"M201907CAT18AA02":198856.64,"M201907CAT18AA03":209102.61,"M201907CAT18AA04":171163.2,"M201907CAT18AA05":78567.09,"M201907CAT18AA06":28791.98,"M201907CAT18AA07":5442.82,"M201907CAT18AA08":1285.4,"M201907CAT19AA01":521923.47,"M201907CAT19AA02":1521979.99,"M201907CAT19AA03":2092265.75,"M201907CAT19AA04":1943440.81,"M201907CAT19AA05":1118449.85,"M201907CAT19AA06":545638.16,"M201907CAT19AA07":170465.18,"M201907CAT19AA08":32294.3,"M201907CAT20AA01":426667.76,"M201907CAT20AA02":728197.42,"M201907CAT20AA03":847700.46,"M201907CAT20AA04":736510.3,"M201907CAT20AA05":336846.78,"M201907CAT20AA06":106208.61,"M201907CAT20AA07":21725.45,"M201907CAT20AA08":1330.18,"M201907CAT21AA01":90574.11,"M201907CAT21AA02":169861.24,"M201907CAT21AA03":254620.48,"M201907CAT21AA04":220700.3,"M201907CAT21AA05":125576.51,"M201907CAT21AA06":94221.94,"M201907CAT21AA07":16590.65,"M201907CAT03AA04":1909.76,"M201907CAT06AA08":129.5,"M201907CAT14AA01":1963.9,"M201907CAT14AA02":19135.76,"M201907CAT14AA03":20050.56,"M201907CAT14AA04":28114.67,"M201907CAT14AA05":37166.63,"M201907CAT14AA06":32661.31,"M201907CAT14AA07":8371.48,"M201907CAT14AA08":330.87,"M201907CAT16AA06":70389.55,"M201907CAT16AA07":20493.12,"M201907CAT16AA08":1728.9,"M201907CAT21AA08":null,"M201907CAT03AA05":null,"M201907CAT03AA07":null,"M201907CAT04AA08":12,"M201907CAT05AA08":180,"M201907CAT12AA08":1718.38,"M201907CAT17AA07":1040,"M201907CAT17AA08":null,"M201907CAT03AA08":null,"LOCODE_NUM":102,"LOCODE_STR":"102","SC":"1","LOCNAME":"Barton","LOCTYPE":"CED2016"}],"id":"5da8230c5e05fd84ee9b727d"}]};



export function wili () {

  console.log('hi from map')
  
  }


 export const red8 = [
  "#ffffcc",
  "#ffeda0",
  "#fed976",
  "#feb24c",
  "#fd8d3c",
  "#fc4e2a",
  "#e31a1c",
  "#b10026"
];


//C201912CAT11AF11

//need to do multiple loops

/* eslint-disable */

document.querySelector('#MERCAT').addEventListener('click', hov);
document.querySelector('#AGE').addEventListener('click', hov);
document.querySelector('#YM').addEventListener('click', hov);
document.querySelector('#SEX').addEventListener('click', hov);
document.querySelector('#SUMA').addEventListener('click', sumA);
document.querySelector('#TOT').addEventListener('click', fireSum );


  let viewpop=  'M' //merchant or customer
  let dates =[ '201908','201908' ]
  let mers =[ '01','02','03' ]
  let dob =[ '11','12','13','15','16' ]
  let sex =[ 'A' ]

  let YM_A=[]
  let AGE_A = []
  let MERCAT_A = []
  let SEX_A = []


  let YM= [{ name: '201907'  , code : '201907'  , action: addPill}, 
                { name: '201908'    , code : '201908' , action: addPill }  ,

   
];


let MERCAT = [{ name: 'Apparel' , code : '01'  ,     action: addPill}
  , { name: 'Automotive'  , code : '02'   , action: addPill }  
,  { name: 'Child-Care' , code : '03'   , action: addPill}    
 , { name: 'Day-Out-Entertainment'  , code : '04'  , action: addPill }      
 , { name: 'Education'  , code : '05'  , action: addPill }      
 , { name: 'Entertainment'  , code : '06'  , action: addPill }      
 , { name: 'Food-Liquor'  , code : '07'  , action: addPill }      
 , { name: 'Food-Catering'  , code : '08'  , action: addPill }      
 , { name: 'Gambling'  , code : '09'  , action: addPill }      
 , { name: 'General-Retail'  , code : '10'  , action: addPill }      
 , { name: 'Healthcare'  , code : '11'  , action: addPill }      
 , { name: 'Home-Maintenance'  , code : '12'  , action: addPill }      
 , { name: 'Household-Goods'  , code : '13'  , action: addPill }      
 , { name: 'Insurance'  , code : '14'  , action: addPill }      
 , { name: 'Leisure'  , code : '15'  , action: addPill }      
 , { name: 'Non-food-Major'  , code : '16'  , action: addPill }      
 , { name: 'Property-Rentals'  , code : '17'  , action: addPill }      
 , { name: 'Retail-Services'  , code : '18'  , action: addPill }     
 , { name: 'Supermarkets'  , code : '19'  , action: addPill }     
 , { name: 'Transport'  , code : '20'  , action: addPill }     
 , { name: 'Travel-Accommodation'  , code : '21'  , action: addPill }     


];  

  let AGE = [
     { name: '18-24'  , code : '01'  , action: addPill}
   , { name: '25-34'   , code : '02'  , action: addPill }  
   , { name: '35-44'   , code : '03'  , action: addPill}    
   , { name: '45-54'   , code : '04' , action: addPill }      
   , { name: '55-54'   , code : '05' , action: addPill }      
   , { name: '65-74'   , code : '06' , action: addPill }      
   , { name: '75-84'   , code : '07' , action: addPill }      
   , { name: '85 + '   , code : '08' , action: addPill }      

];



     let SEX = [{ name: 'ALL' , code : 'A'  ,    action: addPill}     
  
   
];

   function addPill(e) {

     const actiontype = e.target.innerHTML;  //send the class name to the close button
     // name of the object 

     let targObj =eval(e.target.classList[0])
     let tartype =e.target.classList[0]
     let tartcode =e.target.classList[1]
    console.log( 'tartype :', tartype    )
    console.log( 'tarcode :', tartcode    )
   
     const node = document.createElement('SPAN');
     const node2 = document.createElement('SPAN');
     const textnode2 = document.createTextNode('x');
     const textnode = document.createTextNode(actiontype);
     node.appendChild(textnode);
     node.appendChild(node2);
     node2.appendChild(textnode2);
     node2.classList.add('close');
     node.classList.add('closea');
     node.classList.add(tartype ,tartcode );
     document.getElementById('selmulti').appendChild(node);


       //  add to the array version of the select object  
       // select the value of the array  
       let arrtype = eval(`${tartype}_A`)
      // arrtype.push(actiontype)
        console.log ('arrtype :' ,arrtype   )
    


     //take out the selected from the dropdown for next time  document.querySelector("#MERCAT-DROP")
     for (let m = 0; m < targObj.length; m++) {
       if (targObj[m].name === actiontype) {

        console.log( 'targObj[m].name  ', targObj[m]   )
        arrtype.push(targObj[m])
        targObj.splice(m, 1);

         e.target.parentNode.remove();
        
         console.log( ' arrtype ',  arrtype   )
      
       }
     }
    
     node.addEventListener('click', function() {
       let ps = this.classList[2];
       let name=  this.firstChild.nodeValue;
       console.log( 'ps ', this.classList   )
       this.remove();
       targObj.splice(0, 0, { name: name,   code: ps , action: addPill });
       //need to remove here get index first  
       let removeIndex =  arrtype.map(function(item) { return item.name; }).indexOf(actiontype);
       arrtype.splice(removeIndex, 1);

       console.log( 'targObj remove ', targObj   )
       console.log( 'arrtype remove ', arrtype  )

       let targ = e.target.classList[0]
       let dropob = targObj
       let filldrop = document.getElementById(`${targ}-DROP`);


        console.log( 'targ ', targ  )

       //remove siblinings first
       while (filldrop.hasChildNodes()) {
         filldrop.removeChild(filldrop.firstChild);
       }
       for (var k = 0; k < dropob.length; k++) {
         filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ="${e.target.classList[0]} ${ps}"  href="#" >${dropob[k].name}</a></li>`);
         filldrop.addEventListener('click', dropob[k].action); 
       }   
     });
   }


   function hov(e) {
     let targ = e.target.id;
     const drpdwnIn = `</span> <div  uk-dropdown ="pos: middle-top"> <ul id ="${targ}-DROP" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
     let dropob = eval(targ);
     this.insertAdjacentHTML('afterEnd', drpdwnIn);
     let filldrop = document.getElementById(`${targ}-DROP`);
     for (var k = 0; k < dropob.length; k++) {
       filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ="${e.target.id} ${dropob[k].code}"  href="#" >${dropob[k].name}</a></li>`);
       filldrop.addEventListener('click', dropob[k].action); //the action will be to add the pill and reduce the dropdown list
     }
     console.log('fill ', filldrop);
   }


// this will part of a call to axios  

let buildQuery = function (data) {
  if (typeof (data) === 'string') return data;
  let query = [];
  for (let key in data) {
    if (data.hasOwnProperty(key)) {
      query.push(`${encodeURIComponent(key)  }=${  encodeURIComponent(data[key])}`);
    }
  }
  return query.join('&');
};
//http://localhost:3009/v1/abr?limit=100&skip=50&TRADNF=MAJESTIC%20NURSERIES
//need to make generic 

const getDataCed = async ( ) => {
 
  const response = await axios({
    url: `/v1/polygonced/ced`,
    method: 'get',
    onDownloadProgress: function(progressEvent) {}
  });
   await response.data;
  // console.log(data)
  return response.data;
};




/**************************************** */

function selectPop(viewpop = 'M', dates, mers , sex , dob) {
  
  let final = [];
  const CAT = 'CAT';
  const A = 'A';

  //set defaults
  if (dates.length < 1)    {  dates=  [ '201907','201908' ]} 
  if (mers.length < 1)  {  mers=[ '01','02','03','05','06','07','08','09','10','11','12','13','15','16','17','18','19','20','21' ]} 
  if (dob.length < 1)  { dob =[ '01','02','03','05','06','07','08']} 
  if (sex.length < 1)  {  sex=  [ 'A'] } 

  for (let i = 0; i < dates.length; i++) {
    let dt = `${viewpop}${dates[i]}`;
    for (let j = 0; j < mers.length; j++) {
      let mdt = `${dt}${CAT}${mers[j]}`;
      for (let k = 0; k < sex.length; k++) {
        let sx = `${mdt}${A}${sex[k]}`;
        for (let m = 0; m < dob.length; m++) {
          let db = `${sx}${dob[m]}`;
          final.push(db);
        }
      }
    }
  }
  return final;
}

// takes an array of objects spits out codes
function getSelCodes  ( arrObj )   {
   let scrape =[]
  arrObj.forEach(el => {
    scrape.push(el.code)
  });

  return scrape
}

//picks selected vales and aggreagtes them

function pickReduce (object, [...userSelect ] ) {
  //selected object  
  const kval= userSelect.reduce((o, e) => {return o[e] = object[e], o}, {});
   //get values from selected key value and create array
  
   const jval= Object.values(kval) 
   const jv= jval.filter( Number );
   let sum = jv.reduce(function (accumulator, currentValue) {
   
    return accumulator + currentValue;
    
  }, 0);
  
  return sum
}
 


let {  features }  =ceddata
 async function sumA  ()  {
let dates=await getSelCodes(YM_A)
let mers=await getSelCodes(MERCAT_A )
let sex=await getSelCodes(SEX_A )
let dob =await getSelCodes(AGE_A  )

let ALLOWED_FIELDS = await selectPop ('M',dates, mers,sex ,dob)
let final = await pickReduce (features[0].tran[0], ALLOWED_FIELDS )
await console.log( 'select pop'  , ALLOWED_FIELDS)
await console.log( 'final '  , final )

}


async function sumB  (  )  {
  let dates=await getSelCodes(YM_A)
  let mers=await getSelCodes(MERCAT_A )
  let sex=await getSelCodes(SEX_A )
  let dob =await getSelCodes(AGE_A  )
  
  let ALLOWED_FIELDS = await selectPop ('M',dates, mers,sex ,dob)
  let final = await pickReduce (features[0].tran[0], ALLOWED_FIELDS )
  await console.log( 'select pop'  , ALLOWED_FIELDS)
  await console.log( 'final '  , final )
  
  }
  

// need this in a loop  



//control tracking
 
var mapboxAccessToken =
"pk.eyJ1IjoibW9nYXMiLCJhIjoiY2ppaWsxeXV3MWtuZzNxcG4zNTVmN3RteSJ9.2OsUOp70d2VPpc-51-fmcg";

var grayscale = L.tileLayer(
"https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=" +
  mapboxAccessToken,
{
  id: "mapbox.light",
  attribution: "MAPS INC."
}
);

var map = L.map("mapid", {
center: [-33.53434354312, 147.061051828579],
zoom: 6,
layers: [grayscale]
});







async function fireSum ( )
 {
let retdat = await   getDataCed (  ) 
await console.log(retdat)
let geoj = await L.geoJson(retdat, {
  
}).addTo(map);


}




