/* eslint-disable */
export const logsub = async e => {
  //delete existing cookies
  // console.log('logsub works.....'  , e  )   document.querySelector("#l1")

  //delete existing cookies
  //remove exsiting html
  const warntext = document.querySelector(`#l1`);
  if (warntext !== null) {
    warntext.remove();
  }

  Cookies.remove('tokendata');
  let transport = axios.create({
    withCredentials: true
  });

  await transport.interceptors.response.use(
    function(response) {
      console.log('intercepted.....');
      return response;
    },
    function(error) {
      const errorResponse = error.response;
      console.log('err.....', errorResponse.status);
      console.log('errmessage.....', errorResponse.data.message);
      console.log('errobj.....', errorResponse);
      let badpass = errorResponse.data.message;

      //put message in the login screen here
      document
        .querySelector(`#passin`)
        .insertAdjacentHTML('afterEnd', `<div id='l1' class ='badattemp'>${badpass}</div>`);
      return Promise.reject(error);
    }
  );

  //get imput fields from login

  let userin = document.getElementById('userin').value;
  let passin = document.getElementById('passin').value;
  console.log('userin... ', userin);
  console.log('passin... ', passin);
  const lgin = {
    email: userin, //create a form for the user and password
    password: passin
  };
  console.log('lgin  ... ', lgin);

  const da = { email: 'dave@prolitiks.com', password: 'thewinner' };

  try {
    const response = await transport({
      url: `v1/auth/login`,
      method: 'post',
      data: da,
      onDownloadProgress: function(progressEvent) {}
    });
    await response.data;
    console.log('axios data ', response.data);
    await Cookies.set('tokendata', response.data);

    //change the dom here if sucess

    //remove dropdown
    document.querySelector(`#DROPLOG`).remove();
    //change lognin button to signout + actually signout
    document.querySelector(`#LG`).textContent = 'SIGNOFF';
    //function to signoff and reset login
  } catch (e) {
    console.log(e.message);
  }
};



let T6 = async function() {
  //this designates the user
  //const da = {  email:'dave@prolitiks.com',  password: 'thewinner'}

  let { data } = await Cookies.getJSON('tokendata');
  let user = data.user['id'];
  //get token from cookie
  console.log('data ', data.token['accessToken']);
  const config = {
    method: 'get',
    url: `v1/mer`
  };

  await axios.interceptors.request.use(
    function(config) {
      if (data != null) {
        config.headers.Authorization = 'bearer ' + data.token['accessToken'];
      }
      return config;
    },
    function(err) {
      return Promise.reject(err);
    }
  );

  //need to do something here

  await axios.interceptors.response.use(
    function(response) {
      console.log('intercepted.....');
      //   window.location.replace("http://localhost:3009/v1/mer");
      return response;
    },
    function(error) {
      const errorResponse = error.response;
      console.log('err.....', errorResponse.status);
      return Promise.reject(error);
    }
  );

  let res = await axios(config);

  console.log('user', user);
  console.log('data token ', data);
  console.log('res  ', res);
};