/* eslint-disable */

//import constants



export let ProjObj = {

  ProjectName : ''
  

}


export let ConfigObj = {
  SELDATA: { RAR_DATA: [] },

  CHFIG: {},

  DTR: {
    CHRNAME: [
      { key: '20.00', val: 'LINE' },
      { key: '30.00', val: 'BAR' },
      { key: '40.00', val: 'PIE' },
      { key: '50.00', val: 'MAP' }
    ],

    CHRSEL: [],

    CHRSELNAME: [],

    SELNAME: [],

    DTSEL: [],

    DTARR: [
      { YMC: 1, YM: '201601' },
      { YMC: 2, YM: '201602' },
      { YMC: 3, YM: '201603' },
      { YMC: 4, YM: '201604' },
      { YMC: 5, YM: '201605' },
      { YMC: 6, YM: '201606' },
      { YMC: 7, YM: '201607' },
      { YMC: 8, YM: '201608' },
      { YMC: 9, YM: '201609' },
      { YMC: 10, YM: '201610' },
      { YMC: 11, YM: '201611' },
      { YMC: 12, YM: '201612' },
      { YMC: 13, YM: '201701' },
      { YMC: 14, YM: '201702' },
      { YMC: 15, YM: '201703' },
      { YMC: 16, YM: '201704' },
      { YMC: 17, YM: '201705' },
      { YMC: 18, YM: '201706' },
      { YMC: 19, YM: '201707' },
      { YMC: 20, YM: '201708' },
      { YMC: 21, YM: '201709' },
      { YMC: 22, YM: '201710' },
      { YMC: 23, YM: '201711' },
      { YMC: 24, YM: '201712' },
      { YMC: 25, YM: '201801' },
      { YMC: 26, YM: '201802' },
      { YMC: 27, YM: '201803' },
      { YMC: 28, YM: '201804' },
      { YMC: 29, YM: '201805' },
      { YMC: 30, YM: '201806' },
      { YMC: 31, YM: '201807' },
      { YMC: 32, YM: '201808' },
      { YMC: 33, YM: '201809' },
      { YMC: 34, YM: '201810' },
      { YMC: 35, YM: '201811' },
      { YMC: 36, YM: '201812' },
      { YMC: 37, YM: '201901' },
      { YMC: 38, YM: '201902' },
      { YMC: 39, YM: '201903' },
      { YMC: 40, YM: '201904' },
      { YMC: 41, YM: '201905' },
      { YMC: 42, YM: '201906' },
      { YMC: 43, YM: '201907' },
      { YMC: 44, YM: '201908' },
      { YMC: 45, YM: '201909' },
      { YMC: 46, YM: '201910' },
      { YMC: 47, YM: '201911' },
      { YMC: 48, YM: '201912' },
      { YMC: 49, YM: '202001' },
      { YMC: 50, YM: '202002' },
      { YMC: 51, YM: '202003' },
      { YMC: 52, YM: '202004' },
      { YMC: 53, YM: '202005' },
      { YMC: 54, YM: '202006' },
      { YMC: 55, YM: '202007' },
      { YMC: 56, YM: '202008' },
      { YMC: 57, YM: '202009' },
      { YMC: 58, YM: '202010' },
      { YMC: 59, YM: '202011' },
      { YMC: 60, YM: '202012' }
    ]
  },

  DRPOBC: {
    SEEDR: [
      {
        name: 'DATA-SELECTION',
        code: '1',
        ctype: 'DTYPE',
        prefix: 'D',
        drpdwnSelected: [],
        drpdwn: [     
        ]
      },

      {
        name: 'LINE-SELECTION',
        code: '2',
        ctype: 'LTYPE',
        prefix: 'L',
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Thin', code: '0' },
          { name: 'Meduim', code: '1' },
          { name: 'Thick', code: '2' }
        ]
      }
    ]
  },
  
  DRPOB: {
    SEEDR: [
      {
        name: 'COMPLAINT-TYPE',
        code: '2',
        ctype: 'CMTYPE',
        prefix: 'T',
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Access', code: '01' },
          { name: 'Advisor-Issues', code: '02' },
          { name: 'Business-Decision', code: '03' },
          { name: 'Comms-Information-Advice', code: '04' },
          { name: 'Credit-Decision', code: '05' },
          { name: 'Introducer', code: '06' },
          { name: 'Investment-Issues', code: '07' },
          { name: 'Letter-of-Notification', code: '08' },
          { name: 'Other-Bank-ATM', code: '09' },
          { name: 'Process', code: '10' },
          { name: 'Product-Features', code: '11' },
          { name: 'Rates-Fees-Charges', code: '12' },
          { name: 'Security', code: '13' },
          { name: 'Service-Failure', code: '14' },
          { name: 'Service-Quality', code: '15' },
          { name: 'St-George-Bank-SA-ATM', code: '16' },
          { name: 'Westpac-ATM	', code: '17' }
        ]
      },

      {
        name: 'RESOLVE-TIME',
        code: '1',
        ctype: 'CMRESTIME',
        prefix: 'CR',
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Immediately', code: '0' },
          { name: 'Within-7-days', code: '1' },
          { name: 'More-than-7-days', code: '2' },
          { name: 'Unknown', code: '3' }
        ]
      },

      {
        name: 'CUSTOMER-TENURE',
        code: '3',
        ctype: 'CMRELYEARS',
        prefix: 'RL',
        drpdwnSelected: [],
        drpdwn: [
          { name: 'Less-than-1-year', code: '1' },
          { name: '1-3-years', code: '2' },
          { name: '3-5-years', code: '3' },
          { name: '5-10-years', code: '4' },
          { name: '10-20-years', code: '5' },
          { name: 'More-than-20-years', code: '6' },
          { name: 'Unknown', code: '7' }
        ]
      }
    ]
  }
};



//add events to the pills
export function addPill(e) {}

//this is part of the save function for state
export function pushObjcc(ob, key, value, id) {
  const idx = id - 100;
  ob.filter(function (obj) {
    if (obj[key].includes(value)) {
      const { name, drpdwn, drpdwnSelected, ctype } = obj;
      let dp = document.querySelector(`#${value}-B-${id}`).childNodes;
      console.log('dp  ', dp);

      for (let i = 1; i < dp.length; i++) {
        let pilln = dp[i].textContent; //need to get rid of x at end
        let pillname = pilln.substring(0, pilln.length - 1);
        let pillgroup = dp[i].classList[1]; //this is the name of the group
        let pillcode = dp[i].classList[2]; //this is the name of the group
       drpdwnSelected[idx].push({ name: pillname, code: pillcode });
        // drpdwnSelected.push({ name: pillname, code: pillcode });
      }
    }
  });
}



//takes an object as input   createSeedsDrop(SEEDR, 'ctype', SEEDR[j].ctype, `${id}`, `#S`);
//filter the object to get one of the list by key 'ctype'
// sel -select - the base parent where this is attached ,
//id is the identifer counter for this selector box i.e S1, S2
export function createSeedsDrop(ob, key, value, id, sel) {
  const startn = document.querySelector(`${sel}${id}`);  
  //get the created selector by id  'e.g.' S1 already created box grid - <div id='S${id}' class="uk-lbcont Sel"> 
  //from the function let xnewsel = function(id  ,  obj ,  sel ){ }        
  ob.filter(function (obj) {
    if (obj[key].includes(value)) {
//can be multiples but select root obj with key ctype
// obj= {
//   name: 'RESOLVE-TIME',
//   code: '1',
//   ctype: 'CMRESTIME',
//   prefix: 'CR',
//   drpdwnSelected: [],
//   drpdwn: [
//     { name: 'Immediately', code: '0' },
//     { name: 'Within-7-days', code: '1' },
//     { name: 'More-than-7-days', code: '2' },
//     { name: 'Unknown', code: '3' }
//   ]
// }
      const { name, drpdwn, ctype, code } = obj;
      startn.insertAdjacentHTML(
        'beforeEnd',
        `<span    uk-icon="icon: chevron-down ; ratio: 0.6"  id='${ctype}-${id}' class="${ctype} ${code} ${id} uk-label"> ${name}  </span>
       <span class = "flex-container"  id ="${ctype}-B-${id}"> </span> `
      );
      const drpdwnIn = `<div  uk-dropdown="mode: click" > <ul id ="${ctype}-DROP-${id}" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
      document.querySelector(`#${ctype}-${id}`).insertAdjacentHTML('afterEnd', drpdwnIn);
      let filldrop = document.getElementById(`${ctype}-DROP-${id}`);
      for (let i = 0; i < drpdwn.length; i++) {
        filldrop.insertAdjacentHTML(
          'beforeEnd',
          `<li><a class ="${ctype} ${drpdwn[i].code} ${id}"  href="#" >${drpdwn[i].name}</a></li>`
        );
        filldrop.addEventListener('click', addPillz); //this adds the old pill
      }
    }
  });
}

export function addPillSearch (pillgroup, pillname, pillcode, id) {
  const pillgp = pillgroup;
  const pilln = pillname;
  const pillc = pillcode;
  const node = document.createElement('SPAN');
  const node2 = node.cloneNode(true);
  const clx = document.createTextNode('x');
  const textnode = document.createTextNode(pilln);
  node.appendChild(textnode);
  node.appendChild(node2);
  node2.appendChild(clx);
  node2.classList.add('close');
  node.classList.add('closea');
  node.classList.add(pillgp, pillc);
  const boxel = document.getElementById(`${pillgp}-B-${id}`);
  boxel.appendChild(node);

  //optional remove from the dropdown list dom after adding
  let ro = document.querySelectorAll(`#${pillgp}-DROP-${id} > li > a.${pillgp}`);
  for (let i = 0; i < ro.length; i++) {
    if (ro[i].className === `${pillgp} ${pillc} ${id}`) {
      ro[i].parentNode.remove(); //remove from DOM
    }
  }

  // node.addEventListener('click', function () {
  //   this.remove();
  //   let filldrop = document.getElementById(`${pillgroup}-DROP-${id}`);

  //   filldrop.insertAdjacentHTML(
  //     'beforeEnd',
  //     `<li><a class ="${pillgroup} ${pillcode} ${id}"  href="#" >${pillname}</a></li>`
  //   );
  // });
}

//this is for the adding of the pill after section from dropdown
export function addPillClick(e) {
  const pillgroup = e.target.classList[0];
  const pillname = e.target.innerHTML;
  const pillcode = e.target.classList[1];
  const id = e.target.classList[2];
  console.log('add pill z id ', id);
  addPillSearch(pillgroup, pillname, pillcode, id);
}



export function addPilly(pillgroup, pillname, pillcode, id) {
  const pillgp = pillgroup;
  const pilln = pillname;
  const pillc = pillcode;
  const node = document.createElement('SPAN');
  const node2 = node.cloneNode(true);
  const clx = document.createTextNode('x');
  const textnode = document.createTextNode(pilln);
  node.appendChild(textnode);
  node.appendChild(node2);
  node2.appendChild(clx);
  node2.classList.add('close');
  node.classList.add('closea');
  node.classList.add(pillgp, pillc);
  const boxel = document.getElementById(`${pillgp}-B-${id}`);
  boxel.appendChild(node);

  let ro = document.querySelectorAll(`#${pillgp}-DROP-${id} > li > a.${pillgp}`);
  for (let i = 0; i < ro.length; i++) {
    if (ro[i].className === `${pillgp} ${pillc} ${id}`) {
      ro[i].parentNode.remove(); //remove from DOM
    }
  }

  node.addEventListener('click', function () {
    this.remove();
    let filldrop = document.getElementById(`${pillgroup}-DROP-${id}`);

    filldrop.insertAdjacentHTML(
      'beforeEnd',
      `<li><a class ="${pillgroup} ${pillcode} ${id}"  href="#" >${pillname}</a></li>`
    );
  });
}

//adds the pill from the selection from dropdown
export function addPillz(e) {
  const pillgroup = e.target.classList[0];
  const pillname = e.target.innerHTML;
  const pillcode = e.target.classList[1];
  const id = e.target.classList[2];
  console.log('add pill z id ', id);
  addPilly(pillgroup, pillname, pillcode, id);
}



//need to add time parm here plus multi push

//also need to store the dates



// this is for the chart generation

// // takes an array of objects spits out codes e.g. let wee=getSelCodesObj (CMTYPE , 'code')

//picks selected vales and aggreagtes them

export function pickReduce(object, [...userSelect]) {
  //selected object
  const kval = userSelect.reduce((o, e) => {
    return (o[e] = object[e]), o;
  }, {});
  //get values from selected key value and create array
  const jval = Object.values(kval);
  const jv = jval.filter(Number);
  let sum = jv.reduce(function (accumulator, currentValue) {
    return accumulator + currentValue;
  }, 0);

  return sum;
}

export const getDataComp = async (frmdate, tdate) => {
  const response = await axios({
    url: `/v1/complaint?limit=50&sort=CYM&YM>=${frmdate}&YM<=${tdate}`,
    method: 'get',
    onDownloadProgress: function (progressEvent) {}
  });
  await response.data;
  console.log('axios data ', response.data);
  return response.data;
};

//need to add the HC  get the substring of the month year
export async function HC(arr, xcat) {
  await Highcharts.chart('chartcontainer', {
    chart: {
      type: 'line',
      styledMode: true
    },

    legend: {
      enabled: true
    },
    title: {
      text: 'Monthly Stuff'
    },

    tooltip: {
      pointFormat: 'Am: {point.y:.2f}'
    },
    xAxis: {
      categories: xcat,
      //   ,
      //   labels: {
      //    formatter: function () {

      //        console.log  (  this.value )
      //  }
      //  }
      tickInterval: 2
    },
    series: [
      {
        name: 'mogas',
        data: arr
      }
    ]
  });

  console.log(arr);
}

//https://stackoverflow.com/questions/8936610/how-can-i-create-every-combination-possible-for-the-contents-of-two-arrays

//combine arrays

export function combineArrays(array_of_arrays) {
  if (!array_of_arrays) {
    return [];
  }
  if (!Array.isArray(array_of_arrays)) {
    return [];
  }
  if (array_of_arrays.length == 0) {
    return [];
  }
  for (let i = 0; i < array_of_arrays.length; i++) {
    if (!Array.isArray(array_of_arrays[i]) || array_of_arrays[i].length == 0) {
      return [];
    }
  }
  let odometer = new Array(array_of_arrays.length);
  odometer.fill(0);
  let output = [];
  let newCombination = formCombination(odometer, array_of_arrays);
  output.push(newCombination);
  while (odometer_increment(odometer, array_of_arrays)) {
    newCombination = formCombination(odometer, array_of_arrays);
    output.push(newCombination);
  }
  return output;
}
function formCombination(odometer, array_of_arrays) {
  return odometer.reduce(function (accumulator, odometer_value, odometer_index) {
    return '' + accumulator + array_of_arrays[odometer_index][odometer_value];
  }, '');
}
function odometer_increment(odometer, array_of_arrays) {
  for (let i_odometer_digit = odometer.length - 1; i_odometer_digit >= 0; i_odometer_digit--) {
    let maxee = array_of_arrays[i_odometer_digit].length - 1;
    if (odometer[i_odometer_digit] + 1 <= maxee) {
      odometer[i_odometer_digit]++;
      return true;
    } else {
      if (i_odometer_digit - 1 < 0) {
        return false;
      } else {
        odometer[i_odometer_digit] = 0;
        continue;
      }
    }
  }
}

export function getDropObsListCode(ob, key, value, idx) {
  let drpCode = [];
  ob.filter(function (obj) {
    if (obj[key].includes(value)) {
      const { name, drpdwn, ctype, code, prefix, drpdwnSelected } = obj;
      for (let i = 0; i < drpdwnSelected[idx].length; i++) {
        drpCode.push(prefix + drpdwnSelected[idx][i].code);
      }
    }
  });
  return drpCode;
}

export function getDropObsListCodeX(ob, key, value, idx) {
  let drpCode = [];
  ob.filter(function (obj) {
    if (obj[key].includes(value)) {
      const { name, drpdwn, ctype, code, prefix, drpdwnSelected } = obj;

      if (  drpdwnSelected &&  drpdwnSelected[idx].length > 0  ) {
        for (let i = 0; i < drpdwnSelected[idx].length; i++) {
          drpCode.push(prefix + drpdwnSelected[idx][i].code);
        }
      } else {
        for (let j = 0; j < drpdwn.length; j++) {
          drpCode.push(prefix + drpdwn[j].code);
        }
      }
    }
  });
  return drpCode;
}

export function seeddropX(SEEDR, idx) {
  let grparr = [];
  for (let j = 0; j < SEEDR.length; j++) {
    let ga = getDropObsListCodeX(SEEDR, 'ctype', SEEDR[j].ctype, idx);
    grparr.push(ga);
  }
  return grparr;
}

// let xs =seeddrop(DRPOB.SEEDR)

// let ssxx=combineArrays(xs )



let crSrchterm;
let crPg;
let crApiadd;
let crSortby;

//http://localhost:3009/v1/abr?limit=100&skip=50&TRADNF=MAJESTIC%20NURSERIES
//need to make generic 



const getDataAc = async (srchterm = srchterm, pg = 1, apiadd, sortby = `&sort=MerText:desc`) => {
  console.log(`/v1/${apiadd}?${srchterm}&page=${pg}${sortby}`);

  crSrchterm = srchterm;
  crPg = pg;
  crApiadd = apiadd;
  crSortby = sortby;

  const response = await axios({
    url: `/v1/${apiadd}?${srchterm}&page=${pg}${sortby}`,
    method: 'get',
    onDownloadProgress: function(progressEvent) {}
  });
  let { data, meta } = await response.data;
  let { perPage, limit, sort, totalCount, pageCount, count, page } = meta;
  let page_ = page.toString();
  await console.log('pagedata: ', perPage, limit, sort, totalCount, pageCount, count, page_);


  return data;
};






