
/* eslint-disable */
/*
thins to do 
1. info window fix
2. create play for group selection
3. create window of discritions/ instructions
4. update year so it is not white
5. date range for days invalif=d goes to 2015 !!!


*/

const red8 = [
  "#ffffcc",
  "#ffeda0",
  "#fed976",
  "#feb24c",
  "#fd8d3c",
  "#fc4e2a",
  "#e31a1c",
  "#b10026"
];
const dark8 = [
  "#ffffff",
  "#f0f0f0",
  "#d9d9d9",
  "#bdbdbd",
  "#969696",
  "#737373",
  "#525252",
  "#252525"
];


let labelvals = [
  {
    key: "TMR",
    value: "MERCH LOCATION",
    dtype: "Amount $ "
  },
  {
    key: "TCU",
    value: "CUST LOCATION",
    dtype: "Amount $ "
  }
];

let yearlabel = [
  {
    key: "Y1",
    value: "DEC 2016"
  },
  {
    key: "Y2",
    value: "DEC 2017"
  },
  {
    key: "Y3",
    value: "DEC 2018"
  }
];

let mercatlabel = [
  {
    key: "M1D",
    value: "RETAIL",
    dtype: "Amount $ "
  },
  {
    key: "M2D",
    value: "FOOD / DRINK /ENTERTAINMENT",
    dtype: "Amount $ "
  },
  {
    key: "M3D",
    value: "SUPERMARKET",
    dtype: "Amount $ "
  },
  {
    key: "M4D",
    value: "OTHERS",
    dtype: "Amount $ "
  },
  {
    key: "M5D",
    value: "ALL CATEGORIES",
    dtype: "Amount $ "
  }
];

let testob = [
  {
    key: "G1",
    value: {
      GRLOC: ["Adelaide"],
      GRLOCODE: ["401011001"],
      GSTARTD: 20789,
      GENDD: 20794,
      GYEAR: "Y1",
      GMEAS: "TMRM1D",
      GAMT: 15486829
    }
  },
  {
    key: "G2",
    value: {
      GRLOC: [
        "Richmond (SA)",
        "Hindmarsh - Brompton",
        "North Adelaide",
        "Walkerville",
        "St Peters - Marden",
        "Burnside - Wattle Park"
      ],
      GRLOCODE: [
        "404031108",
        "404011093",
        "401011002",
        "401061022",
        "401051019",
        "401031011"
      ],
      GSTARTD: 20789,
      GENDD: 20794,
      GYEAR: "Y1",
      GMEAS: "TMRM1D",
      GAMT: 7762682
    }
  }
];

let rf;

//control tracking
let addmapclr = false;
let creategrpbtn = false;
let creategrp = 0;
let savegrp = 0;
let createchartf = 0;
let sclock = 0;
let pee2;

let syear = -365;

//defaults
let bigval = [21154, 21159]; // date ranges in sas for
let Bdte = 21154;
let Bdtetwo = 21159;
let Bproptype = "TMR";
let Bmertype = "M1D";
let indy = 0;
let indyr = "Y1";
let BSelnice = "TOTAL SPEND";
let Bdtype = "Amount $ ";
const LeafBR =
  "#mapid  div.leaflet-control-container  div.leaflet-bottom.leaflet-right div.info.legend.leaflet-control";
const LeafBL =
  "#mapid  div.leaflet-control-container  div.leaflet-bottom.leaflet-left div.info.groupchart.leaflet-control";
const LeafT =
  "#mapid  div.leaflet-control-container  div.leaflet-bottom.leaflet-right div.info.legend.leaflet-control";

var gran = [];
var grpcomp = [];
let groupob = new Object();
let groupnames = new Object();
let groupnamesSet = new Object();
var groupnameSetarr = [];
var groupcount = 0;
var resetgroup = false;
var ftype;
var fillclr;
var Colr;
var selbool = false;
let pee = [];
let yrin;
var mSel;
var face = [];
var faceloc = [];
var GRPSEL = [];
var dol3;
var scdef = [0, 7500000];
var GRPSELBOOL = false;
var msela;
var ww;
var y = 0;
var mselb;
var mselc;
//initial array of group  selection
let fe = [];
var z = 0;
var mapboxAccessToken =
  "pk.eyJ1IjoibW9nYXMiLCJhIjoiY2ppaWsxeXV3MWtuZzNxcG4zNTVmN3RteSJ9.2OsUOp70d2VPpc-51-fmcg";
let dte;
let dtetwo;
var grayscale = L.tileLayer(
  "https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=" +
    mapboxAccessToken,
  {
    id: "mapbox.light",
    attribution: "MAPS INC."
  }
);

var map = L.map("mapid", {
  center: [-33.53434354312, 147.061051828579],
  zoom: 6,
  layers: [grayscale]
});

let maptbutton = document.getElementById("MB1");
let chartbutton = document.getElementById("GRCHART");
chartbutton.style.display = "none";
let savegrpbutton = document.getElementById("GRSAV");
savegrpbutton.style.display = "none";
let creategrpbutton = document.getElementById("GRPA");

const actionMap20 = document.getElementById("GRPA");
actionMap20.addEventListener("click", grselbutton);
const actionMap21 = document.getElementById("GRSAV");
actionMap21.addEventListener("click", savegroup);

const actionMap1 = document.getElementById("MB1");
actionMap1.addEventListener("click", onMapClick);
const actionMap10 = document.getElementById("MBRS");
actionMap10.addEventListener("click", example1);
const actionMap100 = document.getElementById("MBRS2");
actionMap100.addEventListener("click", example2);
const lock = document.getElementById("SCL");
lock.addEventListener("click", lockscale);
const reslock = document.getElementById("RSCL");
reslock.addEventListener("click", resetscale);




function dtSAStoJS(dtSAS, dtType = "DATE") {
  if (dtSAS === null) {
    return null;
  } else if (dtType === "DATE") {
    return new Date(-315619200000 + dtSAS * 86400000);
  } else if (dtType === "DATETIME") {
    return new Date(-315619200000 + dtSAS * 1000);
  } else {
    return null;
  }
}

let scalefind = function(
  inarr,
  xvar,
  initialValue = 0,
  cumlate = 0,
  min = 0,
  max = 0,
  capita = false
) {
  let wrange = [];
  let mxmn = [];
  for (let i = min; i <= max; i++) {
    wrange.push(xvar + i);
  }
  for (let sel of wrange) {
    inarr.reduce(function(accumulator, currentValue) {
      let cumlate = accumulator + currentValue[sel];
      return mxmn.push(parseInt(cumlate, 10));
    }, []);
  }
  return mxmn;
};

let rangefind = function(
  inarr,
  xvar,
  initialValue = 0,
  cumlate = 0,
  min = 0,
  max = 0,
  capita = false
) {
  let wrange = [];
  for (let i = min; i <= max; i++) {
    wrange.push(xvar + i);
  }
  for (let sel of wrange) {
    inarr.reduce(function(accumulator, currentValue) {
      cumlate = accumulator + currentValue[sel];
      return cumlate;
    }, initialValue + cumlate);
  }
  if (capita == true) {
    return cumlate / wrange.length;
  } else {
    return cumlate;
  }
};
//this only works if create group is pressed

function stack(e) {
  if (addmapclr == true && z == 1) {
    let x = e.target.feature.properties;
    const selbool = fe.includes(x);
    if (selbool !== true) {
      fe.push(x);
      e.target.setStyle({
        fillColor: "#bdbdbd"
      });
      y = 1;
      creategrp++;
      if (createchartf == 0) {
        savegrpbutton.style.display = "";
        creategrpbutton.style.display = "none";
      }
    }
  }
}

function savegroup() {
  face = [];
  faceloc = [];
  dte = Bdte;
  dtetwo = Bdtetwo;
  proptype = Bproptype + Bmertype;
  propyr = indyr;

  let grpname = "GRP";
  if (creategrp > 0 && fe !== []) {
    groupcount++;
    groupob[grpname + groupcount] = fe;
    fe = [];
    let xz = document.getElementById("GRPA");
    xz.setAttribute("uk-icon", "icon:location; ratio: 0.7");
    xz.setAttribute("uk-tooltip", "title: CREATE ANOTHER GROUP; pos: top");
    z = 0;
    gran = [];
    groupnamesSet = {};
    groupnames = {};

    var grxxx = groupob[grpname + groupcount].map(function(drink, x) {
      let prin = propyr + proptype;
      let dte_ = parseInt(dte, 10);
      let dtetwo_ = parseInt(dtetwo, 10);
      let cvegg = [];
      cvegg.push(drink);
      face.push(drink.SA2_NAME_2016);
      faceloc.push(drink.MER_SA2);
      groupnames["GRLOC"] = face;
      groupnames["GRLOCODE"] = faceloc;
      groupnames["GSTARTD"] = dte_;
      groupnames["GENDD"] = dtetwo_;
      groupnames["GYEAR"] = propyr;
      groupnames["GMEAS"] = proptype;
      return rangefind(cvegg, prin, 0, 0, dte_, dtetwo_);
    });

    const sum = grxxx.reduce((total, amount) => total + amount);
    gran.push(sum);
    groupnames["GAMT"] = parseInt(gran);
    groupnamesSet["key"] = "G" + groupcount;
    groupnamesSet["value"] = groupnames;
    groupnameSetarr.push(groupnamesSet);
    onMapClick();
    savegrp++;
    //show chart button on;y if ready
    if (savegrp > 1 && createchartf == 0) {
      chartbutton.style.display = "";
    }
    savegrpbutton.style.display = "none";
    creategrpbutton.style.display = "";
  }
}

function style(feature) {
  dte = Bdte;
  dtetwo = Bdtetwo;
  proptype = Bproptype + Bmertype;
  propyr = indyr;

  let prin = propyr + proptype;
  let cv = [];
  let dte_ = Bdte;
  let dtetwo_ = Bdtetwo;

  cv.push(feature.properties);

  //https://codeburst.io/useful-javascript-array-and-object-methods-6c7971d93230

  rf = rangefind(cv, prin, 0, 0, dte_, dtetwo_);
  //sf = scalefind(cv, prin, 0, 0, dte_, dtetwo_)
  selbool = GRPSEL.includes(feature.properties.MER_SA2);

  function colorbase() {
    if (selbool == false && GRPSELBOOL == false) {
      return Colr(rf);
    } else if (selbool == true && GRPSELBOOL == false) {
      //   console.log('selbool == true && GRPSELBOOL == false)')
      return "#636363";
    } else if (selbool == true && GRPSELBOOL == true) {
      //    console.log('selbool == true && GRPSELBOOL == true')
      return "#737373";
    }
  }
  //console.log('rf a ', rf )

  return {
    fillColor: colorbase(),
    weight: 2,
    opacity: 1,
    color: "white",
    dashArray: "3",
    fillOpacity: 0.7
  };
}

function highlightFeature(e) {
  var layer = e.target;
  if (z == 0) {
    geoj.resetStyle(e.target);
  }
  //geoj.resetStyle(e.target);
  layer.setStyle({
    weight: 5,
    color: "#666",
    dashArray: "",
    fillOpacity: 0.7
  });

  //this updates every time the feature is highlighted

  info.update(layer.feature.properties, rf);

  // console.log('rf', rf)

  if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
    layer.bringToFront();
  }
}

function resetHighlight(e) {
  if (z == 0) {
    geoj.resetStyle(e.target);
    info.update();
  } else {
    var layer = e.target;
    layer.setStyle({
      weight: 2,
      opacity: 1,
      color: "white",
      dashArray: "3",
      fillOpacity: 0.7
    });
    info.update();
  }
}

function grselbutton() {
  let xz = document.getElementById("GRPA");
  xz.setAttribute("uk-icon", "icon:search; ratio: 0.7");
  xz.setAttribute("uk-tooltip", "title: SELECT MAP AREA; pos: top");
  //xz.style.display="none"
  z = 1; // this is the flag for the select group button
  creategrpbtn == true; //create group
  onMapClick();
}

function onEachFeature(feature, layer) {
  layer.on({
    mouseover: highlightFeature,
    mouseout: resetHighlight,
    click: stack
  });
}

// this is the main function the creates the map
function gomap(e) {
  if (typeof geoj !== "undefined") {
    map.removeLayer(geoj);
  }
  geoj = L.geoJson(jsonObj, {
    style: style,
    onEachFeature: onEachFeature
  }).addTo(map);

  if (e != null) {
    map.fitBounds(geoj.getBounds());
  }
  mSel = propyr + proptype + dte;
  selnice = BSelnice;
  map.touchZoom.disable();
}

// this gets called often and every time the map updates

function onMapClick(e) {
  dte = Bdte;
  dtetwo = Bdtetwo;
  proptype = Bproptype + Bmertype;
  propyr = indyr;
  dol3 = Bdtype;
  if (dol3 == "Amount $ ") {
    ftype = "$.3s";
  } else if (dol3 == "Percent % ") {
    ftype = ".0%";
  } else {
    ftype = "$.3s";
  }

  let testprop = jsonObj.features;
  var extx = testprop.map(function(drink, x) {
    let prin = propyr + proptype;
    let dte_ = dte;
    let dtetwo_ = dtetwo;
    let cve = [];
    cve.push(drink.properties);
    return rangefind(cve, prin, 0, 0, dte_, dtetwo_);
  });

  if (sclock == 1) {
    Colr = d3
      .scaleQuantile()
      .domain(d3.extent(pee2))
      .range(red8);
  } else {
    Colr = d3
      .scaleQuantile()
      .domain(d3.extent(extx))
      .range(red8);
  }
  if (createchartf !== 1) {
    const canvas = d3.select(LeafBR).attr("height", 150);
    canvas.select("svg").remove();
    svg = canvas
      .append("svg")
      .attr("width", 110)
      .attr("height", 117);

    svg
      .append("g")
      .attr("class", "legendQuant")
      //.attr("transform", "translate(20,20)")
      .attr("transform", "scale(0.65)");
    var legend = d3
      .legendColor()
      .labelFormat(d3.format(ftype))
      .useClass(false)
      .shapeWidth(20)
      .shapeHeight(20)
      .scale(Colr);
    svg.select(".legendQuant").call(legend);
  }

  gomap(e);
  addmapclr = true;
}

var selnice = "Select & Click Add Map Colour";
let dolorcnt = 1;

//delete map
function nullMap(e) {
  if (typeof geoj !== "undefined") {
    map.removeLayer(geoj);
  }
  selnice = "Select & Click Add Map Colour";
  info.addTo(map);
}

//http://www.puzzlr.org/force-directed-graph-minimal-working-example/

var str = 0;
var ani;

// lock the scale
function lockscale() {
  let scval;
  if (document.getElementById("sctd").checked) {
    scval = document.getElementById("sctd").value;
  }
  if (document.getElementById("sctr").checked) {
    scval = document.getElementById("sctr").value;
  }

  sclock = 1;
  dte = Bdte;
  dtetwo = Bdtetwo;
  proptype = Bproptype + Bmertype;
  propyr = indyr;

  dol3 = Bdtype;
  if (dol3 == "Amount $ ") {
    ftype = "$.3s";
  } else if (dol3 == "Percent % ") {
    ftype = ".0%";
  } else {
    ftype = "$.3s";
  }

  let testprop = jsonObj.features;
  var extxl = testprop.map(function(drink, x) {
    let prin = propyr + proptype;
    let dte_ = dte;
    let dtetwo_ = dtetwo;
    let cve = [];
    cve.push(drink.properties);
    return rangefind(cve, prin, 0, 0, dte_, dtetwo_);
  });

  var extxlock = testprop.map(function(drink, x) {
    let prin = propyr + proptype;
    let dte_ = dte;
    let dtetwo_ = dtetwo;
    let cve = [];
    cve.push(drink.properties);
    return scalefind(cve, prin, 0, 0, dte_, dtetwo_);
  });
  for (let sel of extxlock) {
    pee.push(...sel);
  }
  if (scval == 1) {
    pee2 = pee;
  } else {
    pee2 = extxl;
  }
}

function resetscale() {
  pee = [];
  pee2 = null;
  sclock = 0;
}

function example1(e) {
  map.fitBounds(geoj.getBounds());
  let bar = 1;
  const evt = new MouseEvent("mouseover");
  const evt2 = new MouseEvent("mouseout");
  groupnameSetarr = testob;
  groupchart.update = upgroupchart;
  groupchart.addTo(map);
  bottomchart();
  const canvas = d3.select(LeafBR);
  canvas.select("svg").remove();

  function one() {
    d3.select(
      `#mapid  div.leaflet-control-container  div.leaflet-bottom.leaflet-left  div  svg  g  rect:nth-child( ${bar})`
    )
      .node()
      .dispatchEvent(evt);
  }

  function two() {
    d3.select(
      "#mapid  div.leaflet-control-container  div.leaflet-bottom.leaflet-left  div  svg  g  rect:nth-child(1)"
    )
      .node()
      .dispatchEvent(evt2);
  }

  setTimeout(one, 1500);
  //setTimeout(two, 1500)
}

function example2(e) {}

var info = L.control();
info.onAdd = function(map) {
  this._div = L.DomUtil.create("div", "info"); // create a div with a class "info"
  this.update();
  return this._div;
};

let upbox2 = function(props, mainSel) {
  // mainSel is the main selection
  if (dol3 == "Amount $ ") {
    formt = d3.format("$.3s");
  } else if (dol3 == "Percent % ") {
    formt = d3.format(".0%");
  } else {
    formt = "$.3s";
  }
  let pr = mainSel;
  if (props != null && z == 0) {
    this._div.innerHTML =
      "<b>Measure: </b>" +
      selnice +
      "<br>" +
      (props
        ? "<b>Region Code: </b>" +
          props.GCCSA_CODE_2016 +
          "<br><b>Area Name: </b>" +
          props.SA2_NAME_2016 +
          "<br>" +
          "  <b>Amount: " +
          formt(pr) +
          "</b><br>"
        : "Hover over an area");
  } else if (props != null && z !== 0) {
    this._div.innerHTML =
      "<b>Measure: </b>" +
      selnice +
      "<br>" +
      (props
        ? "<b>Region Code: </b>" +
          props.GCCSA_CODE_2016 +
          "<br><b>Area Name: </b>" +
          props.SA2_NAME_2016 +
          "<br>" +
          " <br> <b>SELECT GROUP AREA</b><br>" +
          " After selecting area/s press save button<br>  " +
          " You must select and save at least 2 groups<br>  " +
          " before you can create a chart <br>  " +
          " Once the chart button appears<br>      " +
          " you can press it to create a bar chart<br>  "
        : "Hover over an area");
  }
};

info.update = upbox2;

function bottomchart() {
  if (dol3 == "Amount $ ") {
    formt = d3.format("$.3s");
  } else if (dol3 == "Percent % ") {
    formt = d3.format(".0%");
  } else {
    formt = "$.3s";
  }

  let cc = groupnameSetarr;
  // add width for no of groups
  let gwidth = 15 * (groupcount - 1);
  var margin = {
    top: 20,
    right: 10,
    bottom: 20,
    left: 40
  };
  var width = 110 + gwidth - margin.left - margin.right,
    height = 110 - margin.top - margin.bottom;

  var div = d3.select(LeafBL).append("div");

  //append all the dom html tags here   http://localhost:3000/api/card/sae

  var svg = d3
    .select(LeafBL)
    .append("svg")

    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

  let x = d3
    .scaleBand()
    .paddingInner(0.1)
    .paddingOuter(0.1);
  let y = d3.scaleLinear().range([height, 0]);

  y.domain([0, d3.max(cc.map(a => a.value.GAMT))]);
  x.domain(cc.map(a => a.key)).range([0, width]);
  const rects = svg.selectAll("rect").data(cc);

  rects.exit().remove();
  rects
    .attr("width", x.bandwidth)
    .attr("height", d => height - y(d.value))
    .attr("fill", function(d) {
      return d.key == fillclr ? "#969696" : "#d9d9d9";
    })
    .attr("x", d => x(d.key))
    .attr("y", d => y(d.value.GAMT));

  rects
    .enter()
    .append("rect")
    .attr("width", x.bandwidth)
    .attr("height", d => height - y(d.value.GAMT))
    .attr("fill", function(d) {
      return d.key == fillclr ? "#969696" : "#d9d9d9";
    })
    .attr("x", d => x(d.key))
    .attr("y", d => y(d.value.GAMT))
    .on("mouseover", handlem)
    .on("mouseout", handlemout);
  //handlem(0,0,0)
  const xAxisGroup = svg
    .append("g")
    .attr("transform", `translate(0, ${height} )`);
  const yAxisGroup = svg.append("g");
  const xAxis = d3.axisBottom(x).tickSize(2);
  const yAxis = d3
    .axisLeft(y)
    .ticks(2)
    .tickSize(2)
    .tickFormat(formt);

  xAxisGroup.call(xAxis);
  yAxisGroup.call(yAxis);
}

var legend = L.control({
  position: "bottomright"
});
legend.onAdd = function(map) {
  var div = L.DomUtil.create("div", "info legend");
  return div;
};
var groupchart = L.control({
  position: "bottomleft"
});
groupchart.onAdd = function(map) {
  this._div = L.DomUtil.create("div", "info groupchart");
  this.update();
  return this._div;
};

const handlem = (d, i, n) => {
  d3.select(n[i])
    .transition()
    .duration(10)
    .attr("fill", "#737373");

  //  console.log(p)
  //val  = d.value.GAMT
  GRPSEL = [];
  GRPSEL = d.value.GRLOCODE;
  GRPSELBOOL = true;
  onMapClick();
  d3.select("#GAMT").text(formt(d.value.GAMT));
  d3.select("#GSTARTD").text(dtSAStoJS(d.value.GSTARTD, "DATE").toDateString());
  d3.select("#GENDD").text(dtSAStoJS(d.value.GENDD, "DATE").toDateString());
  d3.select("#GMEAS").text(d.value.GMEAS);

  var u = d3
    .select("#GRLOCLIST")
    .selectAll("li")
    .data(d.value.GRLOC);

  u.enter()
    .append("li")
    .merge(u)
    .text(function(d) {
      return d;
    });
  u.exit().remove();
  const canvas = d3.select(LeafBR);
  canvas.select("svg").remove();
};
const handlemout = (d, i, n) => {
  onMapClick();
  d3.select(n[i])
    .transition()
    .duration(10)
    .attr("fill", "#d9d9d9");
  const canvas = d3.select(LeafBR);
  canvas.select("svg").remove();
};

let upgroupchart = function(val = "win") {
  if (val != null) {
    this._div.innerHTML = `<div id = "btmdiv" >
    <b>COMPARISON</b><br><br>
    <b>Start Date:</b> <span id = "GSTARTD"></span><br>
    <b>End Date: </b> <span id = "GENDD"></span><br>
    <b>Amount: </b> <span id = "GAMT"></span><br>
    <b>Location: </b> <ul id = "GRLOCLIST"  style=" margin:5px ;padding-left: 10px ;font: 10px Arial, Helvetica, sans-serif;"></ul><br>
    </div  >
    `;
  }
};

let upgroupchart2 = function() {
  this._div.innerHTML = "    <b> Placeholder<b>";
};

//this runs a funxtion to update html

let bch = () => {
  if (savegrp > 1 && createchartf == 0) {
    groupchart.update = upgroupchart;
    groupchart.addTo(map);
    bottomchart();
    const canvas = d3.select(LeafBR);
    canvas.select("svg").remove();
    createchartf = 1;
    creategrpbutton.style.display = "none";
    chartbutton.style.display = "none";
    maptbutton.style.display = "none";
  }
};

const actionMap30 = document.getElementById("GRCHART");
actionMap30.addEventListener("click", bch);

const handleparms = val => {
  // console.log(labelvals[val])
  d3.select("p#slider-label_v").text(labelvals[val]["value"]);
  // update others
  Bproptype = labelvals[val]["key"];
  BSelnice = labelvals[val]["value"];
  Bdtype = labelvals[val]["dtype"];
  //  handledays(bigval)
  onMapClick();
};

const handleparms2 = val => {
  // console.log(labelvals[val])
  d3.select("p#slider-label_v2").text(mercatlabel[val]["value"]);
  // update others
  Bmertype = mercatlabel[val]["key"];
  // handledays(bigval)
  console.log(" Bmertype", Bmertype);
  onMapClick();
};

const handleyears = val => {
  syear = (val - 2017) * 365;
  indy = val - 2016;
  indyr = "Y" + (indy + 1).toString();
  //console.log(syear, indy)
  d3.select("p#slider-year_v").text(yearlabel[indy]["value"]);
  handledays(bigval);
  console.log("syearr", syear);
  onMapClick();
};

const handledays = val => {
  let win = dtSAStoJS(val[0] + syear, "DATE").toDateString();
  let win1 = dtSAStoJS(val[1] + syear, "DATE").toDateString();
  d3.select("p#slider-range_v").text([win, win1].join(" - "));

  bigval = val;

  Bdte = val[0] + syear;
  Bdtetwo = val[1] + syear;

  console.log("bigval", bigval);
  onMapClick();
};

legend.addTo(map);

info.addTo(map);

var sliderStepLabel = d3
  .sliderBottom()
  .min(0)
  .max(1)
  .width(50)
  .tickFormat(d3.format(".0f"))
  .ticks(0)
  .step(1)
  .default(0)
  .handle(
    d3
      .symbol()
      .type(d3.symbolCircle)
      .size(170)()
  )

  .on("onchange", handleparms);

d3.select("p#slider-label_v").text(labelvals[0]["value"]);
d3.selectAll(".parameter-value").style("cursor", "pointer");
//  .style("cursor", "pointer")

var gStep = d3
  .select("div#slider-label")
  .append("svg")
  .attr("width", 200)
  // .attr('height', 40)
  .attr("height", 35)
  .append("g")
  .attr("transform", "translate(13,26)");

gStep.call(sliderStepLabel);

//mccs
var sliderStepLabel2 = d3
  .sliderBottom()
  .min(0)
  .max(4)
  .width(50)
  .tickFormat(d3.format(".0f"))
  .ticks(0)
  .step(1)
  .default(0)
  .handle(
    d3
      .symbol()
      .type(d3.symbolCircle)
      .size(170)()
  )
  .on("onchange", handleparms2);

d3.select("p#slider-label_v2").text(mercatlabel[0]["value"]);
d3.selectAll(".parameter-value").style("cursor", "pointer");
var gStep = d3
  .select("div#slider-label2")
  .append("svg")
  .attr("width", 200)
  .attr("height", 35)
  .append("g")
  .attr("transform", "translate(13,26)");

gStep.call(sliderStepLabel2);

// function cur() {
//   document.getElementById('p#slider-label_v2').style.cursor = "pointer";
// }

//year

var sliderStep = d3
  .sliderBottom()
  .min(2016)
  .max(2018)
  .width(50)
  .tickFormat(d3.format(".0f"))
  .ticks(0)
  .step(1)
  .default(1)
  .handle(
    d3
      .symbol()
      .type(d3.symbolCircle)
      .size(170)()
  )

  .on("onchange", handleyears);

d3.select("p#slider-year_v").text(yearlabel[0]["value"]);
d3.selectAll(".parameter-value").style("cursor", "pointer");
var gStep = d3
  .select("div#slider-year")
  .append("svg")
  .attr("width", 200)
  .attr("height", 35)
  .append("g")
  .attr("transform", "translate(13,26)");

gStep.call(sliderStep);

var sliderRange = d3
  .sliderBottom()
  .min(21154)
  .max(21184)
  .width(180)
  .tickFormat(d3.format(".0f"))
  .ticks(0)
  .default([21154, 21159])
  .fill("#aaa")
  .step(1)
  .handle(
    d3
      .symbol()
      .type(d3.symbolCircle)
      .size(170)()
  )
  .on("onchange", handledays);

let win = dtSAStoJS(21154 + syear, "DATE").toDateString();
let win1 = dtSAStoJS(21159 + syear, "DATE").toDateString();
d3.select("p#slider-range_v").text([win, win1].join(" - "));

var gRange = d3
  .select("div#slider-range")
  .append("svg")
  .attr("width", 450)
  .attr("height", 50)
  .append("g")
  .attr("transform", "translate(13,26)");

gRange.call(sliderRange);

function wl() {
  handledays(bigval);
  nullMap();
  const canvas = d3.select(LeafBR);
  canvas.select("svg").remove();
}

window.onload = wl();


var  closebtns
var appla  =  function  () 
{

  console.log( "butt: ", Bmertype   )
  const node = document.createElement("SPAN");
  const node2 = document.createElement("SPAN");
  const textnode2 = document.createTextNode('x');
  const textnode = document.createTextNode(Bmertype);  
  node.appendChild(textnode);
  node.appendChild(node2);
  node2.appendChild(textnode2);
  node2.classList.add("close");
  node.classList.add("closea");
  document.getElementById("myList").appendChild(node);
  closebtns = document.getElementsByClassName("close");

  let i;
  for (i = 0; i < closebtns.length; i++) {
    closebtns[i].addEventListener("click", function() {
  
      this.parentElement.remove()
    });
  }
}

var applabel = document.getElementById("APP1");
applabel.addEventListener("click", appla);





//d3.select('p#value-step').text(d3.format('.2%')(sliderStep.value()));

//dtSAStoJS(d.value.GSTARTD, 'DATE').toDateString() 21154 21184  .on("mouseout", handlemout)
