/* eslint-disable */

//import {}   from  './modules/Selectors/selv2.js'

import {
  addPill,
 // addPillz,
  addPilly,
  ConfigObj,
//  pushObjcc,
  ProjObj ,

  getDataComp ,
  pickReduce,
  combineArrays, 

 // getDropObsListCode,
  seeddropX,
 // getDropObsListCodeX,

  createSeedsDrop

} from '/js/api/modules/mods/dataSelect.js';

import {

  logsub


} from '/js/api/modules/mods/auth.js';


//based on what goes into it
let ModalObj = {

  Name : ''  ,
  content :''

}





let sld;
let chrSld
console.log(addPill);
console.log(ConfigObj);

//const { DRPOB } = ConfigObj;
const {  DRPOBC  , DRPOB, DTR } = ConfigObj;

//global vars
//Select serioes var
let dataSegID = 99;  //box for the data seg   CreateBoxCard 
let selID = 99;   //smallest level for data seg  let xnewsel = function(id  ,  obj ,  sel ) 
let chartID = 99;
let mdlID = 99;
let gridID = 99;   //main-box-sel  the highest level id everything goes in here 
let  projID = 99;  // the id for the project only one for each page


//this is part of the save function for state
 function pushObj(ob, key, value, id) {
  const idx = id - 100;
  ob.filter(function (obj) {
    if (obj[key].includes(value)) {
      const { name, drpdwn, drpdwnSelected, ctype } = obj;
      let dp = document.querySelector(`#${value}-B-${id}`).childNodes;
      console.log('dp  ', dp);

      for (let i = 1; i < dp.length; i++) {
        let pilln = dp[i].textContent; //need to get rid of x at end
        let pillname = pilln.substring(0, pilln.length - 1);
        let pillcode = dp[i].classList[2]; //this is the name of the group
        drpdwnSelected[idx].push({ name: pillname, code: pillcode });
      }
    }
  });
}


//this saves the state for each selection group e.g. #S100
function SaveSelectData(SEEDR, id) {  
  const idSelInx = id - 100;
  console.log('idSelInx  ', idSelInx);
  for (let j = 0; j < SEEDR.length; j++) {
    SEEDR[j].drpdwnSelected[idSelInx] = []; //this clears it before putting in the new value
    pushObj(SEEDR, 'ctype', SEEDR[j].ctype, id);
  }
  //save the dates  this need sown funtion??

  const sldr = sld.noUiSlider.get();
  const mindte = Math.trunc(sldr[0] / 10) + 9;
  const maxdte = Math.trunc(sldr[1] / 10) + 9;
  const min = document.querySelector(`#slider-min-${id}`).innerHTML;
  const max = document.querySelector(`#slider-max-${id}`).innerHTML;

  //need to clear it first

  DTR.DTSEL[idSelInx] = [];
  DTR.DTSEL[idSelInx].push({ YMC: mindte, YM: min }, { YMC: maxdte, YM: max });

  //need to save names
  const selName = document.querySelector(`#S${id} > input`).value;
  console.log('idSelInx  ', idSelInx);
  console.log('selName   ', selName );

  DTR.SELNAME[idSelInx] = [];
  DTR.SELNAME[idSelInx].push({ selname: selName }, { idx: idSelInx }, { id: id });

  DRPOBC.SEEDR[0].drpdwn.push( { name : DTR.SELNAME[idSelInx][0].selname ,code: idSelInx  }   );

  
  console.log(' DRPOBC.SEEDR[0].drpdwn  ',     DRPOBC.SEEDR[0].drpdwn);
  console.log('DTR.DTSEL  ', DTR.DTSEL);
  console.log('SEEDR  ', DRPOB.SEEDR);
  console.log('ConfigObj  ', ConfigObj);
}


function SaveChartData(CHARTOBJ, id) {
  const idchartInx = id - 100;
  console.log('idchartInx ', idchartInx);
  console.log('CHARTOBJ', CHARTOBJ);

  const chartName = document.querySelector(`#C${id} > input`).value;
  console.log('idchartInx ', idchartInx);
  DTR.CHRSELNAME[idchartInx] = [];
  DTR.CHRSELNAME[idchartInx].push({ selname: chartName }, { idx: idchartInx }, { id: id });
  console.log(' DTR.CHRSELNAME ',  DTR.CHRSELNAME);
 
  // sldr =  chrSld.noUiSlider.get();
  const chrtype = document.querySelector(`#slider-chart-type-${id}`).innerHTML;

  console.log(' chrtype ', chrtype);

  DTR.CHRSEL[idchartInx] = [];
  DTR.CHRSEL[idchartInx].push({ chartype: chrtype });

}


//new small selector 
let xnewsel = function(id  ,  obj ,  sel ) {

  const {  DRPOBC  , DRPOB, DTR  } = obj;

  const startgrid = document.querySelector(`#${sel}` );

  startgrid.insertAdjacentHTML(
    'beforeend',
    `<div><div id='S${id}' class="uk-lbcont Sel">        
    <input class="uk-input uk-form-width-small uk-form-small" value="Selection ${id - 99}"></input> <br>
    <span class="uk-label">TIME HORIZON </span> <span id="X1" class="uk-badge">100</span>  
    <br> <span id='slider-min-${id}' class="closeb"></span>
    <span id='slider-max-${id}' class="closeb"></span> <br>
    <div id ="slider-${id}" class ="sc" >  </div>  
    </div> </div> <br>`
  );
  

  //this is for thr date slider 
  const arrobj = DTR.DTARR;
  const min = 10;
  const max = 47;
  const sliderDt = `S${id}`;
  const sliderEl = `slider-${id}`;

  const YMARR = [];
  for (let i = 0; i < arrobj.length; i++) {
    if (min <= arrobj[i].YMC && max >= arrobj[i].YMC) {
      YMARR.push(arrobj[i].YM);
    }
  }

  let datesrg = YMARR;
  const startSliderDate = document.getElementById(sliderDt); //A2
  console.log('startSliderDate ', startSliderDate);

  const startSlider = document.getElementById(sliderEl);
  console.log('startSlider   ', startSlider);

  noUiSlider.create(startSlider, {
    start: [10, 370],
    connect: true,
    step: 10,
    range: {
      min: [10],
      max: [370]
    }
  });

  sld = startSlider;
  console.log(' sld ', sld);

  const marginMin = document.getElementById(`slider-min-${id}`),
    marginMax = document.getElementById(`slider-max-${id}`);

  startSlider.noUiSlider.on('update', function(values, handle) {
    if (handle) {
      marginMax.innerHTML = datesrg[Math.trunc(values[handle]) / 10 - 1];
      console.log('handle  ', values, handle, 'arr ', Math.trunc(values[handle]) / 10 - 1);
    } else {
      marginMin.innerHTML = datesrg[Math.trunc(values[handle]) / 10 - 1];
      console.log('handle  ', values, handle, 'arr ', Math.trunc(values[handle]) / 10 - 1);
    }
  });
  startSlider.noUiSlider.set([80, 300]);

  //based on the object saved
  function pillfill(ob, key, value, id) {
    ob.filter(function(obj) {
      //3 loops for each
      if (obj[key].includes(value)) {
        const { name, drpdwn, drpdwnSelected, ctype } = obj;
        const idx = id - 100;
        if (Array.isArray(drpdwnSelected[idx]) && drpdwnSelected[idx].length) {
          for (let i = 0; i < drpdwnSelected[idx].length; i++) {
            addPilly(ctype, drpdwnSelected[idx][i].name, drpdwnSelected[idx][i].code, id);
          }
        }
      }
    });
  }

  function seeddrop(SEEDR) {
    for (let j = 0; j < SEEDR.length; j++) {
      createSeedsDrop(SEEDR, 'ctype', SEEDR[j].ctype, `${id}`, `#S`);
      pillfill(SEEDR, 'ctype', SEEDR[j].ctype, `${id}`);
    }
  }

  seeddrop(DRPOB.SEEDR);

  //need to push the selection in to the chart cdropdown

   console.log( 'selmane '  , DTR.SELNAME  )


};





 async function HC(arr, xcat ,id) {
   //need to create a div caled chart container  
    await Highcharts.chart(`CHART-${id}`, {
      chart: {
        type: 'line',
        styledMode: true
      },
  
      legend: {
        enabled: true
      },
      title: {
        text: 'Monthly Stuff'
      },
  
      tooltip: {
        pointFormat: 'Am: {point.y:.2f}'
      },
      xAxis: {
        categories: xcat, 
        tickInterval: 2
      },
      series: [
        {
          name: 'mogas',
          data: arr
        }
      ]
    });
  
    console.log(arr);
  }

//need order of blocks

//idx represnts the index of the numer of selectors
 async function getExz(idx) {
   const dr = await seeddropX(DRPOB.SEEDR, idx);
   const selected_fields = await combineArrays(dr); // for the group of 3 dropdowns
   const mindte = DTR.DTSEL[idx][0].YMC;
   const maxdte = DTR.DTSEL[idx][1].YMC;
   const jsonObj = await getDataComp(mindte, maxdte);
   const coll = await jsonObj.data;

   await console.log('selected_fields  ', selected_fields);
   await console.log('coll ', coll);
   await console.log('SLIDE------------------ ', mindte, maxdte);

   let arr = [];
   let xcat = [];
   await coll.map(function(prps, x) {
     let date = prps.CYM.substring(2, 6) + prps.CYM.substring(6);
     let obj = { name: parseInt(prps.CYM.substring(2, 8)), y: pickReduce(prps, selected_fields) };
     arr.push(obj);
     xcat.push(date);
   });
   await console.log('xcat  ', xcat);
   await console.log('arr    ', arr);
   await HC(arr, xcat, 1);

 }





function CreateBoxCard (  CardId  ,gridSize   , selmain ,selTitle )   {
  const startSel = document.querySelector(`#${selmain}`)
  startSel.insertAdjacentHTML(
    'beforeend',
    ` <div class="uk-width-1-${gridSize}@m">
       <div id="SelCard-${CardId}" class="uk-card uk-card-default uk-card-body">
   
       <div class="uk-flex uk-flex-between"> ${selTitle}
       <button id='seg-add-${CardId}' class="uk-button  uk-button-default uk-button-small">Add</button> 
       </div>
       <br><br>
       </div>
      </div>` );

}



function CreateProj (  gridSize   , selmain ,selTitle )   {

  projID = projID +1 ;
  const startSel = document.querySelector(`#${selmain}`)
  startSel.insertAdjacentHTML(
    'beforeend',
    `  
       <div class="uk-width-1-${gridSize}@m">
       <span class="uk-label">${selTitle} </span> <span id="X1" class="uk-badge">100</span>  
       <button id='proj-add-${projID}' class="uk-button  uk-button-default uk-button-small">Add</button> <br><br>
       </div>
      </div>` );

}




function CreateStartGrid( GridId  , selmain )   {
  const startSel = document.querySelector(`#${selmain}`)
  startSel.insertAdjacentHTML(
    'beforeend',
    `<div id ='GridStart-${GridId}' uk-grid  >
    </div>` );
}


///need a funtion that creates a container with chart   ${CardId}
 

//create chart cell



//




let sectIn  =  function() {

  dataSegID = dataSegID + 1;
  CreateBoxCard  (dataSegID, 3  , `GridStart-${gridID}`,  'new ')
  console.log('ProjObj  ', ProjObj);
  //add event listener


 document.querySelector(`#seg-add-${dataSegID}`).addEventListener('click', T5 );

 
 }


let T4=  function() {


 
 CreateModalGeneric (  "main-box-sel", 1 ,'NEW Project' , 'Create'  , `<h6>POOOOO</h6>`, sectIn)


//   dataSegID = dataSegID + 1;
//   CreateBoxCard  (dataSegID, 3  , `GridStart-${gridID}`,  'new ')
//   console.log('ProjObj  ', ProjObj);
//   //add event listener
//  document.querySelector(`#seg-add-${dataSegID}`).addEventListener('click', T5 );

 
 }


let T5 = function() {
  selID = selID + 1;
  xnewsel(selID  , ConfigObj , `SelCard-100`);
  console.log('selid ', selID);
};


let T8 = function() {
  selID = selID + 1;
  newsel(selID);
  console.log('selid ', selID);
};

let T7 = function() {   //test the drop  nave

 let el = document.querySelector("#main > div.uk-dropdown")
console.log(el)
  UIkit.dropdown(el).show();
};


let ModalCb = function() {
  gridID = gridID + 1
  CreateStartGrid(  gridID  , "main-box-sel" ) 
 CreateProj  ( 1  , `GridStart-${gridID}` , ModalObj.Name)
 
  //add event listener
 
 document.querySelector(`#proj-add-${projID}`).addEventListener('click', T4 );
 
 
 }


//creates a modal return 3 controls in arrary

function CreateModalGeneric(mainSelector, modalid, title, buttonName, innerTemplate, cbFunct) {
  const startSel = document.querySelector(`#${mainSelector}`);
  startSel.insertAdjacentHTML(
    'beforeend',
    `  <div id="modal-a-${modalid}" uk-modal >
     <div class="uk-modal-dialog uk-modal-body" uk-overflow-auto>
     <h6 class="uk-modal-title">${title}</h6>
     ${innerTemplate}
     <input  id='MB-input-${modalid}' class="uk-input uk-form-width-small uk-form-small" ></input> 
     <button id='MB-button-${modalid}' class="uk-button uk-button-primary uk-button-small uk-modal-close" type="button">${buttonName}</button>
     <button class="uk-modal-close-default" type="button" uk-close></button> 
   </div>  
  </div>`
  );

  const startSe = document.querySelector(`#modal-a-${modalid}`);
  const inName = document.querySelector(`#MB-input-${modalid}`);
  const modButn = document.querySelector(`#MB-button-${modalid}`);

  function modalVal() {
    ModalObj.Name = '';
    ModalObj.Name = inName.value;
  }

  modButn.addEventListener('click', modalVal);
  modButn.addEventListener('click', cbFunct);
  UIkit.modal(startSe).show();
}





//operation modal

let T10 = async function() {

//CreateModal (  "main-box-sel", 1 ,'NEW Project' , 'Create'  , `<h6>POOOOO</h6>` ,T6  )


 let cont = CreateModalGeneric (  "main-box-sel", 1 ,'NEW Project' , 'Create'  , `<h6>POOOOO</h6>`, ModalCb )



  }


//chart
let T9 = function() {
  
  getExz(0) 
  
  }


  let SaveAll = function() {
    const selList = document.getElementsByClassName('Sel').length;
    //clear existing before saving 

    DRPOBC.SEEDR[0].drpdwn= []

  


    for (let k = 0; k < selList; k++) {

      SaveSelectData(DRPOB.SEEDR, k + 100);
    }

  //   const chlList = document.getElementsByClassName('Ch').length;
  //   for (let m = 0; m < chlList; m++) {
  //     SaveChartData(DTR.CHRNAME, m + 100);
  //   }
   };





   function createDrop(id, dropName, insertElemtId, drpArr) {
    const drpdwnIn = `<div id = 'MBD' uk-dropdown="mode: click"  > <ul id ="${dropName}-DROP-${id}" class="uk-nav uk-dropdown-nav"> </ul> </div>`;
    const inEl = document.querySelector(`#${insertElemtId}`);
    inEl.insertAdjacentHTML('afterEnd', drpdwnIn);
    let filldrop = document.getElementById(`${dropName}-DROP-${id}`);
    function addP(e) {
      const pillgroup = e.target.classList[0];
      const pillname = e.target.innerHTML;
      console.log('pillgroup ', pillgroup);
      console.log('pillname ', pillname);
      inEl.innerHTML = pillname;

      console.log('inEl.value', inEl.value);
    }
  
    const drpdwn = drpArr;
    for (let i = 0; i < drpdwn.length; i++) {
      filldrop.insertAdjacentHTML('beforeEnd', `<li><a class ='DROP-${id}'  href="#" >${drpdwn[i]}</a></li>`);
  
      //add listener
  
      filldrop.addEventListener('click', addP);
    }
  }
  
   const draaaa =[ 'wwww','ddddd','eeeee'  ]

 
   let T6= function() {
     
    
    createDrop(1, 'computer', 'T1', draaaa)


    console.log('pooo')
    
    }


  //  let T12 = async function() {
  //    let drpdwn = [];
  //    let curval = document.getElementById('MB').value;
  //    if (curval.length > 2) {
  //      let fuzcode = `&FUZ=${encodeURIComponent(curval)}`;
  //      let docs = await getDataAc(`limit=10&perPage=10${fuzcode}`, 1, `abr/fuzz`, `&sort=MerText:desc`);

  //      console.log('docs ', docs);
  //      for (let k = 0; k < docs.length; k++) {
  //        drpdwn.push(docs[k].BUSN);
  //      }
  //    }

  //    createDrop(1, 'N1', 'MB', drpdwn);

  //    UIkit.dropdown(document.getElementById('MBD')).show();
  //  };

  //  document.getElementById('MB').addEventListener('keyup', T12);



  let startPrj = async function() {
    console.log( 'ModalObj '  ,   ModalObj   )
    console.log( 'ProjObj '  ,   ProjObj   )
    CreateModalGeneric (  "main-box-sel", 1 ,'NEW Project' , 'Create'  , `<h6>POOOOO</h6>`, ModalCb )
    
  }



document.querySelector('#T1').addEventListener('click', T1);
document.querySelector('#T2').addEventListener('click', T2);
document.querySelector('#T3').addEventListener('click', T3);
document.querySelector('#T4').addEventListener('click', T4);
document.querySelector('#T5').addEventListener('click', T5);
document.querySelector('#T6').addEventListener('click', T6);
document.querySelector('#T7').addEventListener('click', T7);
document.querySelector('#T8').addEventListener('click', T8);
document.querySelector('#T9').addEventListener('click', T9);
document.querySelector('#T10').addEventListener('click', T10);
document.querySelector('#T11').addEventListener('click', SaveAll);
document.querySelector('#T12').addEventListener('click', startPrj);

//need to insert the slider , need to lable the grid boxes.  CreateSlideDate   document.querySelector("#GRIDSTARTx > div.uk-first-column")

