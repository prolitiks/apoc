
/* eslint-disable */

export var getNextSibling = function(elem, selector) {
  // Get the next sibling element
  var sibling = elem.nextElementSibling;

  // If there's no selector, return the first sibling
  if (!selector) return sibling;

  // If the sibling matches our selector, use it
  // If not, jump to the next sibling and continue the loop
  while (sibling) {
    if (sibling.matches(selector)) return sibling;
    sibling = sibling.nextElementSibling;
  }
};

/*!
 * Get an array of all matching elements in the DOM
 * (c) 2019 Chris Ferdinandi, MIT License, https://gomakethings.com
 * @param  {String} selector The element selector
 * @param  {Node}   parent   The parent to search in [optional]
 * @return {Array}           The elements
 */
export var $$ = function(selector, parent) {
  return Array.prototype.slice.call((parent ? parent : document).querySelectorAll(selector));
};

export var $_ = function(selector, parent) {
  return (parent ? parent : document).querySelector(selector);
};

//returns an elemnt with vals

export function getatrvals(subarr, objkey, keyval, el) {
  let mp = ArrObjCont(subarr, objkey, 'data-id');
  let eltrue = el.querySelector(`[${mp[0][objkey]}="${mp[0][keyval]}"]`);
  return eltrue;
}


export function isElement(o) {
  return typeof HTMLElement === 'object'
    ? o instanceof HTMLElement //DOM2
    : o && typeof o === 'object' && o !== null && o.nodeType === 1 && typeof o.nodeName === 'string';
}

export let $ = function(selector, parent) {
  return isElement(selector) ? selector : (parent ? parent : document).querySelector(`#${selector}`);
};

export function htmStrg(cfgobj, idx) {
  let { crtl, name, prefix, cls, attr, cnt, after, attrname, attrval } = cfgobj;
  let tag = `<${crtl} ${mpto(attr, ' ')} ${mpto(attrname, ' ')}${mpto( attrval,' ' )} 
  id="${prefix}-${idx}" class ="${mpto(name, ' ')} ${mpto(cls, ' ')}">${cnt}`;
  let tagaft = `</${crtl}>${after}`;
  let htmlstr = `${tag}${tagaft}`;
  return { htmlstr, tag, tagaft };
}


export function htmStrgx(cfgobj, idx ) {
  let { crtl, name,  cls,  after , statcnt , dattr } = cfgobj;
  let tag = `<${crtl}  id="${name}-${idx}" ${mpto(dattr,' ')} class ="${mpto(name,' ')} ${mpto(cls,' ')}">${mpto(statcnt, ' ')}`;
  let tagaft = `</${crtl}>${mpto(after, ' ')}`;
  let htmlstr = `${tag}${tagaft}`;
  return { htmlstr, tag, tagaft };
}

export  function htmStrgy(cfgobj, overideObj) {

if (overideObj) {
  for (const [key_] of Object.entries(overideObj)) {
    for (const [key] of Object.entries(cfgobj)) {
      if (key_ == key) {
        cfgobj[key_] = overideObj[key_];
      }
    }
  }
}


  let tag = `<${cfgobj.crtl}  id="${cfgobj.name}" ${mpto( cfgobj.dattr,  " " )} class ="${mpto(cfgobj.name, " ")} ${mpto(cfgobj.cls, " ")}">${mpto(cfgobj.statcnt, " " )}`;
  let tagaft = `</${cfgobj.crtl}>${mpto(cfgobj.after, " ")}`;
  let htmlstr = `${tag}${tagaft}`;
  return { htmlstr, tag, tagaft };
}


export function getFirstChild(el) {
  var firstChild = el.firstChild;
  while (firstChild != null && firstChild.nodeType == 3) {
    // skip TextNodes
    firstChild = firstChild.nextSibling;
  }
  return firstChild;
}

//helper for inserting html
export function $inhtm(html, pos, element) {
  const gel = $(element);
  gel.insertAdjacentHTML(pos, html);
  const firstEl = getFirstChild(gel);
  const lastEl = gel.lastElementChild;
  return { gel, firstEl, lastEl };
}


export function remFrArr(or, remove, objkey, mutate) {
  let original;
  if (mutate) {
    original = or;
  } else original = or.slice();
  for (let i = original.length - 1; i >= 0; i--) {
    for (let j = 0; j < remove.length; j++) {
      if (original[i] && original[i][objkey] === remove[j][objkey]) {
        original.splice(i, 1);
      }
    }
  }
  let named = original.map(nme => nme[objkey]);
  return { original, named, remove };
}


//helper for extracting vaues out of arrays into single strings
//if values is string or number just return
// obkeyname - if has another object , ADD THIS NI OPTIONAL
//if value is array return as joined string
//if array has objects return the values from the key string name, if not return all vales in object
// typeof inp !== "undefined" && (typeof inp !== "object" || !inp)

export let mpto = function(inp, joinvalue, obkeyname) {
  let ky;
  let vl;

  if (typeof inp === 'undefined' ||  !inp) {
    return '';
  } else
    return typeof inp === 'string' || typeof inp === 'number' // ||  typeof inp ==="undefined"
      ? inp
      : //string of object key name
        inp
          .map(function(part) {
            if (typeof inp[0] === 'object') {
              if (Object.values(part).length > 1 && Object.keys(part)[0] == 'datattr') {
                ky = Object.values(part)[0];
                vl = Object.values(part)[1];
                return `${ky} = "${vl}"`;
              }

              if (obkeyname) {
                return Object.values(part[obkeyname]).join(joinvalue);
              } else return Object.values(part).join(joinvalue);
            }
            return part;
          })
          .join(joinvalue);
};

//if the key value matches the objects in the arry return the object selected
//returns all the objects that match the key val so need to [ ] to get the single object
//arr - array of objects
//key - key of object to select
//value of that key to select

export function ArrObjCont(arr, key, value) {
  let ar = arr.filter(function(obj) {
    if (obj[key].includes(value)) {
      return obj;
    }
  });
  return ar;
}
