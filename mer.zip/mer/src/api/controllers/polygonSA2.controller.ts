export {};
import { NextFunction, Request, Response, Router } from 'express';
const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;
const httpStatus = require('http-status');
const { omit } = require('lodash');
import { User, UserNote, PolygonSA2 } from 'api/models';
import { startTimer, apiJson } from 'api/utils/Utils';
import { json } from 'body-parser';

const MongoObj = require('mongodb').ObjectID;
var MongoClient = require('mongodb').MongoClient;

const url = "mongodb://localhost:27017/";


const { handler: errorHandler } = require('../middlewares/error');





exports.gettrans = async (req :Request, res:Response, next: NextFunction) => {

  try {
           await res.json("Polywaffle.......")
          } 
          catch (e) {
          next(e) 
          }
}


/**
 * Get user list
 * @public
 * @example GET https://localhost:3009/v1/users?role=admin&limit=5&offset=0&sort=email:desc,createdAt
 */
exports.list = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await PolygonSA2.list(req)).transform(req);
   console.log('list(req)) ', req   )
    apiJson({ req, res, data, model: PolygonSA2 });
  } catch (e) {
    next(e);
  }
};


exports.listfuzz = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await PolygonSA2.listfuzz(req)).transform(req);
  await console.log('data  ', data   )
    apiJson({ req, res, data, model: PolygonSA2 });
  } catch (e) {
    next(e);
  }
};



exports.listjoin = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await PolygonSA2.listjoin(req));
  await console.log('data  ', data   )
 //   apiJson({ req, res, data, model: Card });
  let gj_new 
  let gj={
  "type": "FeatureCollection",
  "features": []};
   gj.features=data;
   gj_new =gj;


    res.json(gj_new)
  } catch (e) {
    next(e);
  }
};



exports.listjoinMongo = async (req: Request, res: Response, next: NextFunction) => {
  try {
  await   MongoClient.connect(url, function(err:any, db:any) {

      //this gets the strings from the url  GCCSA_CODE_2016  Y1TMRM1D20789
      let qm3={"$match" : {   $or: [  {  "SA4_CODE_2016": 401  }    ]     }   };
     let ag1= { 
        $group : {_id : "$SA4_CODE_2016" ,  totalAmount: { $sum : "$Y1TMRM1D20789" }}
          }
  
    ;
      let dbo = db.db("chuck");
    
      dbo.collection("SA2BOX31").aggregate( [qm3,   ag1  ] ).toArray(function(err:any, result:any) {
        if (err) throw err;
      let  sa2log=result;
        db.close();
     
    
   
     res.json( sa2log)
    });
  });
  
   } 
   catch (e) {
   next(e) 
   }
};




exports.listjoingoose = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await PolygonSA2.listjoin(req));
  await console.log('data  ', data   )
 //   apiJson({ req, res, data, model: Card });
  let gj_new 
  let gj={
  "type": "FeatureCollection",
  "features": []};
   gj.features=data;
   gj_new =gj;


    res.json(gj_new)
  } catch (e) {
    next(e);
  }
};


//steps in process


