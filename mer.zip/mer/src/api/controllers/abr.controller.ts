export {};
import { NextFunction, Request, Response, Router } from 'express';
const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;
const httpStatus = require('http-status');
const { omit } = require('lodash');
import { User, UserNote, Abr } from 'api/models';
import { startTimer, apiJson } from 'api/utils/Utils';
const { handler: errorHandler } = require('../middlewares/error');



exports.getabr = async (req :Request, res:Response, next: NextFunction) => {

  try {
           await res.json("Abr Trans.......")
          } 
          
          catch (e) {

          next(e) 
          }
};




/**
 * Get user list
 * @public
 * @example GET https://localhost:3009/v1/users?role=admin&limit=5&offset=0&sort=email:desc,createdAt
 */
exports.listabr = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await Abr.list(req)).transform(req);
    apiJson({ req, res, data, model: Abr });
  } catch (e) {
    next(e);
  }
};


exports.listfuzz = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await Abr.listfuzz(req)).transform(req);
  await console.log('data  ', data   )
    apiJson({ req, res, data, model: Abr});
  } catch (e) {
    next(e);
  }
};


