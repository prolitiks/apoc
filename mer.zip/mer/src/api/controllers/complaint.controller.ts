export {};
import { NextFunction, Request, Response, Router } from 'express';
const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;
const httpStatus = require('http-status');
const { omit } = require('lodash');
import { User, UserNote, Complaint} from 'api/models';
import { startTimer, apiJson } from 'api/utils/Utils';
import { json } from 'body-parser';
const { handler: errorHandler } = require('../middlewares/error');





exports.gettrans = async (req :Request, res:Response, next: NextFunction) => {

  try {
           await res.json("Complaint Trans.......")

           console.log('Cookies: ', req.cookies)

          } 
          
          catch (e) {

          next(e) 
          }
}


// /**
//  * Get user list
//  * @public
//  * @example GET https://localhost:3009/v1/users?role=admin&limit=5&offset=0&sort=email:desc,createdAt
//  */
exports.list = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await Complaint.list(req)).transform(req);
  //  console.log('Complaint.list(req)) ', req   )
    apiJson({ req, res, data, model: Complaint });
  } catch (e) {
    next(e);
  }
};


exports.listfuzz = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await Complaint.listfuzz(req)).transform(req);
  await console.log('data  ', data   )
    apiJson({ req, res, data, model: Complaint });
  } catch (e) {
    next(e);
  }
};





exports.postAddStory = (req : Request, res: Response, next: NextFunction) => {
  const storyname = req.body.storyname;
  const description = req.body.description;
  const storyType = req.body.storyType;

  };



/**
 * Create new user  or save the chart object  need to ad user plus the data   https://medium.com/@justinmanalad/pre-save-hooks-in-mongoose-js-cf1c0959dba2
 * @public
 */
exports.create = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = new User(req.body);
    const savedUser = await user.save();
    res.status(httpStatus.CREATED);
    res.json(savedUser.transform());
  } catch (error) {
    next(User.checkDuplicateEmail(error));
  }
};

/*

const UserSchema = new Schema({ 
  firstName: String, 
  lastName: String, 
  fullName: String, 
}) 
UserSchema.pre('save', async function preSave() { 
  this.fullName = `${this.lastName} ${this.firstName}` 
}) 
UserSchema.post('save', async function postSave(doc) { 
  console.log(`New user created: ${doc.fullName}`) 
}) 
const User = mongoose.model('User', UserSchema) 

*/
