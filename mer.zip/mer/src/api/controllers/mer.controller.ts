export {};
import { NextFunction, Request, Response, Router } from 'express';
const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;
const httpStatus = require('http-status');
const { omit } = require('lodash');
import { User, UserNote } from 'api/models';
import { startTimer, apiJson } from 'api/utils/Utils';
const { handler: errorHandler } = require('../middlewares/error');





const cookieExtractor =  function(req :Request) {
  let token = null;
 
  if (req && req.cookies.tokendata ) {
    let {data} =  JSON.parse (    req.cookies.tokendata  )
    token = data.token['accessToken']
     
  }
  return token;
};

exports.getg = async (req :Request, res:Response, next: NextFunction) => {
  //req.headers.authorization = 'bearer '+ req.cookies.tokendata.token['accessToken']  ;
  try {
   // let {data} = await JSON.parse (    req.cookies.tokendata  )
         //  req.headers.authorization = 'bearer '+ data.token['accessToken'] ;
           res.json("WORKS.......")

           console.log( 'cookieExtractor  ',  cookieExtractor(req ) )
           // config.headers.Authorization = 'bearer '+ data.token['accessToken'];
           //request.headers.authorization = value;
        //   let {data} = await JSON.parse (    req.cookies.tokendata  )
           //console.log( 'token  '   , data.token['accessToken']);  
           //console.log( 'req headers  '   , req.headers.authorization);  

          } 
          
          catch (e) {

          next(e) 
          }
};




const axios = require('axios')


// let googlePlaceSearch = {
//   input : '' ,
//   inputtype: `textquery`,
//   fields: `formatted_address,name,place_id`,
//   key: `AIzaSyDJVz3WeFDB23Xm-O_QWqT6AWzUV67WqcI`
// }

// /* eslint-disable */
// let googlequery = function (data :any, startsearchhttp:any) {


//   googlePlaceSearch.input   = startsearchhttp
//   if (typeof (data) === 'string') return data;
//   let query = [];
//   for (let key in data) {
//     if (data.hasOwnProperty(key)) {
//       query.push(`${encodeURIComponent(key)  }=${  encodeURIComponent(data[key])}`);
//     }
//   }
//   const starts =`https://maps.googleapis.com/maps/api/place/findplacefromtext/json?`
//   const placdetail =`https://maps.googleapis.com/maps/api/place/details/json?`
//   const qur =query.join('&')
//   const qurfinal=`${starts}${qur}`
//   //need to detructure   placeid=ChIJN1t_tDeuEmsRUsoyG83frY4&fields=name,rating,formatted_phone_number&key=YOUR_API_KEY`
//    console.log( qurfinal  )
//   return qurfinal;
// };

const placesgoogle =`https://maps.googleapis.com/maps/api/place/findplacefromtext/json?`;
const placesdetailgoogle =`https://maps.googleapis.com/maps/api/place/details/json?`;

let googlePlaceSearch = {
  input : '' ,
  inputtype: `textquery`,
  fields: `formatted_address,name,place_id`,
  key: `AIzaSyDJVz3WeFDB23Xm-O_QWqT6AWzUV67WqcI`
}
let googlePlaceDetailSearch = {
  place_id: '' ,
  fields: `geometry,name,type,icon`,
  key: `AIzaSyDJVz3WeFDB23Xm-O_QWqT6AWzUV67WqcI`
}
/* eslint-disable */

//                          object ie googlePlaceSearch  , sech texy  , preurl   
let googlequery = function (data :any, startsearchhttp:any  , prehttp :string) {

 //console.log ( 'test' , Object.keys(data)[0])
  data[Object.keys(data)[0]] = startsearchhttp //adding the serch string here 
  if (typeof (data) === 'string') return data;
  let query = [];
  for (let key in data) {
     console.log( 'keys '  ,  data[key])
    if (data.hasOwnProperty(key)) {
      query.push(`${encodeURIComponent(key)  }=${  encodeURIComponent(data[key])}`);
    }

  }
  const qur =query.join('&')
  const qurfinal=`${prehttp}${qur}`
  //need to detructure   placeid=ChIJN1t_tDeuEmsRUsoyG83frY4&fields=name,rating,formatted_phone_number&key=YOUR_API_KEY`
   console.log( qurfinal  )
  return qurfinal;
};




const getGoogle = async (data : any ,serarchp :string ,  prehttp :string) => {
  try { 
    let querygoggle = await googlequery(data , serarchp  ,prehttp );
    return await axios.get(querygoggle)
  } catch (error) {
    console.error(error)
  }
}


const retGoogle = async (data : any ,serarchp :string  ,  prehttp :string ) => {
  const places = await getGoogle( data,  serarchp,   prehttp  )
  if (places.data) {
    console.log(places.data)
  }
  return places.data
}


exports.getGO = async (req :Request, res:Response, next: NextFunction) => {

  try {   
        let goog = await    retGoogle(  googlePlaceSearch,  req.query.input , placesgoogle )
        // let goog = await    retGoogle(  googlePlaceDetailSearch ,  req.query.place_id , placesdetailgoogle )
       
         //get the places detail from the id
           console.log('test resp ' ,req.query)
           await res.json(goog )
          } 
          
          catch (e) {

          next(e) 
          }
};
