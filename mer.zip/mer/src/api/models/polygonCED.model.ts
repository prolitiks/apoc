

export {};
const mongoose = require('mongoose');

const mongoose_fuzzy_searching = require('mongoose-fuzzy-searching');
import { transformData, listData ,listFuzzData ,listJoinData , listCed } from 'api/utils/ModelUtils';
import {  Tran } from 'api/models';




const polygonCEDSchema = new mongoose.Schema({
  type: {type: String, default: 'Feature'},
 
  geometry: {
    type:{ type: 'String', required: true  },
    coordinates: { type: [[[Number]]], required: true  }// Array of arrays of arrays of numbers
   
  }

  ,
  properties: {
  
    CED_CODE16 :  { type: String, required: true},
    CED_NAME16: { type: String, required: true},
    AREASQKM16 : { type: Number, required: true}
   
  }  
}   ,{ toJSON: { virtuals: true }, toObject: { virtuals: true }}

)
//,{ toJSON: { virtuals: true }, toObject: { virtuals: true }}

 const ALLOWED_FIELDS = [ 'id','properties'];

 polygonCEDSchema.virtual('tran',{
  ref:'Tran',             //model to reference
  localField:'properties.CED_CODE16',   //Class.teacher_id
  foreignField:'LOCODE_STR', //a Teacher.teacher_id
  justOne:false
});



polygonCEDSchema.method({
 // query is optional, e.g. to transform data for response but only include certain "fields"
 transform({ query = {} }: { query?: any } = {}) {
   // transform every record (only respond allowed fields and "&fields=" in query)
   return transformData(this, query, ALLOWED_FIELDS);
 }

});

polygonCEDSchema.statics = {

  list({ query }: { query: any }) {
    
    return listData(this, query, ALLOWED_FIELDS);
  }
  , 

  listfuzz({ query }: { query: any }) {
    return listFuzzData(this, query, ALLOWED_FIELDS);
  }

  ,
  listced({ query }: { query: any }) {
    return listCed(this, query);
  }

};

//polygonCEDSchema.plugin(mongoose_fuzzy_searching, {fields: ['MERCHANT_NAME','MERCHANT_SUBURB']});
  /**
 * @typedef polygonCED
 */
const polygonCED = mongoose.model('polygonCED', polygonCEDSchema);
polygonCED.ALLOWED_FIELDS = ALLOWED_FIELDS;
module.exports = polygonCED; 


// const PersonSchema = new Schema({
//   name: String,
//   band: String
// });

// const BandSchema = new Schema({
//   name: String
// });
// BandSchema.virtual('members', {
//   ref: 'Person', // The model to use
//   localField: 'name', // Find people where `localField`
//   foreignField: 'band', // is equal to `foreignField`
//   // If `justOne` is true, 'members' will be a single doc as opposed to
//   // an array. `justOne` is false by default.
//   justOne: false,
//   options: { sort: { name: -1 }, limit: 5 } // Query options, see http://bit.ly/mongoose-query-options
// });

// const Person = mongoose.model('Person', PersonSchema);
// const Band = mongoose.model('Band', BandSchema);

// /**
//  * Suppose you have 2 bands: "Guns N' Roses" and "Motley Crue"
//  * And 4 people: "Axl Rose" and "Slash" with "Guns N' Roses", and
//  * "Vince Neil" and "Nikki Sixx" with "Motley Crue"
//  */
// Band.find({}).populate('members').exec(function(error, bands) {
//   /* `bands.members` is now an array of instances of `Person` */
// });