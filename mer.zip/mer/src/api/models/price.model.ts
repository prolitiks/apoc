

export {};
const mongoose = require('mongoose');

const mongoose_fuzzy_searching = require('mongoose-fuzzy-searching');
import { transformData, listData ,listFuzzData  } from 'api/utils/ModelUtils';


const priceSchema =  new mongoose.Schema({

  MER_SA2: { 
    type: String, 
    required: true  
   },

   CATCM: {
     type: Number,
     required: false
   },
   
 
   SUM_TRAN: {
    type: Number,
    required: false
  }
  

  //   charts: {
  //    type: mongoose.Schema.Types.ObjectId,
  //    ref: 'Chart',
  //    required: false
  //  }


 }, {strict: false});


 const ALLOWED_FIELDS = [ 'id','MER_SA2', 'CATCM'   ,'SUM_TRAN'];


 priceSchema.method({
 // query is optional, e.g. to transform data for response but only include certain "fields"
 transform({ query = {} }: { query?: any } = {}) {
   // transform every record (only respond allowed fields and "&fields=" in query)
   return transformData(this, query, ALLOWED_FIELDS);
 }

});

priceSchema.statics = {

  list({ query }: { query: any }) {
    
    return listData(this, query, ALLOWED_FIELDS);
  }
  , 

  listfuzz({ query }: { query: any }) {
    return listFuzzData(this, query, ALLOWED_FIELDS);
  }
};

//PolygonSA2Schema.plugin(mongoose_fuzzy_searching, {fields: ['MERCHANT_NAME','MERCHANT_SUBURB']});
  /**
 * @typedef PolygonSA2
 */
const Price = mongoose.model('Price', priceSchema);
Price.ALLOWED_FIELDS = ALLOWED_FIELDS;
module.exports = Price; 


