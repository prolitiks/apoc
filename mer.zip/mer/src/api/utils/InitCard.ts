export {};
import { User, UserNote ,Card} from 'api/models';

const ADMIN_USER_1 = {
  email: 'admin1@example.com',
  role: 'admin',
  password: '1admin1'
};


async function setup() {
  const adminUser1 = new User(ADMIN_USER_1);
  await adminUser1.save();

  for (let i = 0; i < 100; i += 1) {
    const note = new UserNote({ user: adminUser1, note: `admin1 note ${i}` });
    await note.save();


  }
  
}

async function checkNewDB() {
  const adminUser1 = await User.findOne({ email: ADMIN_USER_1.email });
  if (!adminUser1) {
    console.log('- New DB detected ===> Initializing Dev Data...');
    await setup();
  } else {
    console.log('- Skip InitData');
  }
}

checkNewDB();


/*

mongoimport --db node-rem --collection card --file C:\DR\Inter\data\card_hoppo.json  --jsonArray
mongoimport --db chuck --collection CUSTLGAAG --file D:\Hoppo\HA\data\JSON\CUST_LGA_AG_MP.json --jsonArray

mongoimport --db chuck --collection SA2HLSP --file C:\DR\OperationDeltForce\LeData\JSON\SA2_HL_002.json --jsonArray
SA2_HL_002


{
    "_id" : ObjectId("5d5782574448cc04fc5a8b9e"),
    "role" : "user",
    "email" : "dhopkins@westpac.com.au",
    "password" : "$2a$10$oJW3qtvZRABAojBJrOMB0e1RgiivbTMaVanOJq5tke0dFrh5osSqy",
    "createdAt" : ISODate("2019-08-17T04:28:07.387Z"),
    "updatedAt" : ISODate("2019-08-17T04:28:07.387Z"),
    "__v" : 0
}
*/

