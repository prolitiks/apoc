import { getQuery, getPageQuery, queryPromise } from 'api/utils/Utils';
const aqp = require('api-query-params');

 
// transform every record (only respond allowed fields and "&fields=" in query)
export function transformData(context: any, query: any, allowedFields: string[]) {
  const queryParams = getPageQuery(query);
  const transformed: any = {};
  allowedFields.forEach((field: string) => {
    if (queryParams && queryParams.fields && queryParams.fields.indexOf(field) < 0) {
      return; // if "fields" is set => only include those fields, return if not.
    }
    transformed[field] = context[field];
  });

  return transformed;
}

// list data with pagination support
// return a promise for chaining. (e.g. list then transform)
export function listData(context: any, query: any, allowedFields: string[]) {
  //const queryObjx = getQuery(query, allowedFields); // allowed filter fields  1. 
   const qry = aqp (query) 
  const queryObjx = getQuery(qry.filter, allowedFields); // allowed filter fields  1. 

  const queryObj = queryObjx
  // const queryObj = queryObjx[0]
  const { page = 1, perPage = 10, limit=10, offset, sort } = getPageQuery(query);
  
   //console.log( 'query listdata ** '  , query    )

  // console.log( ' queryObjx listdata ** '  , queryObjx   )
  // console.log( ' queryObjx allowedFields** '  , allowedFields  )    https://github.com/loris/api-query-params

  const result = context
    .find(queryObj)
    .sort(sort)
    .skip(typeof offset !== 'undefined' ? offset : perPage * (page - 1))
    .limit(typeof limit !== 'undefined' ? limit : perPage)
    .exec();
  return queryPromise(result);
}

//could put new function here


//:  { ASIC_CODE: '7994', MERCHANT_NAME: 'STEAMGAMES.COM', FUZ: 'hello' }

export function listFuzzData(context: any, query: any, allowedFields: string[]) {
  const queryObj = getQuery(query, allowedFields); // allowed filter fields
  let  fuzz =queryObj.FUZ
  //need to remove 'FUZZ' from query object
  let result
  console.log( ' queryObj.FUZ ' , queryObj.FUZ  )
  const { page = 1, perPage = 10, limit=10, offset, sort } = getPageQuery(query);
   //fuzz =queryObj.FUZ

  //delete queryObj.FUZ 
      
  if (  typeof query.FUZ !== 'undefined'){
     delete queryObj.FUZ 
      result = context
      .fuzzySearch({query: fuzz    ,minSize: 4  })
     // .find(queryObj)
      .sort(sort)
      .skip(typeof offset !== 'undefined' ? offset : perPage * (page - 1))
      .limit(typeof limit !== 'undefined' ? limit : perPage)
      .exec();

      console.log( ' queryObj del' , typeof fuzz)
      console.log( ' fuzz' , fuzz )
  }
  else
  {
    result = context
   
    .find(queryObj)
    .sort(sort)
    .skip(typeof offset !== 'undefined' ? offset : perPage * (page - 1))
    .limit(typeof limit !== 'undefined' ? limit : perPage)
    .exec();
  }
    
    console.log( ' result ' , result )

  return queryPromise(result);
}



export function listJoinData(context: any, query: any) {

  const result = context
    .find({ } )
    .populate({ path: 'price', select: 'SUM_TRAN -_id'})
    .limit(30)
    .exec();
  return queryPromise(result);
}



export function listCed (context: any, query: any) {

  const result = context
    .find({ } )
    .populate({ path: 'tran', select: '-_id'})
    .limit(50)
    .exec();
  return queryPromise(result);
}


// let gj={
//   "type": "FeatureCollection",
//   "features": []};
// gj.features=sa2log;
// gj_new =gj;

//  let gg = gj_new.features;
// let ext =gg.map (a=>a.properties);

// res.render('./request/card/map21',  { 
// encodedJson : encodeURIComponent(JSON.stringify(gj_new)),
// encodedJson2 : encodeURIComponent(JSON.stringify(qm))

