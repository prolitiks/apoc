const mstime = require('mstime');
import { NextFunction, Request, Response, Router } from 'express';
import { ITEMS_PER_PAGE } from 'api/utils/Const';

export function jsonClone(obj: any) {
  return JSON.parse(JSON.stringify(obj));
}

// Helper functions for Utils.uuid()
const lut = Array(256)
  .fill('')
  .map((_, i) => (i < 16 ? '0' : '') + i.toString(16));
const formatUuid = ({ d0, d1, d2, d3 }: { d0: number; d1: number; d2: number; d3: number }) =>
  lut[d0 & 0xff] +
  lut[(d0 >> 8) & 0xff] +
  lut[(d0 >> 16) & 0xff] +
  lut[(d0 >> 24) & 0xff] +
  '-' +
  lut[d1 & 0xff] +
  lut[(d1 >> 8) & 0xff] +
  '-' +
  lut[((d1 >> 16) & 0x0f) | 0x40] +
  lut[(d1 >> 24) & 0xff] +
  '-' +
  lut[(d2 & 0x3f) | 0x80] +
  lut[(d2 >> 8) & 0xff] +
  '-' +
  lut[(d2 >> 16) & 0xff] +
  lut[(d2 >> 24) & 0xff] +
  lut[d3 & 0xff] +
  lut[(d3 >> 8) & 0xff] +
  lut[(d3 >> 16) & 0xff] +
  lut[(d3 >> 24) & 0xff];

const getRandomValuesFunc =
  typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues
    ? () => {
      const dvals = new Uint32Array(4);
      window.crypto.getRandomValues(dvals);
      return {
        d0: dvals[0],
        d1: dvals[1],
        d2: dvals[2],
        d3: dvals[3]
      };
    }
    : () => ({
      d0: (Math.random() * 0x100000000) >>> 0,
      d1: (Math.random() * 0x100000000) >>> 0,
      d2: (Math.random() * 0x100000000) >>> 0,
      d3: (Math.random() * 0x100000000) >>> 0
    });

/* -------------------------------------------------------------------------------- */

export function uuid() {
  return formatUuid(getRandomValuesFunc());
}

export function startTimer(req: Request) {
  mstime.start(req.originalUrl, { uuid: uuid() });
}

export function endTimer(req: Request) {
  const end = mstime.end(req.originalUrl);
  if (end) {
    console.log(`avg time - ${end.avg} (ms)`);
    return end;
  }
  return null;
}

// from "sort" string (URL param) => build sort object (mongoose), e.g. "sort=name:desc,age"
export function getSortQuery(sortStr: string, defaultKey = 'createdAt') {
  let arr = [sortStr || defaultKey];
  if (sortStr && sortStr.indexOf(',')) {
    arr = sortStr.split(',');
  }
  let ret = {};
  for (let i = 0; i < arr.length; i += 1) {
    let order = 1; // default: ascending (a-z)
    let keyName = arr[i].trim();
    if (keyName.indexOf(':') >= 0) {
      const [keyStr, orderStr] = keyName.split(':'); // e.g. "name:desc"
      keyName = keyStr.trim();
      order = orderStr.trim() === 'desc' || orderStr.trim() === '-1' ? -1 : 1;
    }
    ret = { ...ret, [keyName]: order };
  }
  return ret;
}

// from "req" (req.query) => transform to: query object, e.g. { limit: 5, sort: { name: 1 } }
export function getPageQuery(reqQuery: any) {
  if (!reqQuery) {
    return null;
  }
  const output: any = {};
  if (reqQuery.page) {
    output.perPage = reqQuery.perPage || ITEMS_PER_PAGE; // if page is set => take (or set default) perPage
  }
  if (reqQuery.fields) {
    output.fields = reqQuery.fields.split(',').map((field: string) => field.trim()); // to array
  }
  // number (type) query params => parse them:
  const numParams = ['page', 'perPage', 'limit', 'offset'];
  numParams.forEach(field => {
    if (reqQuery[field]) {
      output[field] = parseInt(reqQuery[field], 10);
    }
  });
  output.sort = getSortQuery(reqQuery.sort, 'createdAt');
  return output;
}


// - API list endpoints also support URL params for pagination
//   - Example 1: GET https://localhost:3009/v1/users?limit=5&offset=0&sort=email:desc,createdAt
//   - Example 2: GET https://localhost:3009/v1/users?page=1&perPage=20
//   - Example 3: GET https://localhost:3009/v1/users/5c7f85009d65d4210efffa42/notes?note=*partialtext*

// normalize req.query to get "safe" query fields => return "query" obj for mongoose (find, etc.)
export function getQuery(reqQuery: any, fieldArray: string[]) {
  const queryObj: any = {};
  const obfuz: any = {};

  //let queryObjArr: any = []
  fieldArray.map(field => {
    // get query fields excluding pagination fields:
    if (['page', 'perPage', 'limit', 'offset'].indexOf(field) < 0 && reqQuery[field]) {
  
        queryObj[field] = reqQuery[field]; // exact search
       
      }
    }
  );
  console.log('- queryObj: ', JSON.stringify(queryObj));
  console.log('- fieldArray : ', fieldArray);
 
  //return queryObj;
  return queryObj
}


// function to decorate a promise with useful helpers like: .transform(), etc.
// @example: return queryPromise( this.find({}) )
export function queryPromise(mongoosePromise: any) {
  return new Promise(async resolve => {
    const items = await mongoosePromise;

    // decorate => transform() on the result
    items.transform = (params: any) => {
      return items.map((item: any) => (item.transform ? item.transform(params) : item));
    };
    resolve(items);
  });
}

type apiJsonTypes = {
  req: Request;
  res: Response;
  data: any | any[]; // data can be object or array
  model?: any; // e.g. "listModal: User" to get meta.totalCount (User.countDocuments())
  meta?: any;
  json?: boolean; // retrieve JSON only (won't use res.json(...))
};
/**
 * prepare a standard API Response, e.g. { meta: {...}, data: [...], errors: [...] }
 * @param param0
 */
export async function apiJson({ req, res, data, model, meta = {}, json = false }: apiJsonTypes) {
  const queryObj = getPageQuery(req.query);
   const metaData = { ...queryObj, ...meta };
   //console.log('model: ' , model)
 
  // console.log(' queryObj: ',  queryObj.FUZ)
  // console.log(' req.query : ',  req.query)
  // console.log(' metaData: ',  metaData)

  //console.log('model: ' , model)
  if (model) {
    // if pass in "model" => query for totalCount & put in "meta"
    
    let totalCount
    
    const isPagination = req.query.limit || req.query.page;
    if (isPagination && model.countDocuments) {

      const query = getQuery(req.query, model.ALLOWED_FIELDS);
     const countQuery = jsonClone(query);
     await console.log(' typeof query : ', typeof query.FUZ )
     
       //  totalCount =await model.countDocuments(countQuery);
      
     if (  typeof query.FUZ !== 'undefined'){
     
      totalCount= await model.fuzzySearch({query: query.FUZ ,minSize: 4 }).count();
      await console.log(' undefined fired : ' )
     }
     else
    {
      totalCount =await model.countDocuments(countQuery);
      }
    
      console.log('count: ', totalCount)
      console.log('query :', query)
   //Story.fuzzySearch({query: ob}).count()
      metaData.totalCount = totalCount;
      if (queryObj.perPage) {
        metaData.pageCount = Math.ceil(totalCount / queryObj.perPage);
      }
      metaData.count = data && data.length ? data.length : 0;
      console.log('metaData.count : ', metaData.count)
    }
  }
  // add Timer data
  const timer = endTimer(req);
  if (timer) {
    metaData.timer = timer.last;
    metaData.timerAvg = timer.avg;
  }

  const output = { data, meta: metaData };
  if (json) {
    return output;
  }
  return res.json(output);
}



export function randomString(len = 10, charStr = 'abcdefghijklmnopqrstuvwxyz0123456789') {
  const chars = [...`${charStr}`];
  return [...Array(len)].map(i => chars[(Math.random() * chars.length) | 0]).join('');
}

// transform every record (only respond allowed fields and "&fields=" in query)
export function transformData(context: any, query: any, allowedFields: string[]) {
  const queryParams = getPageQuery(query);
  const transformed: any = {};
  allowedFields.forEach((field: string) => {
    if (queryParams && queryParams.fields && queryParams.fields.indexOf(field) < 0) {
      return; // if "fields" is set => only include those fields, return if not.
    }
    transformed[field] = context[field];
  });

 
  return transformed;
}

// list data with pagination support
// return a promise for chaining. (e.g. list then transform)
export function listData(context: any, query: any, allowedFields: string[]) {
  const queryObjx = getQuery(query, allowedFields); // allowed filter fields
  const queryObj = queryObjx[0]
  const { page = 1, perPage = 10, limit=10, offset, sort } = getPageQuery(query);
 
  const result = context
    .find(queryObj)
    .sort(sort)
    .skip(typeof offset !== 'undefined' ? offset : perPage * (page - 1))
    .limit(typeof limit !== 'undefined' ? limit : perPage)
    .exec();
  return queryPromise(result);
}

//could put new function here


//:  { ASIC_CODE: '7994', MERCHANT_NAME: 'STEAMGAMES.COM', FUZ: 'hello' }

export function listFuzzData(context: any, query: any, allowedFields: string[]) {
  const queryObj = getQuery(query, allowedFields); // allowed filter fields
  let  fuzz =queryObj.FUZ
  //need to remove 'FUZZ' from query object
  let result
  console.log( ' queryObj.FUZ ' , queryObj.FUZ  )
  const { page = 1, perPage = 10, limit=10, offset, sort } = getPageQuery(query);
   //fuzz =queryObj.FUZ

  //delete queryObj.FUZ 
      
  if (  typeof query.FUZ !== 'undefined'){
     delete queryObj.FUZ 
      result = context
      .fuzzySearch({query: fuzz    ,minSize: 4  })
     // .find(queryObj)
      .sort(sort)
      .skip(typeof offset !== 'undefined' ? offset : perPage * (page - 1))
      .limit(typeof limit !== 'undefined' ? limit : perPage)
      .exec();

      console.log( ' queryObj del' , typeof fuzz)
      console.log( ' fuzz' , fuzz )
  }
  else
  {
    result = context
   
    .find(queryObj)
    .sort(sort)
    .skip(typeof offset !== 'undefined' ? offset : perPage * (page - 1))
    .limit(typeof limit !== 'undefined' ? limit : perPage)
    .exec();
  }
    
    console.log( ' result ' , result )

  return queryPromise(result);
}



export function listJoinData(context: any, query: any) {

  const result = context
    .find({ } )
    .populate({ path: 'price', select: 'SUM_TRAN -_id'})
    .limit(1)
    .exec();


  return queryPromise(result);
}



import { User, UserNote, PolygonSA2 } from 'api/models';






exports.gettrans = async (req :Request, res:Response, next: NextFunction) => {

  try {
           await res.json("Polywaffle.......")
          } 
          catch (e) {
          next(e) 
          }
}


/**
 * Get user list
 * @public
 * @example GET https://localhost:3009/v1/users?role=admin&limit=5&offset=0&sort=email:desc,createdAt
 */
exports.list = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await PolygonSA2.list(req)).transform(req);
   console.log('list(req)) ', req   )
    apiJson({ req, res, data, model: PolygonSA2 });
  } catch (e) {
    next(e);
  }
};


exports.listfuzz = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await PolygonSA2.listfuzz(req)).transform(req);
  await console.log('data  ', data   )
    apiJson({ req, res, data, model: PolygonSA2 });
  } catch (e) {
    next(e);
  }
};



exports.listjoin = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await PolygonSA2.listjoin(req));
  await console.log('data  ', data   )
 //   apiJson({ req, res, data, model: Card });
  let gj_new 
  let gj={
  "type": "FeatureCollection",
  "features": []};
   gj.features=data;
   gj_new =gj;


    res.json(gj_new)
  } catch (e) {
    next(e);
  }
};

