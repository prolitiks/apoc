export {};
import * as express from 'express';
import { apiJson } from 'api/utils/Utils';

const userRoutes = require('./user.route');
const merRoutes = require('./mer.route');
const cardRoutes = require('./card.route');
const abrRoutes = require('./abr.route');
const mavenRoutes = require('./maven.route');
const authRoutes = require('./auth.route');
const uploadRoutes = require('./upload.route');
const polygonSA2Routes = require('./polygonSA2.route');
const polygonCEDRoutes = require('./polygonCED.route');
const priceRoutes = require('./price.route');
const tranRoutes = require('./tran.route');

const complaintRoutes = require('./complaint.route');

const router = express.Router();
/**
 * GET v1/status
 */
router.get('/status', (req, res, next) => {
  apiJson({ req, res, data: { status: 'OK' } });
  return next();
});

/**
 * GET v1/docs
 */


router.use('/file', express.static('file'));
router.use('/docs', express.static('docs'));
router.use('/users', userRoutes);
router.use('/mer', merRoutes);
router.use('/card', cardRoutes);
router.use('/abr', abrRoutes);
router.use('/maven', mavenRoutes);
router.use('/auth', authRoutes);
router.use('/upload', uploadRoutes);
router.use('/polygonsa2', polygonSA2Routes);
router.use('/polygonced', polygonCEDRoutes);
router.use('/price', priceRoutes);
router.use('/tran', tranRoutes);
router.use('/complaint', complaintRoutes);



module.exports = router;
