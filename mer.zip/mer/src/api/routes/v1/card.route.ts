export {};
const express = require('express');
const validate = require('express-validation');

const controller = require('../../controllers/card.controller');
const { authorize, ADMIN, LOGGED_USER } = require('../../middlewares/auth');
const { listUsers, createUser, replaceUser, updateUser } = require('../../validations/user.validation');

const router = express.Router();

/**
 * Load user when API with userId route parameter is hit  
router.get( '/apix/:page',  storyController.getStoryDetailAPI  );
 */

//router.get('/',   controller.gettrans);



router
  .route('/')
 //.get( controller.list)
 .get( controller.gettrans)
 

router
.route('/fuzz')
.get( controller.listfuzz)

router
.route('/join')
.get( controller.listjoin)




// app.use('/admin', function(req,res,next){
//   if(req.user){
//     return express.static(path.join(__dirname, 'public'));
//   } else {
//     res.render(403, 'login', {message:'Please, login!'});
//   }
//  });


module.exports = router;

