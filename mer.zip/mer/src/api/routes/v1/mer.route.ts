export {};
const express = require('express');
const validate = require('express-validation');
const controller = require('../../controllers/mer.controller');
const { authorize, ADMIN, LOGGED_USER } = require('../../middlewares/auth');
const { listUsers, createUser, replaceUser, updateUser } = require('../../validations/user.validation');

const router = express.Router();

/**
 * Load user when API with userId route parameter is hit  
router.get( '/apix/:page',  storyController.getStoryDetailAPI  );
//
router.route('/:userId/notes').get( authorize(LOGGED_USER),controller.listUserNotes);
 */

router.route('/').get( controller.getg   );
console.log(  'mer logged '  ,LOGGED_USER )
//router.get('/',  authorize(LOGGED_USER), controller.getg    );
router.get('/getexternal',   controller.getGO);

module.exports = router;


