const mongoose = require('mongoose')
require('mongoose').connect('mongodb://localhost:27017/node-rem');
var mongoose_fuzzy_searching = require('mongoose-fuzzy-searching');

const Schema = mongoose.Schema;

 
const cardSchema = new Schema({


    ASIC_CODE	: {  type: 'String',   required: false  },
    CARDMEMBER_PRES	: {  type: 'String',   required: false  },
    CARD_PRES	: {  type: 'String',   required: false  },
    CARD_TRANSACTION_SOURCE	: {  type: 'String',   required: false  },
    MERCHANT_COUNTRY_CODE	: {  type: 'String',   required: false  },
    MERCHANT_ID	: {  type: 'String',   required: false  },
    MERCHANT_NAME	: {  type: 'String',   required: false  },
    MERCHANT_SUBURB	: {  type: 'String',   required: false  },
    MONTH_KEY	: {  type: 'String',   required: false  },
    MerText	: {  type: 'String',   required: false  },
    PERIOD_ID	: {  type: 'String',   required: false  },
    POS_ENTR_MODE	: {  type: 'String',   required: false  },
    TRANSACTION_VALUE	: {  type: 'String',   required: false  },
    TRAN_CNCY_CODE	: {  type: 'String',   required: false  },
    TR_AMT	: {  type: 'String',   required: false  },
    trdate	: {  type: 'String',   required: false  },
      user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  
      }, {strict: false});
  // },
  
  //  userId: {
  //    type: Schema.Types.ObjectId,
  //    ref: 'User',
  //    required: false
  //  }
  
//  merchSchema.plugin(mongoosePaginate);
cardSchema.plugin(mongoose_fuzzy_searching, {fields: ['MERCHANT_NAME','MERCHANT_SUBURB']});

//  merchSchema.plugin(mongooseHistory)


Card =mongoose.model('Card', cardSchema);

const updateFuzzy = async (Model, attrs) => {
       // const data = await Model.findOne();
         const dcount = await Model.count()   
        const datax = await Model.find({}).limit(2000)   ;

        let data;
        for (var i = 0; i < datax.length; i++) {
        data = await datax[i]
        const obj = await attrs.reduce((acc, attr) => ({ ...acc, [attr]: data[attr] }), {});
        await console.log('updated record: ', i)
        await Model.findByIdAndUpdate(data._id, obj).exec();
           if  (i== (datax.length -1 )  )
        {
          process.exit()  
        }
      }

}

 
updateFuzzy(Card, ['MERCHANT_NAME','MERCHANT_SUBURB']);


