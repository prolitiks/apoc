export {};
import { NextFunction, Request, Response, Router } from 'express';
const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;
const httpStatus = require('http-status');
const { omit } = require('lodash');
import { User, UserNote, Maven } from 'api/models';
import { startTimer, apiJson } from 'api/utils/Utils';
const { handler: errorHandler } = require('../middlewares/error');



exports.getmaven = async (req :Request, res:Response, next: NextFunction) => {
  try {
           await res.json("Maven Trans.......")
          } 
          catch (e) {
          next(e) 
          }
};

// /**
//  * Get user list
//  * @public
//  * @example GET https://localhost:3009/v1/users?role=admin&limit=5&offset=0&sort=email:desc,createdAt
//  */
exports.list = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await Maven.list(req)).transform(req);
    apiJson({ req, res, data, model: Maven });
  } catch (e) {
    next(e);
  }
};



exports.listfuzz = async (req: Request, res: Response, next: NextFunction) => {
  try {
    startTimer(req);
    const data = (await Maven.listfuzz(req)).transform(req);
  await console.log('data  ', data   )
    apiJson({ req, res, data, model: Maven});
  } catch (e) {
    next(e);
  }
};


