
// const mongoosePaginate = require('mongoose-paginate');
// var mongoose_fuzzy_searching = require('mongoose-fuzzy-searching');
// var mongooseHistory = require('mongoose-history')  count : 2661833
//we need a fuzzy serch version


export {};
const mongoose = require('mongoose');
const mongoose_fuzzy_searching = require('mongoose-fuzzy-searching');
import { transformData, listData ,listFuzzData  } from 'api/utils/ModelUtils';


const abrSchema = new mongoose.Schema({

  BUSN	: {  type: 'String',   required: false  },
  TRADN	: {  type: 'String',   required: false  },
  TRADNF	: {  type: 'String',   required: false  },
  BUSPC	: {  type: 'String',   required: false  },
  BUSSTATE	: {  type: 'String',   required: false  },
  STATUS	: {  type: 'String',   required: false  },
  ABN_	: {  type: 'String',   required: false  },
  BSUB	: {  type: 'String',   required: false  },
  BSUBSSC	: {  type: 'String',   required: false  },
  BSUBF	: {  type: 'String',   required: false  },
  

  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }


  }, {strict: false});

  const ALLOWED_FIELDS = ['id', 'user', 'BUSN','TRADN','TRADNF', 'BUSPC', 'BUSSTATE', 'STATUS', 'ABN_', 'BSUB', 'BSUBSSC', 'BSUBF','FUZ'];

  // cardSchema.plugin(mongoosePaginate);
  // cardSchema.plugin(mongoose_fuzzy_searching, {fields: ['MERCHANT_NAME', 'MERCHANT_SUBURB']});
  // cardSchema.plugin(mongooseHistory)

//  module.exports =  mongoose.model('


abrSchema.method({
  // query is optional, e.g. to transform data for response but only include certain "fields"
  transform({ query = {} }: { query?: any } = {}) {
    // transform every record (only respond allowed fields and "&fields=" in query)
    return transformData(this, query, ALLOWED_FIELDS);
  }
});

abrSchema.statics = {
  list({ query }: { query: any }) {
    return listData(this, query, ALLOWED_FIELDS);
  }

  ,

listfuzz({ query }: { query: any }) {
  return listFuzzData(this, query, ALLOWED_FIELDS);
}


};


abrSchema.plugin(mongoose_fuzzy_searching, {fields: ['BSUB','TRADN','BUSN']});
  /**
 * @typedef Abr
 */
const Abr = mongoose.model('Abr', abrSchema);
Abr.ALLOWED_FIELDS = ALLOWED_FIELDS;
module.exports = Abr;


  //https://github.com/VassilisPallas/mongoose-fuzzy-searching#simple-usage

  //mongoimport --db chuck --collection CUSTLGAAG --file D:\Hoppo\HA\data\JSON\CUST_LGA_AG_MP.json --jsonArray