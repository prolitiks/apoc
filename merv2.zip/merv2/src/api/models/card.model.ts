
// const mongoosePaginate = require('mongoose-paginate');
// var mongoose_fuzzy_searching = require('mongoose-fuzzy-searching');
// var mongooseHistory = require('mongoose-history')
//we need a fuzzy serch version  cardSchema.plugin(mongoose_fuzzy_searching, {fields: ['MERCHANT_NAME','MERCHANT_SUBURB']});


export {};
const mongoose = require('mongoose');

const mongoose_fuzzy_searching = require('mongoose-fuzzy-searching');
import { transformData, listData ,listFuzzData  } from 'api/utils/ModelUtils';


const cardSchema = new mongoose.Schema({

  ASIC_CODE	: {  type: 'String',   required: false  },
  CARDMEMBER_PRES	: {  type: 'String',   required: false  },
  CARD_PRES	: {  type: 'String',   required: false  },
  CARD_TRANSACTION_SOURCE	: {  type: 'String',   required: false  },
  MERCHANT_COUNTRY_CODE	: {  type: 'String',   required: false  },
  MERCHANT_ID	: {  type: 'String',   required: false  },
  MERCHANT_NAME	: {  type: 'String',   required: false  },
  MERCHANT_SUBURB	: {  type: 'String',   required: false  },
  MONTH_KEY	: {  type: 'String',   required: false  },
  MerText	: {  type: 'String',   required: false  },
  PERIOD_ID	: {  type: 'String',   required: false  },
  POS_ENTR_MODE	: {  type: 'String',   required: false  },
  TRANSACTION_VALUE	: {  type: 'String',   required: false  },
  TRAN_CNCY_CODE	: {  type: 'String',   required: false  },
  TR_AMT	: {  type: 'String',   required: false  },
  trdate	: {  type: 'String',   required: false  },

  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }


  }, {strict: false});

 // const ALLOWED_FIELDS = ['id', 'user', 'TR_AMT', 'MerText',' PERIOD_ID','trdate','ASIC_CODE','CARD_PRES','MERCHANT_NAME','MERCHANT_SUBURB'];
  const ALLOWED_FIELDS = [ 'id','TR_AMT', 'MerText',' PERIOD_ID','ASIC_CODE','trdate','MERCHANT_NAME','MERCHANT_SUBURB','FUZ'];

  // cardSchema.plugin(mongoosePaginate);
  // cardSchema.plugin(mongoose_fuzzy_searching, {fields: ['MERCHANT_NAME', 'MERCHANT_SUBURB']});
  // cardSchema.plugin(mongooseHistory)

//  module.exports =  mongoose.model('Card', cardSchema );


cardSchema.method({
  // query is optional, e.g. to transform data for response but only include certain "fields"
  transform({ query = {} }: { query?: any } = {}) {
    // transform every record (only respond allowed fields and "&fields=" in query)
    return transformData(this, query, ALLOWED_FIELDS);
  }
 
  


});

// cardSchema.statics = {
//   list({ query }: { query: any }) {
//     return listData(this, query, ALLOWED_FIELDS);
//   }
// };

cardSchema.statics = {
 
  list({ query }: { query: any }) {
    
    return listData(this, query, ALLOWED_FIELDS);
  }

  , 
   
  listfuzz({ query }: { query: any }) {
    return listFuzzData(this, query, ALLOWED_FIELDS);
  }
 
};

cardSchema.plugin(mongoose_fuzzy_searching, {fields: ['MERCHANT_NAME','MERCHANT_SUBURB']});

  /**
 * @typedef Card
 */
const Card = mongoose.model('Card', cardSchema);
Card.ALLOWED_FIELDS = ALLOWED_FIELDS;
module.exports = Card;


  //https://github.com/VassilisPallas/mongoose-fuzzy-searching#simple-usage

  //mongoimport --db chuck --collection CUSTLGAAG --file D:\Hoppo\HA\data\JSON\CUST_LGA_AG_MP.json --jsonArray