/* eslint-disable */

///https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=Museum%20of%20Contemporary%20Art%20Australia&inputtype=textquery&fields=photos,formatted_address,name,rating,opening_hours,geometry&key=AIzaSyDJVz3WeFDB23Xm-O_QWqT6AWzUV67WqcI


//https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=mongolian%20grill&inputtype=textquery&fields=photos,formatted_address,name,opening_hours,rating&locationbias=circle:2000@47.6918452,-122.2226413&key=AIzaSyDJVz3WeFDB23Xm-O_QWqT6AWzUV67WqcI

//api AIzaSyDJVz3WeFDB23Xm-O_QWqT6AWzUV67WqcI
//select one from the list

//https://maps.googleapis.com/maps/api/place/findplacefromtext/json?
//https://maps.googleapis.com/maps/api/place/details/json?placeid=ChIJn5qtqpytEmsRn2juKNy2hjQ&fields=name,rating,formatted_phone_number&key=AIzaSyDJVz3WeFDB23Xm-O_QWqT6AWzUV67WqcI
//https://maps.googleapis.com/maps/api/place/details/json?placeid=ChIJn5qtqpytEmsRn2juKNy2hjQ&key=AIzaSyDJVz3WeFDB23Xm-O_QWqT6AWzUV67WqcI

//need to include places id 





let buildQuery = function (data) {
  if (typeof (data) === 'string') return data;
  let query = [];
  for (let key in data) {
    if (data.hasOwnProperty(key)) {
      query.push(`${encodeURIComponent(key)  }=${  encodeURIComponent(data[key])}`);
    }
  }
  return query.join('&');
};

let petfinderData = {
  key: '12345',
  shelterID: 'abc00',
  count: 20,
  animal: 'dogs'
};


let query = buildQuery(petfinderData);
