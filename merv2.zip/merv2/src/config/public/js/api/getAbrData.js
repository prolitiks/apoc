/* eslint-disable */

//need to create the query string first 
//http://localhost:3009/v1/card?limit=100&page=6&perPage=50&sort=MerText:desc

//localhost:3009/v1/users?fields=id,name&name=*john* (get id & name only in response)
//localhost:3009/v1/users?role=admin&page=1&perPage=20 (query & pagination)
//localhost:3009/v1/users?role=admin&limit=5&offset=0&sort=email:desc,createdAt
//need evir var for name of app, need to add the date


// Select the node that will be observed for mutations
const targetNode = document.getElementById('some-id');

// Options for the observer (which mutations to observe)
const config = { attributes: true, childList: true, subtree: true };

// Callback function to execute when mutations are observed
const callback = function(mutationsList, observer) {
    for(let mutation of mutationsList) {
        if (mutation.type === 'childList') {
            console.log('A child node has been added or removed.');
        }
        else if (mutation.type === 'attributes') {
            console.log('The ' + mutation.attributeName + ' attribute was modified.');
        }
    }
};
//   "start": "cross-env NODE_ENV=production forever start -a --uid 'node-rem' -v -c ts-node src/index.ts",
// Create an observer instance linked to the callback function
const observer = new MutationObserver(callback);

// Start observing the target node for configured mutations
observer.observe(targetNode, config);

// Later, you can stop observing
observer.disconnect();


let buildQuery = function (data) {
  if (typeof (data) === 'string') return data;
  let query = [];
  for (let key in data) {
    if (data.hasOwnProperty(key)) {
      query.push(`${encodeURIComponent(key)  }=${  encodeURIComponent(data[key])}`);
    }
  }
  return query.join('&');
};

//default query
let cardData = {
  limit: 20,
  perPage: 20
};

let querya = buildQuery(cardData);

console.log('qerya  ',querya )

var params ={};
var inJson;
var instory;

const getStateData= async (srchterm=querya, pg=1) => {
     const sortby = `&sort=MerText:desc`
     console.log(`/v1/card?${srchterm}&page=${pg}${sortby}`)
     const response = await axios({
  //  url: `/v1/card?limit=20&page=1${sortby}`,
    url: `/v1/card?${srchterm}&page=${pg}${sortby}`,
    method: 'get',
    onDownloadProgress: function(progressEvent) {
   //     console.log('download', progressEvent);  //put the progress bar in this function  limit=20&page=1&offset=20&perPage=20   ***
      }
  })
 let  {data , meta } = await response.data
    //need to destructure 

  let { perPage , limit , sort  , totalCount  , pageCount   , count  ,page}  = meta;
  let page_ = page.toString()    ;  
    await console.log('pagedata: ', perPage , limit , sort  , totalCount  , pageCount   , count  , page_)
    await pagination( `/v1/card?` , data  ,totalCount  , limit , page_ , pageCount   ) 
//,"meta":{"perPage":20,"limit":20,"sort":{"MerText":-1},"totalCount":1350,"pageCount":68,"count":20,"timer":25.4,"timerAvg":25.4}}

   inJson= await data
    await console.log('getall: ', inJson)
    return data
}

let querys =''

const getAllStuff = async (  querya  ,  pg    ) => {
  
  //step 1
 // const querys = await searchparms()

  //querys = await  searchp (elname)
  //await console.log('step 1 : ', querys)

  //step 2
   let docs= await getStateData ( querya , pg )

  // //step 3   fill the table 
    await console.log('returned docs: ' ,docs  )
    await  CreateTableFromJSON(docs, 1,0    )

}
document.getElementById("but1").addEventListener('click', getAllStuff)


//create special links for columns that are links , bold etc.  

let nodata =  [{ "NO": "DATA" }];
let tagopen1 =''  ;
let tagclose1 =''  ;
let tag1= 'H4';
let attr1 =' '
let cls1 =' '
let lnk1 =' '
//these are the cols to change  
const hidecolhead =[0]
const hidehcolrows =[0]

//how do we select the id from the button  pressed
//need to add the triggers  
    function CreateTableFromJSON(inJson=nodata, colid =1,colidx=0) {
     console.log('arg   ', arguments.length)
        // EXTRACT VALUE FOR HTML HEADER. 
    
        var col = [];
        for (var i = 0; i < inJson.length; i++) {
            for (var key in inJson[i]) {
                if (col.indexOf(key) === -1) {
                    col.push(key);
                }
            }
        }

        // CREATE DYNAMIC TABLE.
        var table = document.createElement("table");
        table.classList.add("uk-table", "uk-table-hover" ,"uk-text-small");
        // CREATE HTML TABLE HEADER ROW USING THE EXTRACTED HEADERS ABOVE.
        var tr = table.insertRow(-1);                   // TABLE ROW.
        for (var i = 0; i < col.length; i++) {
            var th = document.createElement("th");      // TABLE HEADER no changes needed to the header.
            th.innerHTML = col[i];
            tr.appendChild(th); // this is the normal condition 
      
               if ( hidecolhead.includes(i))  {
                 th.hidden =true;
              }
        }
        // ADD JSON DATA TO THE TABLE AS ROWS.
        for (var i = 0; i < inJson.length; i++) {
            tr = table.insertRow(-1);
            for (var j = 0; j < col.length; j++) 
            {
                var tabCell = tr.insertCell(-1);
            //    tabCell.innerHTML = inJson[i][col[j]];
                let w=  inJson[i][col[j]];
                if ( j === colid ) {  // j is the col, ive selected here for highlighting or whatever
                    tabCell.innerHTML  = `${tagopen1}${w}${tagclose1}`
                
                  //  tabCell.addEventListener('click', testgetEl);
                }
                if ( j === colidx ) {  // j is the col, ive selected here for highlighting or whatever
                    tabCell.innerHTML  = `${tagopen1}${w}${tagclose1}`

                //    tabCell.addEventListener('click', testgetEl2);
                }
                //hidden values for ids etc
                  if ( hidehcolrows.includes(j)  )   {
                    //do something else here 
                    tabCell.hidden =true
                }
                else {
                tabCell.innerHTML  =  w  // this is the normal condition 
                }
            }
              var tabCell = tr.insertCell(-1);



          //   tabCell.innerHTML = ''
          //need to add delete and edit to here 
          tabCell.insertAdjacentHTML("beforeend", 
          `<span><a href="#">...</a>
            </span> <div uk-dropdown ="pos: left-top">  
            <ul class="uk-nav uk-dropdown-nav">
            <li><a href="#">Edit</a></li> 
            <li><a href="#">Delete</a></li>
            </ul>
            </div>`);

             //  tabCell.addEventListener('click', el3);
             //delete event handler
             // tabCell.querySelector("div > ul > li:nth-child(2) > a").addEventListener('click', el3);
             //  tabCell.querySelector("div > ul > li:nth-child(1) > a").addEventListener('click', el3);
        }

        // FINALLY ADD THE NEWLY CREATED TABLE WITH JSON DATA TO A CONTAINER.
        var divContainer = document.getElementById("showData");
        divContainer.innerHTML = "";
        divContainer.appendChild(table);
    }

//this is the query parms to pass to the post request, so get all the classses here as serch parms 
//the name of the class or classes  will be the name of the input parms !!!!!!
function searchp (elname) {
  const allins =  document.getElementsByClassName(`${elname}`)
  for (i = 0; i < allins.length; i++) {
      params[allins[i].id ]=allins[i].value 
  }
  return queryString = Object.keys(params).map(key => key + '=' + params[key]).join('&');
}

    



//edit or delete actions based on getting the id from the click event
let el3 = async function testgetEl3 (e) {

  //put a special id on the prod and user ids and add an event lister function to them  
  //start off with https://github.com/ngduc/node-rem/blob/master/src_docs/features.md
  
   
    const actidupdom = '1' //where we get the id for the edit or delete
    const actelemt = '3' //where we the elemt we want to change /edit eg input 
    const actelemt2 = '4' //where we the elemt we want to change /edit eg input 
  
    const actionid = await e.target.closest(`tr`).querySelector(`td:nth-child(${actidupdom})`).innerHTML 
    let actionelemt = await e.target.closest(`tr`).querySelector(`td:nth-child(${actelemt})`)
    let actionelemt2 = await e.target.closest(`tr`).querySelector(`td:nth-child(${actelemt2})`)
    let qts  =  await e.target.closest(`tr`).childElementCount;   //get the nth child count   
  const actiontype =e.target.innerHTML 
  
      console.log( "el3   type : "  , actiontype   , 'actionID :  ' ,   actionid )
       
        if (actiontype == 'Delete')  {
          
          console.log( "Just actioned this function : "  , actiontype   )
       
        } 
        if (actiontype == 'Edit')  {
          let  curval  = actionelemt.innerHTML;
          console.log( "Just actioned this function : "  , actiontype  , 'element :',  curval  , 'count ' , qts )
         //todo  execute edit event (make the table cells have inputs  )  
        // actionelemt.innerHTML    = `<input id ="in1xxx"  value="${curval}"   type="text">`
           // need to hide dissable elements       push into form object
         actionelemt2.setAttribute("contenteditable", "true")
        
                      
        } 
       
      //what to do based on these actions
    //  delax( deleteid )
   //   getallrefresh()
  }   
  


















function pagination (pglink = `/chart/pa/` , docs =[] , total =0 , limit =0 , page ='0', pages=0   ) {

  //todo check if this elemnt is already created , if yes remove document.querySelector("#pagea > ul")
  //need to disable bad
  let fist =document.querySelector("#pagea > ul")
  if ( fist !== null )
    {
      fist.remove()
    }
  
  console.log('first ' ,fist  )
  const curpg = parseInt(page); 
  const nxtpg = curpg+1;
  const prvpg = curpg-1;
  let ul= document.createElement("ul");     
  let pg=document.getElementById("pagea")
  pg.appendChild(ul);  
  ul.classList.add("uk-pagination");
  let li= document.createElement("li")
  ul.appendChild(li); 
  if ( curpg  !==1  )  {
  //li.insertAdjacentHTML("beforeend", `<a  onclick="getFuzSerch( '${querys}'  , ${prvpg})"   href="#"><span uk-pagination-previous></span></a>`);
  li.insertAdjacentHTML("beforeend", `<a  onclick="getAllStuff ( '${querya}' , ${prvpg})"   href="#"><span uk-pagination-previous></span></a>`);
  console.log(  'curpage not 1  '  ,  `${querya}`    )
  }
  else 
  {
    li.insertAdjacentHTML("beforeend", `<a   href="#"><span uk-pagination-previous></span></a>`);
  }

  let outpgarr= generatePagination (curpg , pages)  
  console.log( 'outpgarr ' ,outpgarr   )
  console.log( 'q srting in pagation function: ' ,querys  )
  let lis =null
        for (let i = 0; i < outpgarr.length  ; i++) {
             lis= document.createElement("li");      
           //need to add event listener with 2 parms  
          //  lis.innerHTML =  `<a  onclick="getFuzSerch( '${querys}'  , ${outpgarr[i]})"  href="#">${outpgarr[i]}</a>`  
            lis.innerHTML =  `<a   onclick="getAllStuff ( '${querya}' , ${outpgarr[i]})"  href="#">${outpgarr[i]}</a>`  
            ul.appendChild(lis); 
            if ( outpgarr[i]== "..."  )
                 {
                  lis.classList.add("uk-disabled")   
                 }
             if (outpgarr[i]== page )
                {
                  lis.classList.add("uk-active")
                }
        }
       
        console.log('lis: ' , lis  )
  
         if (lis !== null) 
         {
         ul.appendChild(lis)
  
           if ( curpg  <  pages )  {
                 lis.insertAdjacentHTML("afterend", `<li> <a  onclick="getAllStuff ( '${querya}'  , ${nxtpg })"   href="#"><span uk-pagination-next></span></a>  </li>`);
              }     
            else
              {
                 lis.insertAdjacentHTML("afterend", `<li><a   href="#"><span uk-pagination-next>.</span></a></li>`);
              }
  
         }
  
        console.log(pg)
  
      
   function generatePagination(current, last) {
    const offset = 2;
    const leftOffset = current - offset;
    const rightOffset = current + offset + 1;
  
    /**
     * Reduces a list into the page numbers desired in the pagination
     * @param {array} accumulator - Growing list of desired page numbers
     * @param {*} _ - Throwaway variable to ignore the current value in iteration
     * @param {*} idx - The index of the current iteration
     * @returns {array} The accumulating list of desired page numbers
     */
    function reduceToDesiredPageNumbers(accumulator, _, idx) {
      const currIdx = idx + 1;
  
      if (
        // Always include first page
        currIdx === 1
        // Always include last page
        || currIdx === last
        // Include if index is between the above defined offsets
        || (currIdx >= leftOffset && currIdx < rightOffset)) {
        return [
          ...accumulator,
          currIdx,
        ];
      }
  
      return accumulator;
    }
  
    /**
     * Transforms a list of desired pages and puts ellipsis in any gaps
     * @param {array} accumulator - The growing list of page numbers with ellipsis included
     * @param {number} currentPage - The current page in iteration
     * @param {number} currIdx - The current index
     * @param {array} src - The source array the function was called on
     */
    function transformToPagesWithEllipsis(accumulator, currentPage, currIdx, src) {
      const prev = src[currIdx - 1];
  
      if (prev != null && currentPage - prev !== 1) {
        return [
          ...accumulator,
          '...',
          currentPage,
        ];
      }
  
      // If page does not meet above requirement, just add it to the list
      return [
        ...accumulator,
        currentPage,
      ];
    }
    const pageNumbers = Array(last)
      .fill()
      .reduce(reduceToDesiredPageNumbers, []);
    const pageNumbersWithEllipsis = pageNumbers.reduce(transformToPagesWithEllipsis, []);
    return pageNumbersWithEllipsis;
       }
     }