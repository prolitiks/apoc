/* eslint-disable */
// ES5
const Places = require("google-places-web").default; // instance of GooglePlaces Class;

// Setup
Places.apiKey = `AIzaSyDJVz3WeFDB23Xm-O_QWqT6AWzUV67WqcI`
//Places.debug = __DEV__; // boolean;

let partialAddress = "1600 Pennsylv";
const radius = 2000;
const language = "en";
const inputtype=`textquery`;
const fields=`formatted_address,name,place_id`;

// Search with default opts


// Search with default opts
Places.search({ input: partialAddress, inputtype :inputtype  })
  .then(results => {
    console.log(results)
  })
  .catch(e => console.log(e));

