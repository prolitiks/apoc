### NOTES

eslint-config-airbnb-base - pin to ^12.0.1" - 09/27/2018
  - 13.1.x, eslint will fail: Configuration for rule "import/extensions" is invalid
